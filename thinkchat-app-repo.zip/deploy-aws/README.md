# AWS ECS deploy assets

Continuous deploy for the WhatsApp platform on **ECS Fargate**: build images →
migrate the database → roll out three services (API, worker, web).

## Files
- `ecs/api-task-def.json` — API service (HTTP, port 4000, behind the ALB)
- `ecs/worker-task-def.json` — BullMQ workers (same image, `node dist/worker.js`)
- `ecs/web-task-def.json` — Next.js frontend (port 3000, behind the ALB)
- `github/deploy.yml` — CI/CD pipeline → place at `.github/workflows/deploy.yml`
- (repo) `src/worker.ts` — worker entrypoint added to the backend

## One-time AWS setup (a developer does this once)
1. **ECR repos:** `wa-api`, `wa-web`.
2. **ECS cluster:** `wa-platform` (Fargate).
3. **RDS PostgreSQL** + **ElastiCache Redis** in private subnets.
4. **S3 bucket** `wa-platform-media` + task-role permissions to it.
5. **ALB** with target groups → `wa-api` (4000) and `wa-web` (3000); HTTPS via ACM.
6. **Secrets Manager** secret holding `DATABASE_URL`, `JWT_ACCESS_SECRET`,
   `ENCRYPTION_KEY`, Meta + AI + Razorpay keys. Put its ARN in the task defs.
7. **IAM roles:** `wa-ecs-execution` (pull images, read secrets, write logs),
   `wa-ecs-task` (app's runtime perms, e.g. S3), and `github-actions-deploy`
   (trusted via GitHub OIDC; can push ECR, register task defs, update services,
   `iam:PassRole` the ECS roles, and `ecs:RunTask` for migrations).
8. **Create the three services** (`wa-api`, `wa-worker`, `wa-web`) from these task
   defs initially; the pipeline updates them thereafter.
9. Replace every `<PLACEHOLDER>` (account id, region, subnets, SG, secret ARN,
   endpoints, domain) in the task defs and workflow.

## How the pipeline works
On push to `main`: assume the OIDC role → build & push both images tagged with the
commit SHA → run `prisma migrate deploy` as a one-off Fargate task → render each
task def with the new image and roll the services with stability waits.

## Flagged refinements
- **Worker/API separation:** `src/worker.ts` boots only the DI container (no HTTP).
  But the API also instantiates the BullMQ processors today, so both would consume
  jobs. To run workers *only* in the worker service, gate the processor providers
  behind `ROLE=worker` in each module. Harmless if left (BullMQ shares load), but
  cleaner to gate.
- **RLS over pooling:** ensure the per-request PostgreSQL `app.current_org_id` is
  set inside a transaction (the `forTenant` helper) when going through RDS Proxy.
- **Realtime:** add the socket.io Redis adapter + ALB sticky sessions before
  scaling the API past one task.
- **Health endpoint:** the API task def expects `GET /health` — add a tiny health
  controller if not present.
