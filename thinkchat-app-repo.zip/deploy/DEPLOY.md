# Deploying the WhatsApp platform on a Hostinger VPS

This is a plain-English guide to getting the MVP live on one Hostinger server.
You (the founder) can follow along to understand each step; the commands in
`code boxes` are for the developer you bring on. Total setup time once the code
is ready: about half a day.

> **Important — which Hostinger product to buy (read this first)**
>
> When you order, choose **VPS → KVM 2 plan → Ubuntu 24.04**.
>
> Do **not** choose Hostinger's "Cloud hosting" plans (Cloud Startup /
> Professional / Enterprise). Despite the name, those are managed website
> hosting with no root access and no Docker, and this app will not run on them.
> The VPS is the correct product — and it costs the same or less (about
> $8–13/month).

---

## What you're setting up

One Hostinger VPS runs five small pieces side by side, in "containers"
(self-contained boxes that don't interfere with each other):

- **api** — the brain: handles WhatsApp messages, the inbox, sending, billing
- **web** — the website your team and customers see (the inbox screen)
- **postgres** — the database (all your contacts, conversations, messages)
- **redis** — the fast queue that processes messages in the background
- **caddy** — the front door: handles your domain and automatic HTTPS (the padlock)

Only Caddy is open to the internet; the database and queue are sealed inside,
which keeps your data safe.

---

## What you need before starting

1. A **Hostinger VPS** — the **KVM 2 plan** (8 GB RAM, 2 CPUs) is the right
   starting size; it costs roughly $8–13/month. Choose **Ubuntu 24.04** as the
   operating system, and pick the **Docker** template if Hostinger offers it
   (it pre-installs the container software).
2. A **domain name** (e.g. `yourbrand.com`).
3. The **project code** in a Git repository your developer can access.
4. A **Meta / WhatsApp Business** account with an app created (the slow part —
   start it early).

---

## Step 1 — Point your domain at the server

In your domain provider's DNS settings, create two **A records** pointing at the
VPS's IP address (Hostinger shows you the IP):

| Type | Name  | Value (points to) |
|------|-------|-------------------|
| A    | `app` | your VPS IP       |
| A    | `api` | your VPS IP       |

So `app.yourbrand.com` is the dashboard and `api.yourbrand.com` is the backend.

---

## Step 2 — Get onto the server (developer)

```bash
ssh root@YOUR_VPS_IP
```

If the Docker template wasn't used, install it once:

```bash
curl -fsSL https://get.docker.com | sh
```

Lock down the firewall so only web traffic and SSH are open:

```bash
ufw allow 22 && ufw allow 80 && ufw allow 443 && ufw --force enable
```

---

## Step 3 — Get the code and settings onto the server (developer)

```bash
mkdir -p /opt/wa-saas && cd /opt/wa-saas
git clone YOUR_REPO_URL .
cp deploy/.env.example .env
nano .env          # fill in every value (see below)
```

The `.env` file is the one place all your secrets and settings live. The
important ones to fill in:

- **APP_DOMAIN / API_DOMAIN** — your two domains from Step 1
- **POSTGRES_PASSWORD** — a long random password
- **JWT secrets / ENCRYPTION_KEY** — random strings (the file shows how to
  generate them)
- **META_APP_ID / META_APP_SECRET** — from your Meta app dashboard
- **WHATSAPP_WEBHOOK_VERIFY_TOKEN** — any secret word you choose (you'll paste
  the same word into Meta in Step 5)

---

## Step 4 — Start everything (developer)

First time only, create the database tables:

```bash
cd /opt/wa-saas
# if the project already has prisma migrations committed, the api does this
# automatically on boot. For a brand-new database with none yet:
docker compose -f deploy/docker-compose.yml run --rm api npx prisma db push
```

Then bring it all up:

```bash
docker compose -f deploy/docker-compose.yml up -d --build
```

Caddy automatically fetches HTTPS certificates within a minute. Visit
`https://app.yourbrand.com` — the inbox should load.

Check everything is running:

```bash
docker compose -f deploy/docker-compose.yml ps
```

---

## Step 5 — Connect Meta to your server

In your Meta app's WhatsApp webhook settings:

- **Callback URL:** `https://api.yourbrand.com/webhooks/whatsapp`
- **Verify token:** the same word you put in `WHATSAPP_WEBHOOK_VERIFY_TOKEN`
- Subscribe to the **messages** field.

Meta will ping the URL to verify it; if your server is up, it passes instantly.
From then on, every incoming WhatsApp message flows into your inbox live.

---

## Step 6 — Test it

Send a WhatsApp message to your connected number. It should appear in the inbox
within a second or two. Reply from the inbox; the customer gets it on WhatsApp.
That's the full loop working.

---

## Keeping it running

**Backups (do this on day one).** A daily database backup script is included:

```bash
crontab -e
# add this line:
0 3 * * * cd /opt/wa-saas/deploy && ./backup.sh >> /var/log/wa-backup.log 2>&1
```

**Updates.** When your developer ships improvements:

```bash
cd /opt/wa-saas && git pull
docker compose -f deploy/docker-compose.yml up -d --build
```

**Logs (if something misbehaves):**

```bash
docker compose -f deploy/docker-compose.yml logs -f api
```

---

## When to move off a single VPS

This setup comfortably serves your first tens of customers. Signs it's time to
upgrade: the inbox feels slow, messages queue up, or you're storing a lot of
media. At that point your developer moves the database and queue to managed
services and runs more copies of the app — but you don't need any of that to
launch, and you'll have revenue by then to pay for it.

---

## What to hand your developer

Point them at this folder (`deploy/`) and the schema/code we generated. A capable
developer can read this, fill in the gaps (auth screens, the remaining inbox
polish), and get you live. If they can't engage with this, that tells you
something useful about whether to hire them.
