# Hand-off: deploy the WhatsApp platform to a Hostinger VPS

**For:** the developer/freelancer doing the deploy.
**Scale:** ~10–15 business customers (light load — one VPS is plenty).

## What you're getting
A validated code foundation for a multi-tenant WhatsApp Business platform, split
into modules (each a zip), plus the infrastructure to run it:

- Backend modules (NestJS): WhatsApp Cloud API, team inbox + realtime, campaigns,
  billing/metering, CRM, auth/RBAC/tenancy, AI agent, automation flows.
- Frontend (Next.js 15) feature components for each of the above + auth.
- `schema.prisma` (45 models), `rls_policies.sql`, and this `deploy/` folder
  (docker-compose, Dockerfiles, Caddy for auto-HTTPS, backup script, `.env.example`).

## Read this first — the honest state of the code
Each module was generated and **syntax-validated independently**. They have
**never been compiled or run together**, and there is no assembled repo, no
`package.json`, and no `npm install` yet. **Your first job is assembly**, and the
first real build will surface cross-module fixes. This is expected.

## Target server
Hostinger **KVM 2 VPS, Ubuntu 24.04**, Docker pre-installed. (It was created from
the n8n template — n8n is running and can be stopped/removed; it's unrelated.)

## Steps, in order
1. **Assemble two projects.**
   - **Backend:** merge all `src/*` modules into one NestJS app; add `package.json`,
     `tsconfig.json`, `nest-cli.json`; install dependencies (incl. `@nestjs/*`,
     `prisma`/`@prisma/client`, `bullmq`, `ioredis`, `@nestjs/jwt`, `bcryptjs`,
     `class-validator`, `socket.io`). Get `nest build` green.
   - **Frontend (`web/`):** standard Next.js 15 app; add `package.json`,
     `next.config`, Tailwind + shadcn/ui setup; deps incl. `recharts`, `reactflow`,
     `lucide-react`. Get `next build` green.
2. **Place `deploy/` at the repo root** (next to `src/` and `web/`).
3. **Create `.env`** from `deploy/.env.example` and fill the required values
   (domains, DB, Redis, `JWT_ACCESS_SECRET`, `ENCRYPTION_KEY`, Meta app id/secret,
   webhook verify token). AI/Razorpay/S3 are optional until those features go live.
4. **DNS:** point `app.` and `api.` A-records at the VPS IP.
5. **Deploy:** on the VPS, `docker compose -f deploy/docker-compose.yml up -d --build`.
   This builds the images, runs `prisma migrate deploy`, starts Postgres, Redis,
   API, web, and Caddy. Caddy auto-issues HTTPS for both domains.
6. **Verify:** `https://api.<domain>/health` responds, and `https://app.<domain>`
   loads the login page; register an account and confirm it works.
7. **Meta setup (with the owner):** create/verify the Meta app, set the webhook
   callback to `https://api.<domain>/webhooks/whatsapp` with the verify token,
   configure embedded signup with the app id/secret, and submit for App Review +
   Business Verification.

## Things to wire (flagged, so they're not surprises)
- **Health endpoint:** add `GET /health` if not present (compose expects it).
- **Workers:** the BullMQ processors run inside the API by default — fine at this
  scale. For higher volume, uncomment the `worker` service in `docker-compose.yml`
  (it runs `node dist/worker.js`).
- **Row-level security:** tenant isolation is **already enforced at the app layer**
  (Prisma middleware). `rls_policies.sql` is **optional** database-level hardening
  that uses `FORCE` RLS + a per-request session variable — **do not apply it until
  you wire `app.current_org_id` per request** (the `forTenant` helper), or it will
  block all queries.
- **Media storage:** `StorageService.putObject` is a stub — implement S3 (or local)
  before using image/file features.
- **Payments:** Razorpay order creation is a stub; finish it + set the webhook to
  `https://api.<domain>/billing/webhook/razorpay` for live billing.
- **AI knowledge:** retrieval is keyword-based; swap to embeddings later if needed.
- **Message rates:** `billing` ships a sample rate card — replace with Meta's real
  per-message rates.

## Backups
`deploy/backup.sh` dumps Postgres; add it to cron (daily) and copy off-server.

## What "done" looks like
On your domains, over HTTPS: a user registers, connects a WhatsApp number, sees a
working team inbox (send/receive in real time), and can run a broadcast. Everything
else (AI, flows, billing) is then switched on as needed.

## Rough effort
Assembly + first deploy to a working staging site: a few days for an experienced
full-stack developer. Finishing the stubs and getting through Meta review is
additional, partly gated by Meta's own timelines.
