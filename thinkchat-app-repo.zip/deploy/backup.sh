#!/bin/sh
# Daily PostgreSQL backup. Schedule with: crontab -e
#   0 3 * * * cd /opt/wa-saas/deploy && ./backup.sh >> /var/log/wa-backup.log 2>&1
set -e
. ../.env
DIR="/root/wa-backups"
mkdir -p "$DIR"
STAMP=$(date +%F-%H%M)
docker compose exec -T postgres pg_dump -U "$POSTGRES_USER" "$POSTGRES_DB" \
  | gzip > "$DIR/db-$STAMP.sql.gz"
# keep the 14 most recent backups
ls -1t "$DIR"/db-*.sql.gz | tail -n +15 | xargs -r rm
echo "backup done: db-$STAMP.sql.gz"
