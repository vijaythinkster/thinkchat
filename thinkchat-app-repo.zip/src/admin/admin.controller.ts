import {
  Body, Controller, Get, Param, Patch, Post, Query, Req, UseGuards,
} from '@nestjs/common';
import { PlatformAdminGuard } from './guards/platform-admin.guard';
import { AdminService, ActorCtx } from './admin.service';
import { PlansService } from './plans.service';
import { CouponsService } from './coupons.service';
import {
  CreateCouponDto, CreatePlanDto, ImpersonateDto, ListAuditDto, ListOrgsDto,
  ListUsersDto, SetActiveDto, SetSuperAdminDto, SuspendOrgDto, UpdateCouponDto,
  UpdatePlanDto, UsageQueryDto,
} from './dto/admin.dto';

function actor(req: any): ActorCtx {
  return {
    userId: req.user?.userId,
    orgId: req.user?.organizationId,
    ip: req.ip,
    userAgent: req.headers?.['user-agent'],
  };
}

@Controller('admin')
@UseGuards(PlatformAdminGuard)
export class AdminController {
  constructor(
    private readonly admin: AdminService,
    private readonly plans: PlansService,
    private readonly coupons: CouponsService,
  ) {}

  @Get('overview')
  overview() {
    return this.admin.overview();
  }

  // ---- organizations ----
  @Get('organizations')
  listOrgs(@Query() q: ListOrgsDto) {
    return this.admin.listOrganizations(q);
  }

  @Get('organizations/:id')
  getOrg(@Param('id') id: string) {
    return this.admin.getOrganization(id);
  }

  @Post('organizations/:id/suspend')
  suspend(@Param('id') id: string, @Body() dto: SuspendOrgDto, @Req() req: any) {
    return this.admin.suspendOrganization(id, dto.reason, actor(req));
  }

  @Post('organizations/:id/reactivate')
  reactivate(@Param('id') id: string, @Req() req: any) {
    return this.admin.reactivateOrganization(id, actor(req));
  }

  @Post('organizations/:id/impersonate')
  impersonate(@Param('id') id: string, @Body() dto: ImpersonateDto, @Req() req: any) {
    return this.admin.impersonate(id, dto, actor(req));
  }

  // ---- users ----
  @Get('users')
  listUsers(@Query() q: ListUsersDto) {
    return this.admin.listUsers(q);
  }

  @Post('users/:id/active')
  setActive(@Param('id') id: string, @Body() dto: SetActiveDto, @Req() req: any) {
    return this.admin.setUserActive(id, dto.isActive, actor(req));
  }

  @Post('users/:id/super-admin')
  setSuperAdmin(@Param('id') id: string, @Body() dto: SetSuperAdminDto, @Req() req: any) {
    return this.admin.setSuperAdmin(id, dto.enabled, actor(req));
  }

  // ---- usage / revenue ----
  @Get('usage')
  usage(@Query() q: UsageQueryDto) {
    return this.admin.platformUsage(q);
  }

  // ---- plans ----
  @Get('plans')
  listPlans() {
    return this.plans.list();
  }

  @Post('plans')
  createPlan(@Body() dto: CreatePlanDto, @Req() req: any) {
    return this.plans.create(dto, actor(req));
  }

  @Patch('plans/:id')
  updatePlan(@Param('id') id: string, @Body() dto: UpdatePlanDto, @Req() req: any) {
    return this.plans.update(id, dto, actor(req));
  }

  // ---- coupons ----
  @Get('coupons')
  listCoupons() {
    return this.coupons.list();
  }

  @Post('coupons')
  createCoupon(@Body() dto: CreateCouponDto, @Req() req: any) {
    return this.coupons.create(dto, actor(req));
  }

  @Patch('coupons/:id')
  updateCoupon(@Param('id') id: string, @Body() dto: UpdateCouponDto, @Req() req: any) {
    return this.coupons.update(id, dto, actor(req));
  }

  // ---- audit ----
  @Get('audit-logs')
  audit(@Query() q: ListAuditDto) {
    return this.admin.auditLogs(q);
  }
}
