import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { AdminController } from './admin.controller';
import { AdminService } from './admin.service';
import { PlansService } from './plans.service';
import { CouponsService } from './coupons.service';
import { PlatformAdminGuard } from './guards/platform-admin.guard';

/**
 * Phase 12 — platform super-admin console. Cross-tenant; every route is gated by
 * PlatformAdminGuard which verifies the caller is a super-admin and switches on
 * tenant-scope bypass for the request. JwtModule is imported so impersonation
 * tokens can be signed with the same access-token secret as the auth module.
 */
@Module({
  imports: [
    JwtModule.register({
      secret: process.env.JWT_ACCESS_SECRET,
      signOptions: { expiresIn: '15m' },
    }),
  ],
  controllers: [AdminController],
  providers: [AdminService, PlansService, CouponsService, PlatformAdminGuard],
})
export class AdminModule {}
