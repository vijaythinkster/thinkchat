import { Injectable, NotFoundException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InvoiceStatus, Prisma, SubscriptionStatus } from '@prisma/client';
import { PrismaService } from 'src/common/prisma/prisma.service';
import {
  ImpersonateDto, ListAuditDto, ListOrgsDto, ListUsersDto, UsageQueryDto,
} from './dto/admin.dto';

/**
 * Platform-operator service. Every method here runs with tenant-scoping
 * bypassed (PlatformAdminGuard), so reads/writes span all organizations.
 * Mutations are written to AuditLog for accountability.
 */
@Injectable()
export class AdminService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwt: JwtService,
  ) {}

  // ----------------------------------------------------------------- overview
  async overview() {
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const last30 = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

    const [
      totalOrgs, suspendedOrgs, totalUsers, connectedNumbers,
      activeSubs, messages30d, usageAgg, paidThisMonth,
    ] = await Promise.all([
      this.prisma.organization.count({ where: { deletedAt: null } }),
      this.prisma.organization.count({ where: { deletedAt: null, suspendedAt: { not: null } } }),
      this.prisma.user.count({ where: { deletedAt: null } }),
      this.prisma.whatsAppNumber.count({ where: { status: 'CONNECTED' } }),
      this.prisma.subscription.findMany({
        where: { status: SubscriptionStatus.ACTIVE },
        select: { plan: { select: { priceMonthly: true, currency: true } } },
      }),
      this.prisma.message.count({ where: { createdAt: { gte: last30 } } }),
      this.prisma.usageRecord.aggregate({
        where: { periodStart: { gte: monthStart } },
        _sum: { metaCost: true, billedCost: true, quantity: true },
      }),
      this.prisma.invoice.aggregate({
        where: { status: InvoiceStatus.PAID, paidAt: { gte: monthStart } },
        _sum: { total: true },
      }),
    ]);

    const mrr = activeSubs.reduce((s, x) => s + Number(x.plan?.priceMonthly ?? 0), 0);
    const metaCost = Number(usageAgg._sum.metaCost ?? 0);
    const billed = Number(usageAgg._sum.billedCost ?? 0);

    return {
      organizations: { total: totalOrgs, suspended: suspendedOrgs, active: totalOrgs - suspendedOrgs },
      users: totalUsers,
      connectedNumbers,
      messagesLast30d: messages30d,
      mrr,
      revenueThisMonth: Number(paidThisMonth._sum.total ?? 0),
      messagingThisMonth: {
        metaCost, billed, margin: billed - metaCost,
        marginPct: billed > 0 ? Math.round(((billed - metaCost) / billed) * 100) : 0,
        messages: usageAgg._sum.quantity ?? 0,
      },
    };
  }

  // ------------------------------------------------------------ organizations
  async listOrganizations(q: ListOrgsDto) {
    const limit = q.limit ?? 25;
    const where: Prisma.OrganizationWhereInput = {};
    if (q.status === 'deleted') where.deletedAt = { not: null };
    else if (q.status === 'suspended') { where.deletedAt = null; where.suspendedAt = { not: null }; }
    else if (q.status === 'active') { where.deletedAt = null; where.suspendedAt = null; }
    else where.deletedAt = null;

    if (q.search) {
      where.OR = [
        { name: { contains: q.search, mode: 'insensitive' } },
        { slug: { contains: q.search, mode: 'insensitive' } },
      ];
    }

    const rows = await this.prisma.organization.findMany({
      where,
      include: {
        _count: { select: { users: true, whatsAppNumbers: true, contacts: true } },
        subscriptions: {
          where: { status: { in: [SubscriptionStatus.ACTIVE, SubscriptionStatus.TRIALING] } },
          include: { plan: { select: { tier: true, name: true, priceMonthly: true, currency: true } } },
          take: 1,
          orderBy: { createdAt: 'desc' },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: limit + 1,
      ...(q.cursor ? { cursor: { id: q.cursor }, skip: 1 } : {}),
    });

    const hasMore = rows.length > limit;
    const page = hasMore ? rows.slice(0, limit) : rows;

    const items = page.map((o) => {
      const sub = o.subscriptions[0];
      return {
        id: o.id,
        name: o.name,
        slug: o.slug,
        isAgency: o.parentId === null && false, // parentId null = top-level; agencies have children
        createdAt: o.createdAt,
        suspendedAt: o.suspendedAt,
        deletedAt: o.deletedAt,
        counts: o._count,
        plan: sub?.plan ? { tier: sub.plan.tier, name: sub.plan.name, priceMonthly: Number(sub.plan.priceMonthly), currency: sub.plan.currency } : null,
        subscriptionStatus: sub?.status ?? null,
      };
    });

    return { items, nextCursor: hasMore ? page[page.length - 1].id : null };
  }

  async getOrganization(orgId: string) {
    const org = await this.prisma.organization.findFirst({
      where: { id: orgId },
      include: {
        _count: { select: { users: true, whatsAppNumbers: true, contacts: true, campaigns: true, conversations: true } },
        subscriptions: { include: { plan: true, coupon: true }, orderBy: { createdAt: 'desc' }, take: 5 },
        children: { select: { id: true, name: true, slug: true } },
      },
    });
    if (!org) throw new NotFoundException('Organization not found');

    const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    const [usage, recentInvoices, numbers] = await Promise.all([
      this.prisma.usageRecord.aggregate({
        where: { organizationId: orgId, periodStart: { gte: monthStart } },
        _sum: { metaCost: true, billedCost: true, quantity: true },
      }),
      this.prisma.invoice.findMany({
        where: { organizationId: orgId },
        orderBy: { createdAt: 'desc' }, take: 10,
        select: { id: true, number: true, status: true, total: true, currency: true, issuedAt: true, paidAt: true },
      }),
      this.prisma.whatsAppNumber.findMany({
        where: { organizationId: orgId },
        select: { id: true, displayPhone: true, verifiedName: true, status: true, qualityRating: true },
      }),
    ]);

    const metaCost = Number(usage._sum.metaCost ?? 0);
    const billed = Number(usage._sum.billedCost ?? 0);
    return {
      organization: {
        id: org.id, name: org.name, slug: org.slug, parentId: org.parentId,
        timezone: org.timezone, locale: org.locale, createdAt: org.createdAt,
        suspendedAt: org.suspendedAt, suspendedReason: org.suspendedReason, deletedAt: org.deletedAt,
      },
      counts: org._count,
      children: org.children,
      subscriptions: org.subscriptions,
      numbers,
      usageThisMonth: { metaCost, billed, margin: billed - metaCost, messages: usage._sum.quantity ?? 0 },
      recentInvoices,
    };
  }

  async suspendOrganization(orgId: string, reason: string | undefined, actor: ActorCtx) {
    await this.ensureOrg(orgId);
    const org = await this.prisma.organization.update({
      where: { id: orgId },
      data: { suspendedAt: new Date(), suspendedReason: reason ?? null },
    });
    await this.audit(actor, orgId, 'platform.org.suspend', 'Organization', orgId, { reason });
    return { id: org.id, suspendedAt: org.suspendedAt, suspendedReason: org.suspendedReason };
  }

  async reactivateOrganization(orgId: string, actor: ActorCtx) {
    await this.ensureOrg(orgId);
    const org = await this.prisma.organization.update({
      where: { id: orgId },
      data: { suspendedAt: null, suspendedReason: null },
    });
    await this.audit(actor, orgId, 'platform.org.reactivate', 'Organization', orgId, {});
    return { id: org.id, suspendedAt: null };
  }

  // -------------------------------------------------------------------- users
  async listUsers(q: ListUsersDto) {
    const limit = q.limit ?? 25;
    const where: Prisma.UserWhereInput = { deletedAt: null };
    if (q.organizationId) where.organizationId = q.organizationId;
    if (q.search) where.email = { contains: q.search, mode: 'insensitive' };

    const rows = await this.prisma.user.findMany({
      where,
      select: {
        id: true, email: true, firstName: true, lastName: true, isActive: true,
        isSuperAdmin: true, lastLoginAt: true, createdAt: true,
        organization: { select: { id: true, name: true, slug: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: limit + 1,
      ...(q.cursor ? { cursor: { id: q.cursor }, skip: 1 } : {}),
    });
    const hasMore = rows.length > limit;
    const items = hasMore ? rows.slice(0, limit) : rows;
    return { items, nextCursor: hasMore ? items[items.length - 1].id : null };
  }

  async setUserActive(userId: string, isActive: boolean, actor: ActorCtx) {
    const user = await this.prisma.user.findFirst({ where: { id: userId }, select: { id: true, organizationId: true } });
    if (!user) throw new NotFoundException('User not found');
    await this.prisma.user.update({ where: { id: userId }, data: { isActive } });
    await this.audit(actor, user.organizationId, isActive ? 'platform.user.enable' : 'platform.user.disable', 'User', userId, {});
    return { id: userId, isActive };
  }

  async setSuperAdmin(userId: string, enabled: boolean, actor: ActorCtx) {
    const user = await this.prisma.user.findFirst({ where: { id: userId }, select: { id: true, organizationId: true } });
    if (!user) throw new NotFoundException('User not found');
    await this.prisma.user.update({ where: { id: userId }, data: { isSuperAdmin: enabled } });
    await this.audit(actor, user.organizationId, enabled ? 'platform.superadmin.grant' : 'platform.superadmin.revoke', 'User', userId, {});
    return { id: userId, isSuperAdmin: enabled };
  }

  /**
   * Mint a short-lived access token to log in AS a tenant user for support.
   * The token carries `impersonatedBy` so downstream actions are attributable.
   * No refresh token is issued — impersonation sessions are deliberately brief.
   */
  async impersonate(orgId: string, dto: ImpersonateDto, actor: ActorCtx) {
    const user = await this.prisma.user.findFirst({
      where: { id: dto.userId, organizationId: orgId, deletedAt: null },
      include: { userRoles: { include: { role: { include: { rolePermissions: { include: { permission: true } } } } } } },
    });
    if (!user) throw new NotFoundException('User not found in that organization');

    const permissions = Array.from(new Set(
      user.userRoles.flatMap((ur) => ur.role.rolePermissions.map((rp) => rp.permission.key)),
    ));
    const roles = user.userRoles.map((ur) => ur.role.name);

    const token = await this.jwt.signAsync(
      { sub: user.id, organizationId: orgId, permissions, roles, impersonatedBy: actor.userId },
      { expiresIn: '30m' },
    );
    await this.audit(actor, orgId, 'platform.impersonate', 'User', user.id, { minutes: 30 });
    return { accessToken: token, expiresIn: 1800, user: { id: user.id, email: user.email } };
  }

  // -------------------------------------------------------------------- usage
  async platformUsage(q: UsageQueryDto) {
    const from = q.from ? new Date(q.from) : new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    const to = q.to ? new Date(q.to) : new Date();

    const byMetric = await this.prisma.usageRecord.groupBy({
      by: ['metric'],
      where: { periodStart: { gte: from, lte: to } },
      _sum: { metaCost: true, billedCost: true, quantity: true },
    });

    const byOrg = await this.prisma.usageRecord.groupBy({
      by: ['organizationId'],
      where: { periodStart: { gte: from, lte: to } },
      _sum: { metaCost: true, billedCost: true },
      orderBy: { _sum: { billedCost: 'desc' } },
      take: 10,
    });

    const orgIds = byOrg.map((r) => r.organizationId);
    const orgs = await this.prisma.organization.findMany({
      where: { id: { in: orgIds } }, select: { id: true, name: true },
    });
    const nameOf = new Map(orgs.map((o) => [o.id, o.name]));

    return {
      range: { from, to },
      byMetric: byMetric.map((m) => ({
        metric: m.metric,
        metaCost: Number(m._sum.metaCost ?? 0),
        billed: Number(m._sum.billedCost ?? 0),
        margin: Number(m._sum.billedCost ?? 0) - Number(m._sum.metaCost ?? 0),
        quantity: m._sum.quantity ?? 0,
      })),
      topOrgsBySpend: byOrg.map((r) => ({
        organizationId: r.organizationId,
        name: nameOf.get(r.organizationId) ?? r.organizationId,
        metaCost: Number(r._sum.metaCost ?? 0),
        billed: Number(r._sum.billedCost ?? 0),
      })),
    };
  }

  // ------------------------------------------------------------------- audit
  async auditLogs(q: ListAuditDto) {
    const limit = q.limit ?? 50;
    const where: Prisma.AuditLogWhereInput = {};
    if (q.organizationId) where.organizationId = q.organizationId;
    if (q.userId) where.userId = q.userId;
    if (q.action) where.action = { contains: q.action };
    if (q.from || q.to) where.createdAt = { ...(q.from ? { gte: new Date(q.from) } : {}), ...(q.to ? { lte: new Date(q.to) } : {}) };

    const rows = await this.prisma.auditLog.findMany({
      where,
      include: { user: { select: { email: true } }, organization: { select: { name: true } } },
      orderBy: { createdAt: 'desc' },
      take: limit + 1,
      ...(q.cursor ? { cursor: { id: q.cursor }, skip: 1 } : {}),
    });
    const hasMore = rows.length > limit;
    const items = hasMore ? rows.slice(0, limit) : rows;
    return { items, nextCursor: hasMore ? items[items.length - 1].id : null };
  }

  // ----------------------------------------------------------------- helpers
  private async ensureOrg(orgId: string) {
    const o = await this.prisma.organization.findFirst({ where: { id: orgId }, select: { id: true } });
    if (!o) throw new NotFoundException('Organization not found');
  }

  private audit(actor: ActorCtx, orgId: string, action: string, entityType: string, entityId: string, metadata: Record<string, unknown>) {
    return this.prisma.auditLog.create({
      data: {
        organizationId: orgId,
        userId: actor.userId,
        action,
        entityType,
        entityId,
        metadata: metadata as Prisma.InputJsonValue,
        ipAddress: actor.ip,
        userAgent: actor.userAgent,
      },
    });
  }
}

export interface ActorCtx {
  userId: string;
  orgId: string; // acting admin's home org (used for platform-global audit rows)
  ip?: string;
  userAgent?: string;
}
