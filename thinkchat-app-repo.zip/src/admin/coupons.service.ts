import { Injectable, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { CreateCouponDto, UpdateCouponDto } from './dto/admin.dto';
import type { ActorCtx } from './admin.service';

/** Global discount coupons (not tenant-scoped). */
@Injectable()
export class CouponsService {
  constructor(private readonly prisma: PrismaService) {}

  list() {
    return this.prisma.coupon.findMany({
      include: { _count: { select: { subscriptions: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async create(dto: CreateCouponDto, actor: ActorCtx) {
    const coupon = await this.prisma.coupon.create({
      data: {
        code: dto.code.toUpperCase(),
        percentOff: dto.percentOff,
        amountOff: dto.amountOff,
        currency: dto.currency,
        maxRedemptions: dto.maxRedemptions,
        expiresAt: dto.expiresAt ? new Date(dto.expiresAt) : null,
      },
    });
    await this.audit(actor, 'platform.coupon.create', coupon.id, { code: coupon.code });
    return coupon;
  }

  async update(id: string, dto: UpdateCouponDto, actor: ActorCtx) {
    const exists = await this.prisma.coupon.findUnique({ where: { id }, select: { id: true } });
    if (!exists) throw new NotFoundException('Coupon not found');
    const coupon = await this.prisma.coupon.update({
      where: { id },
      data: {
        ...(dto.isActive !== undefined ? { isActive: dto.isActive } : {}),
        ...(dto.maxRedemptions !== undefined ? { maxRedemptions: dto.maxRedemptions } : {}),
        ...(dto.expiresAt !== undefined ? { expiresAt: dto.expiresAt ? new Date(dto.expiresAt) : null } : {}),
      },
    });
    await this.audit(actor, 'platform.coupon.update', id, { ...dto });
    return coupon;
  }

  private audit(actor: ActorCtx, action: string, entityId: string, metadata: Record<string, unknown>) {
    return this.prisma.auditLog.create({
      data: {
        organizationId: actor.orgId, userId: actor.userId, action,
        entityType: 'Coupon', entityId, metadata: metadata as Prisma.InputJsonValue,
        ipAddress: actor.ip, userAgent: actor.userAgent,
      },
    });
  }
}
