import {
  IsArray, IsBoolean, IsInt, IsISO8601, IsNumberString, IsOptional,
  IsString, Max, Min, MinLength,
} from 'class-validator';
import { Type } from 'class-transformer';

export class ListOrgsDto {
  @IsOptional() @IsString() search?: string;
  @IsOptional() @IsString() status?: 'active' | 'suspended' | 'deleted';
  @IsOptional() @IsString() planTier?: string;
  @IsOptional() @IsString() cursor?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(100) limit?: number;
}

export class SuspendOrgDto {
  @IsOptional() @IsString() reason?: string;
}

export class ImpersonateDto {
  @IsString() userId!: string;
}

export class SetActiveDto {
  @IsBoolean() isActive!: boolean;
}

export class SetSuperAdminDto {
  @IsBoolean() enabled!: boolean;
}

export class ListUsersDto {
  @IsOptional() @IsString() search?: string;
  @IsOptional() @IsString() organizationId?: string;
  @IsOptional() @IsString() cursor?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(100) limit?: number;
}

export class ListAuditDto {
  @IsOptional() @IsString() organizationId?: string;
  @IsOptional() @IsString() userId?: string;
  @IsOptional() @IsString() action?: string;
  @IsOptional() @IsISO8601() from?: string;
  @IsOptional() @IsISO8601() to?: string;
  @IsOptional() @IsString() cursor?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(200) limit?: number;
}

export class UsageQueryDto {
  @IsOptional() @IsISO8601() from?: string;
  @IsOptional() @IsISO8601() to?: string;
}

export class CreatePlanDto {
  @IsString() tier!: string; // PlanTier enum value
  @IsString() @MinLength(1) name!: string;
  @IsOptional() @IsString() description?: string;
  @IsNumberString() priceMonthly!: string;
  @IsNumberString() priceYearly!: string;
  @IsOptional() @IsString() currency?: string;
  limits!: Record<string, unknown>;
  features!: Record<string, unknown>;
}

export class UpdatePlanDto {
  @IsOptional() @IsString() name?: string;
  @IsOptional() @IsString() description?: string;
  @IsOptional() @IsNumberString() priceMonthly?: string;
  @IsOptional() @IsNumberString() priceYearly?: string;
  @IsOptional() limits?: Record<string, unknown>;
  @IsOptional() features?: Record<string, unknown>;
  @IsOptional() @IsBoolean() isActive?: boolean;
}

export class CreateCouponDto {
  @IsString() @MinLength(1) code!: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(100) percentOff?: number;
  @IsOptional() @IsNumberString() amountOff?: string;
  @IsOptional() @IsString() currency?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) maxRedemptions?: number;
  @IsOptional() @IsISO8601() expiresAt?: string;
}

export class UpdateCouponDto {
  @IsOptional() @IsBoolean() isActive?: boolean;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) maxRedemptions?: number;
  @IsOptional() @IsISO8601() expiresAt?: string;
}
