import {
  CanActivate, ExecutionContext, ForbiddenException, Injectable,
} from '@nestjs/common';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { enterTenantContext, getTenantContext } from 'src/common/tenant/request-context';

/**
 * Gate for the cross-tenant platform console. Runs AFTER the global JwtAuthGuard
 * (so req.user + tenant context already exist). It confirms the caller is a
 * platform super-admin, then flips on `bypassTenantScope` for the rest of the
 * request so admin queries see every organization instead of just the caller's.
 *
 * Put `isSuperAdmin` in the JWT claims to skip the DB lookup on the hot path;
 * the DB fallback keeps it correct if the claim is absent.
 */
@Injectable()
export class PlatformAdminGuard implements CanActivate {
  constructor(private readonly prisma: PrismaService) {}

  async canActivate(ctx: ExecutionContext): Promise<boolean> {
    const req = ctx.switchToHttp().getRequest();
    const user = req.user;
    if (!user?.userId) throw new ForbiddenException('Not authenticated');

    let isSuperAdmin = user.isSuperAdmin === true;
    if (!isSuperAdmin) {
      // Fallback lookup. Scoped to the caller's own org by the tenant middleware,
      // which is exactly where their own user row lives — so this resolves safely.
      const row = await this.prisma.user.findFirst({
        where: { id: user.userId },
        select: { isSuperAdmin: true },
      });
      isSuperAdmin = row?.isSuperAdmin === true;
    }
    if (!isSuperAdmin) throw new ForbiddenException('Platform administrators only');

    const current = getTenantContext();
    enterTenantContext({
      userId: user.userId,
      organizationId: current?.organizationId ?? user.organizationId,
      permissions: current?.permissions ?? [],
      roles: current?.roles ?? [],
      bypassTenantScope: true,
    });
    return true;
  }
}
