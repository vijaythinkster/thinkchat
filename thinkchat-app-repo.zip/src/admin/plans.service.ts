import { Injectable, NotFoundException } from '@nestjs/common';
import { PlanTier, Prisma } from '@prisma/client';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { CreatePlanDto, UpdatePlanDto } from './dto/admin.dto';
import type { ActorCtx } from './admin.service';

/** Global pricing-plan catalogue (not tenant-scoped). */
@Injectable()
export class PlansService {
  constructor(private readonly prisma: PrismaService) {}

  list() {
    return this.prisma.plan.findMany({
      include: { _count: { select: { subscriptions: true } } },
      orderBy: { priceMonthly: 'asc' },
    });
  }

  async create(dto: CreatePlanDto, actor: ActorCtx) {
    const plan = await this.prisma.plan.create({
      data: {
        tier: dto.tier as PlanTier,
        name: dto.name,
        description: dto.description,
        priceMonthly: dto.priceMonthly,
        priceYearly: dto.priceYearly,
        currency: dto.currency ?? 'USD',
        limits: dto.limits as Prisma.InputJsonValue,
        features: dto.features as Prisma.InputJsonValue,
      },
    });
    await this.audit(actor, 'platform.plan.create', plan.id, { tier: plan.tier });
    return plan;
  }

  async update(id: string, dto: UpdatePlanDto, actor: ActorCtx) {
    const exists = await this.prisma.plan.findUnique({ where: { id }, select: { id: true } });
    if (!exists) throw new NotFoundException('Plan not found');
    const plan = await this.prisma.plan.update({
      where: { id },
      data: {
        ...(dto.name !== undefined ? { name: dto.name } : {}),
        ...(dto.description !== undefined ? { description: dto.description } : {}),
        ...(dto.priceMonthly !== undefined ? { priceMonthly: dto.priceMonthly } : {}),
        ...(dto.priceYearly !== undefined ? { priceYearly: dto.priceYearly } : {}),
        ...(dto.limits !== undefined ? { limits: dto.limits as Prisma.InputJsonValue } : {}),
        ...(dto.features !== undefined ? { features: dto.features as Prisma.InputJsonValue } : {}),
        ...(dto.isActive !== undefined ? { isActive: dto.isActive } : {}),
      },
    });
    await this.audit(actor, 'platform.plan.update', id, { ...dto });
    return plan;
  }

  private audit(actor: ActorCtx, action: string, entityId: string, metadata: Record<string, unknown>) {
    return this.prisma.auditLog.create({
      data: {
        organizationId: actor.orgId, userId: actor.userId, action,
        entityType: 'Plan', entityId, metadata: metadata as Prisma.InputJsonValue,
        ipAddress: actor.ip, userAgent: actor.userAgent,
      },
    });
  }
}
