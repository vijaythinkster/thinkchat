import { Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { JOB, QUEUE, RunInferenceJob } from 'src/whatsapp/queue/queue.constants';

interface MessageReceivedEvent {
  organizationId: string;
  conversationId: string;
  messageId: string;
}

/**
 * Bridges inbound messages to AI inference. Listens for the same event the inbox
 * gateway uses; if the org has an active assistant, it enqueues an inference job.
 * The worker re-checks human assignment, so this stays a thin trigger.
 */
@Injectable()
export class AITriggerListener {
  constructor(
    private readonly prisma: PrismaService,
    @InjectQueue(QUEUE.AI_INFERENCE) private readonly queue: Queue<RunInferenceJob>,
  ) {}

  @OnEvent('whatsapp.message.received')
  async onInbound(evt: MessageReceivedEvent) {
    const assistant = await this.prisma.aIAssistant.findFirst({
      where: { organizationId: evt.organizationId, isActive: true, deletedAt: null },
      select: { id: true },
    });
    if (!assistant) return;
    await this.queue.add(
      JOB.RUN_INFERENCE,
      { organizationId: evt.organizationId, conversationId: evt.conversationId, messageId: evt.messageId, assistantId: assistant.id },
      { attempts: 3, backoff: { type: 'exponential', delay: 3000 }, removeOnComplete: 200 },
    );
  }
}
