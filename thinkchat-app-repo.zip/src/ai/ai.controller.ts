import { Body, Controller, Delete, Get, Param, Patch, Post } from '@nestjs/common';
import { OrgId } from 'src/common/tenant/org-id.decorator';
import { RequirePermissions } from 'src/auth/decorators/permissions.decorator';
import { AIService } from './ai.service';
import { KnowledgeService } from './knowledge.service';
import {
  AddKnowledgeDto, CreateAssistantDto, TestAssistantDto, UpdateAssistantDto,
} from './dto/ai.dto';

@Controller('ai/assistants')
@RequirePermissions('ai.manage')
export class AIController {
  constructor(
    private readonly ai: AIService,
    private readonly knowledge: KnowledgeService,
  ) {}

  @Get()
  list(@OrgId() orgId: string) { return this.ai.list(orgId); }

  @Post()
  create(@OrgId() orgId: string, @Body() dto: CreateAssistantDto) { return this.ai.create(orgId, dto); }

  @Get(':id')
  get(@OrgId() orgId: string, @Param('id') id: string) { return this.ai.get(orgId, id); }

  @Patch(':id')
  update(@OrgId() orgId: string, @Param('id') id: string, @Body() dto: UpdateAssistantDto) {
    return this.ai.update(orgId, id, dto);
  }

  @Delete(':id')
  remove(@OrgId() orgId: string, @Param('id') id: string) { return this.ai.remove(orgId, id); }

  @Post(':id/test')
  test(@OrgId() orgId: string, @Param('id') id: string, @Body() dto: TestAssistantDto) {
    return this.ai.test(orgId, id, dto);
  }

  // --- knowledge base ---
  @Get(':id/knowledge')
  listKnowledge(@OrgId() orgId: string, @Param('id') id: string) { return this.knowledge.list(orgId, id); }

  @Post(':id/knowledge')
  addKnowledge(@OrgId() orgId: string, @Param('id') id: string, @Body() dto: AddKnowledgeDto) {
    return this.knowledge.add(orgId, id, dto);
  }

  @Delete(':id/knowledge/:kid')
  removeKnowledge(@OrgId() orgId: string, @Param('kid') kid: string) {
    return this.knowledge.remove(orgId, kid);
  }
}
