import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { QUEUE } from 'src/whatsapp/queue/queue.constants';
import { AIService } from './ai.service';
import { AIController } from './ai.controller';
import { KnowledgeService } from './knowledge.service';
import { AIProviderFactory } from './providers/ai-provider.factory';
import { OpenAIProvider } from './providers/openai.provider';
import { AnthropicProvider } from './providers/anthropic.provider';
import { GeminiProvider } from './providers/gemini.provider';
import { AIInferenceProcessor } from './queue/ai-inference.processor';
import { AITriggerListener } from './ai-trigger.listener';

@Module({
  imports: [
    BullModule.registerQueue({ name: QUEUE.AI_INFERENCE }, { name: QUEUE.MESSAGE_SEND }),
  ],
  controllers: [AIController],
  providers: [
    AIService, KnowledgeService, AIProviderFactory,
    OpenAIProvider, AnthropicProvider, GeminiProvider,
    AIInferenceProcessor, AITriggerListener,
  ],
  exports: [AIService, KnowledgeService],
})
export class AIModule {}
