import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { AIProviderFactory } from './providers/ai-provider.factory';
import { KnowledgeService } from './knowledge.service';
import { CreateAssistantDto, TestAssistantDto, UpdateAssistantDto } from './dto/ai.dto';

@Injectable()
export class AIService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly factory: AIProviderFactory,
    private readonly knowledge: KnowledgeService,
  ) {}

  list(organizationId: string) {
    return this.prisma.aIAssistant.findMany({
      where: { organizationId, deletedAt: null }, orderBy: { createdAt: 'desc' },
    });
  }

  async get(organizationId: string, id: string) {
    const a = await this.prisma.aIAssistant.findFirst({ where: { id, organizationId, deletedAt: null } });
    if (!a) throw new NotFoundException('Assistant not found');
    return a;
  }

  create(organizationId: string, dto: CreateAssistantDto) {
    return this.prisma.aIAssistant.create({
      data: {
        organizationId, type: dto.type, name: dto.name, provider: dto.provider, model: dto.model,
        systemPrompt: dto.systemPrompt, temperature: dto.temperature ?? 0.4,
        config: (dto.config ?? {}) as any, escalationRules: (dto.escalationRules ?? {}) as any,
      },
    });
  }

  async update(organizationId: string, id: string, dto: UpdateAssistantDto) {
    await this.get(organizationId, id);
    return this.prisma.aIAssistant.update({
      where: { id },
      data: {
        name: dto.name, provider: dto.provider, model: dto.model, systemPrompt: dto.systemPrompt,
        temperature: dto.temperature, isActive: dto.isActive,
        ...(dto.config ? { config: dto.config as any } : {}),
        ...(dto.escalationRules ? { escalationRules: dto.escalationRules as any } : {}),
      },
    });
  }

  async remove(organizationId: string, id: string) {
    await this.get(organizationId, id);
    await this.prisma.aIAssistant.update({ where: { id }, data: { deletedAt: new Date(), isActive: false } });
    return { deleted: true };
  }

  /** Synchronous one-shot used by the settings playground. */
  async test(organizationId: string, id: string, dto: TestAssistantDto) {
    const result = await this.reply(organizationId, id, dto.message);
    return result;
  }

  /** Generate a single reply from an assistant (used by the playground + flow AI nodes). */
  async reply(organizationId: string, assistantId: string, message: string) {
    const assistant = await this.get(organizationId, assistantId);
    const context = await this.knowledge.retrieve(organizationId, assistantId, message);
    const systemPrompt = context.length
      ? `${assistant.systemPrompt}\n\nRelevant knowledge:\n${context.join('\n---\n')}`
      : assistant.systemPrompt;

    const result = await this.factory.get(assistant.provider).chat({
      model: assistant.model, systemPrompt, temperature: assistant.temperature,
      messages: [{ role: 'user', content: message }],
    });
    return { reply: result.text, tokensIn: result.tokensIn, tokensOut: result.tokensOut };
  }
}
