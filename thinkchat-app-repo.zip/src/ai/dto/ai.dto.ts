import {
  IsBoolean, IsEnum, IsNumber, IsObject, IsOptional, IsString, Max, Min,
} from 'class-validator';
import { AIAssistantType, AIProvider, KnowledgeSourceType } from '@prisma/client';

export class CreateAssistantDto {
  @IsEnum(AIAssistantType) type!: AIAssistantType;
  @IsString() name!: string;
  @IsEnum(AIProvider) provider!: AIProvider;
  @IsString() model!: string;
  @IsString() systemPrompt!: string;
  @IsOptional() @IsNumber() @Min(0) @Max(1) temperature?: number;
  @IsOptional() @IsObject() config?: Record<string, unknown>;
  @IsOptional() @IsObject() escalationRules?: Record<string, unknown>;
}

export class UpdateAssistantDto {
  @IsOptional() @IsString() name?: string;
  @IsOptional() @IsEnum(AIProvider) provider?: AIProvider;
  @IsOptional() @IsString() model?: string;
  @IsOptional() @IsString() systemPrompt?: string;
  @IsOptional() @IsNumber() @Min(0) @Max(1) temperature?: number;
  @IsOptional() @IsObject() config?: Record<string, unknown>;
  @IsOptional() @IsObject() escalationRules?: Record<string, unknown>;
  @IsOptional() @IsBoolean() isActive?: boolean;
}

export class AddKnowledgeDto {
  @IsString() name!: string;
  @IsEnum(KnowledgeSourceType) sourceType!: KnowledgeSourceType;
  @IsOptional() @IsString() sourceUri?: string;
  @IsOptional() @IsString() content?: string;
}

export class TestAssistantDto {
  @IsString() message!: string;
}
