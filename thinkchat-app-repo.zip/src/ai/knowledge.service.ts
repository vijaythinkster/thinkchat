import { Injectable } from '@nestjs/common';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { AddKnowledgeDto } from './dto/ai.dto';

/**
 * Knowledge base storage + retrieval. Retrieval here is a lightweight term-overlap
 * scorer over stored chunks so it runs with zero external infra. The schema keeps a
 * `vectorRef` column for the production path: embed chunks and query a vector store
 * (pgvector or external), then swap retrieve() to use it. Flagged as a follow-up.
 */
@Injectable()
export class KnowledgeService {
  constructor(private readonly prisma: PrismaService) {}

  list(organizationId: string, assistantId: string) {
    return this.prisma.aIKnowledgeBase.findMany({
      where: { organizationId, assistantId, deletedAt: null }, orderBy: { createdAt: 'desc' },
    });
  }

  add(organizationId: string, assistantId: string, dto: AddKnowledgeDto) {
    return this.prisma.aIKnowledgeBase.create({
      data: {
        organizationId, assistantId, name: dto.name,
        sourceType: dto.sourceType, sourceUri: dto.sourceUri, content: dto.content,
      },
    });
  }

  async remove(organizationId: string, id: string) {
    await this.prisma.aIKnowledgeBase.updateMany({
      where: { id, organizationId }, data: { deletedAt: new Date() },
    });
    return { deleted: true };
  }

  /** Top-k chunks by naive term overlap with the query. */
  async retrieve(organizationId: string, assistantId: string, query: string, k = 4): Promise<string[]> {
    const entries = await this.prisma.aIKnowledgeBase.findMany({
      where: { organizationId, assistantId, deletedAt: null, content: { not: null } },
      select: { content: true },
    });
    const terms = tokenize(query);
    const scored = entries
      .map((e) => ({ content: e.content ?? '', score: overlap(terms, tokenize(e.content ?? '')) }))
      .filter((s) => s.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, k);
    return scored.map((s) => s.content);
  }
}

function tokenize(s: string): Set<string> {
  return new Set(s.toLowerCase().match(/[a-z0-9]{3,}/g) ?? []);
}
function overlap(a: Set<string>, b: Set<string>): number {
  let n = 0;
  for (const t of a) if (b.has(t)) n++;
  return n;
}
