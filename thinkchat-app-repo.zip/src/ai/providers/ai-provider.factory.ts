import { BadRequestException, Injectable } from '@nestjs/common';
import { AIProvider } from '@prisma/client';
import { ChatProvider } from './ai-provider.interface';
import { OpenAIProvider } from './openai.provider';
import { AnthropicProvider } from './anthropic.provider';
import { GeminiProvider } from './gemini.provider';

/** Resolves the configured provider for an assistant. Add new providers here only. */
@Injectable()
export class AIProviderFactory {
  private readonly registry: Record<AIProvider, ChatProvider>;

  constructor(openai: OpenAIProvider, anthropic: AnthropicProvider, gemini: GeminiProvider) {
    this.registry = {
      [AIProvider.OPENAI]: openai,
      [AIProvider.ANTHROPIC]: anthropic,
      [AIProvider.GEMINI]: gemini,
    };
  }

  get(provider: AIProvider): ChatProvider {
    const p = this.registry[provider];
    if (!p) throw new BadRequestException(`Unsupported AI provider ${provider}`);
    return p;
  }
}
