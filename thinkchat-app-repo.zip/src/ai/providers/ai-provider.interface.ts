import { AIProvider } from '@prisma/client';

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface ChatRequest {
  model: string;
  systemPrompt: string;
  messages: ChatMessage[];   // conversation history (user/assistant turns)
  temperature: number;
  maxTokens?: number;
}

export interface ChatResult {
  text: string;
  tokensIn: number;
  tokensOut: number;
}

/** One interface; OpenAI / Anthropic / Gemini implement it behind the factory. */
export interface ChatProvider {
  readonly provider: AIProvider;
  chat(req: ChatRequest): Promise<ChatResult>;
}
