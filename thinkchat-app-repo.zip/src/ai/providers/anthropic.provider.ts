import { Injectable } from '@nestjs/common';
import { AIProvider } from '@prisma/client';
import { ChatProvider, ChatRequest, ChatResult } from './ai-provider.interface';

@Injectable()
export class AnthropicProvider implements ChatProvider {
  readonly provider = AIProvider.ANTHROPIC;

  async chat(req: ChatRequest): Promise<ChatResult> {
    const key = process.env.ANTHROPIC_API_KEY;
    if (!key) throw new Error('ANTHROPIC_API_KEY not set');
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': key,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: req.model,
        max_tokens: req.maxTokens ?? 600,
        temperature: req.temperature,
        system: req.systemPrompt,
        messages: req.messages.map((m) => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: m.content })),
      }),
    });
    if (!res.ok) throw new Error(`Anthropic ${res.status}: ${await res.text()}`);
    const data = await res.json();
    const text = Array.isArray(data.content) ? data.content.map((c: any) => c.text ?? '').join('') : '';
    return {
      text,
      tokensIn: data.usage?.input_tokens ?? 0,
      tokensOut: data.usage?.output_tokens ?? 0,
    };
  }
}
