import { Injectable } from '@nestjs/common';
import { AIProvider } from '@prisma/client';
import { ChatProvider, ChatRequest, ChatResult } from './ai-provider.interface';

@Injectable()
export class OpenAIProvider implements ChatProvider {
  readonly provider = AIProvider.OPENAI;

  async chat(req: ChatRequest): Promise<ChatResult> {
    const key = process.env.OPENAI_API_KEY;
    if (!key) throw new Error('OPENAI_API_KEY not set');
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model: req.model,
        temperature: req.temperature,
        max_tokens: req.maxTokens ?? 600,
        messages: [{ role: 'system', content: req.systemPrompt }, ...req.messages],
      }),
    });
    if (!res.ok) throw new Error(`OpenAI ${res.status}: ${await res.text()}`);
    const data = await res.json();
    return {
      text: data.choices?.[0]?.message?.content ?? '',
      tokensIn: data.usage?.prompt_tokens ?? 0,
      tokensOut: data.usage?.completion_tokens ?? 0,
    };
  }
}
