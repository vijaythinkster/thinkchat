import { Processor, WorkerHost, InjectQueue } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job, Queue } from 'bullmq';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { JOB, QUEUE, RunInferenceJob, SendMessageJob } from 'src/whatsapp/queue/queue.constants';
import { AIProviderFactory } from '../providers/ai-provider.factory';
import { KnowledgeService } from '../knowledge.service';
import { ChatMessage } from '../providers/ai-provider.interface';

const HANDOFF = '[[HANDOFF]]';

/**
 * Generates an AI reply for an inbound message and sends it via the shared
 * MESSAGE_SEND worker. Skips conversations a human already owns. If the model
 * decides to escalate (emits [[HANDOFF]]), the turn is logged as handed off.
 * Runs outside request scope, so every query passes organizationId explicitly.
 */
@Processor(QUEUE.AI_INFERENCE, { concurrency: 4 })
export class AIInferenceProcessor extends WorkerHost {
  private readonly logger = new Logger(AIInferenceProcessor.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly factory: AIProviderFactory,
    private readonly knowledge: KnowledgeService,
    @InjectQueue(QUEUE.MESSAGE_SEND) private readonly sendQueue: Queue,
  ) {
    super();
  }

  async process(job: Job<RunInferenceJob>): Promise<void> {
    if (job.name !== JOB.RUN_INFERENCE) return;
    const { organizationId, conversationId } = job.data;

    const assistant = job.data.assistantId
      ? await this.prisma.aIAssistant.findFirst({ where: { id: job.data.assistantId, organizationId, isActive: true, deletedAt: null } })
      : await this.prisma.aIAssistant.findFirst({ where: { organizationId, isActive: true, deletedAt: null }, orderBy: { createdAt: 'asc' } });
    if (!assistant) return;

    const conversation = await this.prisma.conversation.findFirst({
      where: { id: conversationId, organizationId },
      include: { contact: { select: { phone: true, name: true } } },
    });
    if (!conversation) return;
    if (conversation.assignedAgentId) return; // a human is handling this thread

    // Recent history → chat turns.
    const window = Number((assistant.config as any)?.memoryWindow ?? 10);
    const history = await this.prisma.message.findMany({
      where: { conversationId, organizationId, body: { not: null } },
      orderBy: { createdAt: 'asc' }, take: window,
      select: { direction: true, body: true },
    });
    const messages: ChatMessage[] = history.map((m) => ({
      role: m.direction === 'INBOUND' ? 'user' : 'assistant',
      content: m.body ?? '',
    }));
    if (messages.length === 0 || messages[messages.length - 1].role !== 'user') return;
    const lastUser = messages[messages.length - 1].content;

    // RAG context + escalation instruction.
    const context = await this.knowledge.retrieve(organizationId, assistant.id, lastUser);
    const systemPrompt =
      `${assistant.systemPrompt}\n\n` +
      (context.length ? `Relevant knowledge:\n${context.join('\n---\n')}\n\n` : '') +
      `If you cannot help or the user asks for a human, reply with ${HANDOFF} and a short handoff sentence.`;

    let result;
    try {
      result = await this.factory.get(assistant.provider).chat({
        model: assistant.model, systemPrompt, temperature: assistant.temperature, messages,
      });
    } catch (err) {
      this.logger.error(`Inference failed for ${conversationId}: ${(err as Error).message}`);
      throw err; // BullMQ retry
    }

    const handedOff = result.text.includes(HANDOFF);
    const reply = result.text.replace(HANDOFF, '').trim();

    // Send the reply (unless empty) via the standard outbound pipeline.
    if (reply) {
      const graph = {
        messaging_product: 'whatsapp', to: conversation.contact.phone,
        type: 'text', text: { body: reply },
      };
      const message = await this.prisma.message.create({
        data: {
          organizationId, conversationId, whatsAppNumberId: conversation.whatsAppNumberId,
          direction: 'OUTBOUND', type: 'TEXT', status: 'QUEUED', body: reply,
          payload: { graph } as any,
        },
      });
      await this.sendQueue.add(JOB.SEND_MESSAGE, { organizationId, messageId: message.id } as SendMessageJob,
        { attempts: 5, backoff: { type: 'exponential', delay: 4000 }, removeOnComplete: 1000 });
    }

    await this.prisma.aIConversationLog.create({
      data: {
        organizationId, assistantId: assistant.id, conversationId,
        tokensIn: result.tokensIn, tokensOut: result.tokensOut, handedOff,
        transcript: messages as any, summary: reply.slice(0, 280),
      },
    });

    if (handedOff) this.logger.log(`Assistant handed off conversation ${conversationId}`);
  }
}
