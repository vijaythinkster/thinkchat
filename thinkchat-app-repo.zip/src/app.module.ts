import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { BullModule } from '@nestjs/bullmq';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { CommonModule } from './common/common.module';
import { AuthModule } from './auth/auth.module';
import { WhatsAppModule } from './whatsapp/whatsapp.module';
import { InboxModule } from './inbox/inbox.module';
import { CampaignsModule } from './campaigns/campaigns.module';
import { BillingModule } from './billing/billing.module';
import { CrmModule } from './crm/crm.module';
import { AIModule } from './ai/ai.module';
import { FlowsModule } from './flows/flows.module';
import { AdminModule } from './admin/admin.module';
import { IntegrationsModule } from './integrations/integrations.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    EventEmitterModule.forRoot(),
    BullModule.forRoot({
      connection: {
        host: process.env.REDIS_HOST ?? 'redis',
        port: Number(process.env.REDIS_PORT ?? 6379),
      },
    }),
    CommonModule,
    AuthModule,
    WhatsAppModule,
    InboxModule,
    CampaignsModule,
    BillingModule,
    CrmModule,
    AIModule,
    FlowsModule,
    AdminModule,
    IntegrationsModule,
  ],
})
export class AppModule {}
