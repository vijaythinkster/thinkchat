import { ConflictException, Injectable, UnauthorizedException } from '@nestjs/common';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { PasswordService } from './password.service';
import { TokensService, AccessClaims } from './tokens/tokens.service';
import { PERMISSIONS, SYSTEM_ROLES } from './rbac/permissions';
import { RegisterDto, LoginDto } from './dto/auth.dto';

function slugify(name: string) {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '').slice(0, 40)
    + '-' + Math.random().toString(36).slice(2, 7);
}

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly passwords: PasswordService,
    private readonly tokens: TokensService,
  ) {}

  /** Create a new tenant: org + seeded roles/permissions + owner user. */
  async register(dto: RegisterDto) {
    const passwordHash = await this.passwords.hash(dto.password);

    // Permission catalog is global + idempotent.
    await Promise.all(
      PERMISSIONS.map((p) =>
        this.prisma.permission.upsert({
          where: { key: p.key }, create: { key: p.key, description: p.description }, update: {},
        }),
      ),
    );
    const allPerms = await this.prisma.permission.findMany();
    const permByKey = new Map(allPerms.map((p) => [p.key, p.id]));

    const result = await this.prisma.$transaction(async (tx) => {
      const org = await tx.organization.create({
        data: { name: dto.organizationName, slug: slugify(dto.organizationName) },
      });

      // System roles + their permissions.
      const roleIdByName: Record<string, string> = {};
      for (const [name, def] of Object.entries(SYSTEM_ROLES)) {
        const role = await tx.role.create({
          data: { organizationId: org.id, name, description: def.description, isSystem: true },
        });
        roleIdByName[name] = role.id;
        await tx.rolePermission.createMany({
          data: def.permissions
            .map((k) => permByKey.get(k))
            .filter((id): id is string => !!id)
            .map((permissionId) => ({ roleId: role.id, permissionId })),
          skipDuplicates: true,
        });
      }

      const user = await tx.user.create({
        data: {
          organizationId: org.id, email: dto.email, passwordHash,
          firstName: dto.firstName, lastName: dto.lastName,
          userRoles: { create: { roleId: roleIdByName.Owner } },
        },
      });
      return { org, user };
    });

    const claims = await this.loadClaims(result.user.id);
    const tokens = await this.tokens.issue(claims);
    return { organization: { id: result.org.id, name: result.org.name }, user: publicUser(result.user), ...tokens };
  }

  async login(dto: LoginDto) {
    // No org context yet => tenant middleware is a no-op, so this finds the user
    // across orgs by email, then verifies the password.
    const candidates = await this.prisma.user.findMany({
      where: { email: dto.email, isActive: true, deletedAt: null },
    });
    let matched: (typeof candidates)[number] | null = null;
    for (const u of candidates) {
      if (u.passwordHash && (await this.passwords.verify(dto.password, u.passwordHash))) { matched = u; break; }
    }
    if (!matched) throw new UnauthorizedException('Invalid email or password');

    await this.prisma.user.update({ where: { id: matched.id }, data: { lastLoginAt: new Date() } });
    const claims = await this.loadClaims(matched.id);
    const tokens = await this.tokens.issue(claims);
    return { user: publicUser(matched), ...tokens };
  }

  refresh(refreshToken: string) {
    return this.tokens.rotate(refreshToken, (userId) => this.loadClaims(userId));
  }

  async logout(refreshToken: string) {
    await this.tokens.revoke(refreshToken);
    return { ok: true };
  }

  async me(userId: string) {
    const claims = await this.loadClaims(userId);
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    return { user: user ? publicUser(user) : null, roles: claims.roles, permissions: claims.perms };
  }

  /** Build JWT claims (org + roles + flattened permissions) for a user. */
  private async loadClaims(userId: string): Promise<AccessClaims> {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: {
        userRoles: { include: { role: { include: { rolePermissions: { include: { permission: true } } } } } },
      },
    });
    if (!user) throw new UnauthorizedException('User not found');
    const roles = user.userRoles.map((ur) => ur.role.name);
    const perms = new Set<string>();
    for (const ur of user.userRoles)
      for (const rp of ur.role.rolePermissions) perms.add(rp.permission.key);
    return { sub: user.id, org: user.organizationId, roles, perms: [...perms] };
  }
}

function publicUser(u: { id: string; email: string; firstName: string | null; lastName: string | null; organizationId: string }) {
  return { id: u.id, email: u.email, firstName: u.firstName, lastName: u.lastName, organizationId: u.organizationId };
}
