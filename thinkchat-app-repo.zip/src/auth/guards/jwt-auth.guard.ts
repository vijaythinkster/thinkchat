import {
  CanActivate, ExecutionContext, Injectable, UnauthorizedException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { JwtService } from '@nestjs/jwt';
import { IS_PUBLIC_KEY } from '../decorators/public.decorator';
import { AccessClaims } from '../tokens/tokens.service';
import { enterTenantContext } from 'src/common/tenant/request-context';

/**
 * Verifies the access token, attaches the user to the request, and seeds the
 * async-local tenant context the Prisma middleware reads. @Public routes skip it.
 */
@Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(
    private readonly jwt: JwtService,
    private readonly reflector: Reflector,
  ) {}

  async canActivate(ctx: ExecutionContext): Promise<boolean> {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      ctx.getHandler(), ctx.getClass(),
    ]);
    if (isPublic) return true;

    const req = ctx.switchToHttp().getRequest();
    const header: string = req.headers?.authorization ?? '';
    const [scheme, token] = header.split(' ');
    if (scheme !== 'Bearer' || !token) throw new UnauthorizedException('Missing bearer token');

    let claims: AccessClaims;
    try {
      claims = await this.jwt.verifyAsync<AccessClaims>(token);
    } catch {
      throw new UnauthorizedException('Invalid or expired token');
    }

    req.user = {
      userId: claims.sub, organizationId: claims.org,
      roles: claims.roles ?? [], permissions: claims.perms ?? [],
    };
    req.organizationId = claims.org;
    enterTenantContext({
      userId: claims.sub, organizationId: claims.org,
      roles: claims.roles ?? [], permissions: claims.perms ?? [],
    });
    return true;
  }
}
