/** Permission catalog. Seeded into the Permission table on first org registration. */
export const PERMISSIONS: { key: string; description: string }[] = [
  { key: 'contacts.read', description: 'View contacts' },
  { key: 'contacts.write', description: 'Create / edit contacts' },
  { key: 'contacts.delete', description: 'Delete contacts' },
  { key: 'inbox.read', description: 'View conversations' },
  { key: 'inbox.send', description: 'Send messages' },
  { key: 'inbox.assign', description: 'Assign conversations' },
  { key: 'campaigns.read', description: 'View campaigns' },
  { key: 'campaigns.manage', description: 'Create / launch campaigns' },
  { key: 'templates.manage', description: 'Manage message templates' },
  { key: 'crm.manage', description: 'Manage pipeline, deals, tasks' },
  { key: 'billing.read', description: 'View usage and invoices' },
  { key: 'billing.manage', description: 'Manage subscription and payments' },
  { key: 'team.manage', description: 'Manage users and roles' },
  { key: 'settings.manage', description: 'Manage org settings and numbers' },
  { key: 'ai.manage', description: 'Manage AI assistants' },
  { key: 'flows.manage', description: 'Manage automation flows' },
  { key: 'integrations.manage', description: 'Connect and manage third-party integrations' },
];

export const ALL_PERMISSION_KEYS = PERMISSIONS.map((p) => p.key);

/** System roles seeded per organization at registration. */
export const SYSTEM_ROLES: Record<string, { description: string; permissions: string[] }> = {
  Owner: { description: 'Full access', permissions: ALL_PERMISSION_KEYS },
  Admin: {
    description: 'Manage everything except billing and team',
    permissions: ALL_PERMISSION_KEYS.filter((k) => k !== 'billing.manage' && k !== 'team.manage'),
  },
  Agent: {
    description: 'Front-line agent',
    permissions: ['contacts.read', 'contacts.write', 'inbox.read', 'inbox.send', 'campaigns.read'],
  },
};
