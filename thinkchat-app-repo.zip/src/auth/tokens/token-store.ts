import { Injectable, OnModuleDestroy } from '@nestjs/common';
import Redis from 'ioredis';
import * as crypto from 'crypto';

const TTL_SECONDS = 30 * 24 * 60 * 60; // 30 days

/**
 * Refresh-token store backed by Redis. One key per issued refresh token
 * (rt:{userId}:{tokenId}) holding the SHA-256 of its secret. Rotation deletes the
 * old key and writes a new one; presenting a token whose key is gone signals reuse.
 */
@Injectable()
export class TokenStore implements OnModuleDestroy {
  private readonly redis = new Redis({
    host: process.env.REDIS_HOST ?? 'redis',
    port: Number(process.env.REDIS_PORT ?? 6379),
    maxRetriesPerRequest: null,
  });

  private key(userId: string, tokenId: string) {
    return `rt:${userId}:${tokenId}`;
  }

  static hash(secret: string) {
    return crypto.createHash('sha256').update(secret).digest('hex');
  }

  async save(userId: string, tokenId: string, secretHash: string) {
    await this.redis.set(this.key(userId, tokenId), secretHash, 'EX', TTL_SECONDS);
  }

  async get(userId: string, tokenId: string): Promise<string | null> {
    return this.redis.get(this.key(userId, tokenId));
  }

  async revoke(userId: string, tokenId: string) {
    await this.redis.del(this.key(userId, tokenId));
  }

  /** Revoke every session for a user (used on refresh-token reuse detection). */
  async revokeAll(userId: string) {
    const keys = await this.redis.keys(`rt:${userId}:*`);
    if (keys.length) await this.redis.del(...keys);
  }

  async onModuleDestroy() {
    await this.redis.quit();
  }
}
