import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as crypto from 'crypto';
import { TokenStore } from './token-store';

export interface AccessClaims {
  sub: string;          // userId
  org: string;          // organizationId
  roles: string[];
  perms: string[];
}

export interface IssuedTokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;    // access token lifetime (seconds)
}

const ACCESS_TTL = 15 * 60; // 15 minutes

@Injectable()
export class TokensService {
  constructor(
    private readonly jwt: JwtService,
    private readonly store: TokenStore,
  ) {}

  async issue(claims: AccessClaims): Promise<IssuedTokens> {
    const accessToken = await this.jwt.signAsync(claims, { expiresIn: ACCESS_TTL });

    const tokenId = crypto.randomUUID();
    const secret = crypto.randomBytes(32).toString('hex');
    await this.store.save(claims.sub, tokenId, TokenStore.hash(secret));
    // Opaque, self-describing refresh token: userId.tokenId.secret
    const refreshToken = `${claims.sub}.${tokenId}.${secret}`;

    return { accessToken, refreshToken, expiresIn: ACCESS_TTL };
  }

  /**
   * Validate a refresh token and rotate it. On reuse (a token whose server-side
   * record is gone) every session for the user is revoked.
   */
  async rotate(refreshToken: string, reissue: (userId: string) => Promise<AccessClaims>): Promise<IssuedTokens> {
    const parts = refreshToken.split('.');
    if (parts.length !== 3) throw new UnauthorizedException('Malformed refresh token');
    const [userId, tokenId, secret] = parts;

    const stored = await this.store.get(userId, tokenId);
    if (!stored) {
      await this.store.revokeAll(userId);
      throw new UnauthorizedException('Refresh token no longer valid');
    }
    if (!timingSafeEqual(stored, TokenStore.hash(secret))) {
      await this.store.revokeAll(userId);
      throw new UnauthorizedException('Refresh token mismatch');
    }

    await this.store.revoke(userId, tokenId); // one-time use
    const claims = await reissue(userId);
    return this.issue(claims);
  }

  async revoke(refreshToken: string) {
    const parts = refreshToken.split('.');
    if (parts.length === 3) await this.store.revoke(parts[0], parts[1]);
  }
}

function timingSafeEqual(a: string, b: string) {
  const ba = Buffer.from(a); const bb = Buffer.from(b);
  return ba.length === bb.length && crypto.timingSafeEqual(ba, bb);
}
