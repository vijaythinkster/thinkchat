import {
  Body, Controller, Get, Param, Post, Req,
} from '@nestjs/common';
import { PlanTier } from '@prisma/client';
import { OrgId } from 'src/common/tenant/org-id.decorator';
import { Public } from 'src/auth/decorators/public.decorator';
import { BillingService } from './billing.service';
import { UsageService } from './usage.service';
import { PaymentsService } from './payments/payments.service';

@Controller('billing')
export class BillingController {
  constructor(
    private readonly billing: BillingService,
    private readonly usage: UsageService,
    private readonly payments: PaymentsService,
  ) {}

  @Get('usage')
  usageNow(@OrgId() orgId: string) {
    return this.usage.currentPeriodUsage(orgId);
  }

  @Get('subscription')
  subscription(@OrgId() orgId: string) {
    return this.billing.getSubscription(orgId);
  }

  @Post('subscribe')
  subscribe(@OrgId() orgId: string, @Body() body: { tier: PlanTier; currency?: string }) {
    return this.billing.subscribe(orgId, body.tier, body.currency);
  }

  @Get('invoices')
  invoices(@OrgId() orgId: string) {
    return this.billing.listInvoices(orgId);
  }

  @Post('invoices/generate')
  generate(@OrgId() orgId: string) {
    return this.billing.generateInvoice(orgId);
  }

  @Post('invoices/:id/checkout')
  checkout(@OrgId() orgId: string, @Param('id') id: string, @Body() body: { gateway?: any }) {
    return this.payments.createCheckout(orgId, id, body.gateway ?? 'RAZORPAY');
  }

  // Gateway webhook (no tenant guard; authenticity is the signature). Needs raw body.
  @Public()
  @Post('webhook/:gateway')
  webhook(@Param('gateway') gateway: string, @Req() req: any) {
    const raw = (req.rawBody ?? Buffer.from(JSON.stringify(req.body ?? {}))).toString('utf8');
    return this.payments.handleWebhook(gateway.toUpperCase(), raw, req.headers ?? {});
  }
}
