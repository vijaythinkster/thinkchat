import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { QUEUE } from 'src/whatsapp/queue/queue.constants';
import { PricingService } from './pricing/pricing.service';
import { UsageService } from './usage.service';
import { BillingService } from './billing.service';
import { BillingController } from './billing.controller';
import { PaymentsService } from './payments/payments.service';
import { RazorpayProvider } from './payments/razorpay.provider';
import { BillingMeterProcessor } from './queue/billing-meter.processor';

@Module({
  imports: [BullModule.registerQueue({ name: QUEUE.BILLING_METER })],
  controllers: [BillingController],
  providers: [
    PricingService, UsageService, BillingService,
    PaymentsService, RazorpayProvider, BillingMeterProcessor,
  ],
  exports: [BillingService, UsageService, PricingService],
})
export class BillingModule {}
