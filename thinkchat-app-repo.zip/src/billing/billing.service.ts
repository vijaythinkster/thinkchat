import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { PlanTier } from '@prisma/client';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { UsageService, monthRange } from './usage.service';

const GST_RATE = 0.18; // India GST on the platform service

@Injectable()
export class BillingService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly usage: UsageService,
  ) {}

  getSubscription(organizationId: string) {
    return this.prisma.subscription.findFirst({
      where: { organizationId },
      include: { plan: true },
      orderBy: { createdAt: 'desc' },
    });
  }

  listInvoices(organizationId: string) {
    return this.prisma.invoice.findMany({
      where: { organizationId }, orderBy: { createdAt: 'desc' },
    });
  }

  async subscribe(organizationId: string, tier: PlanTier, currency = 'USD') {
    const plan = await this.prisma.plan.findFirst({ where: { tier, currency, isActive: true } });
    if (!plan) throw new NotFoundException(`No active ${tier} plan in ${currency}`);
    const { start, end } = monthRange();

    const existing = await this.getSubscription(organizationId);
    if (existing) {
      return this.prisma.subscription.update({
        where: { id: existing.id },
        data: { planId: plan.id, status: 'ACTIVE', currentPeriodStart: start, currentPeriodEnd: end },
        include: { plan: true },
      });
    }
    return this.prisma.subscription.create({
      data: {
        organizationId, planId: plan.id, status: 'ACTIVE',
        currentPeriodStart: start, currentPeriodEnd: end,
      },
      include: { plan: true },
    });
  }

  /**
   * Roll a billing period into an Invoice: platform subscription fee + metered
   * usage, with GST applied for INR. Idempotent-ish via the unique invoice number.
   */
  async generateInvoice(organizationId: string, periodStart?: Date) {
    const { start } = periodStart ? { start: periodStart } : monthRange();
    const sub = await this.getSubscription(organizationId);
    const currency = sub?.plan.currency ?? 'USD';

    const lineItems: Array<{ type: string; description: string; quantity: number; amount: number }> = [];
    let subtotal = 0;

    if (sub) {
      const fee = Number(sub.plan.priceMonthly);
      lineItems.push({ type: 'subscription', description: `${sub.plan.name} plan`, quantity: 1, amount: fee });
      subtotal += fee;
    }

    const usage = await this.usage.usageForPeriod(organizationId, start);
    for (const u of usage) {
      if (u.billedCost <= 0) continue;
      lineItems.push({
        type: 'usage', description: u.metric.replace('messages.', 'WhatsApp messages — '),
        quantity: u.quantity, amount: round2(u.billedCost),
      });
      subtotal += u.billedCost;
    }

    if (lineItems.length === 0) throw new BadRequestException('Nothing to invoice for this period');

    subtotal = round2(subtotal);
    const taxAmount = currency === 'INR' ? round2(subtotal * GST_RATE) : 0;
    const total = round2(subtotal + taxAmount);
    const number = `INV-${start.getUTCFullYear()}${String(start.getUTCMonth() + 1).padStart(2, '0')}-${rand6()}`;

    return this.prisma.invoice.create({
      data: {
        organizationId, subscriptionId: sub?.id, number, status: 'OPEN',
        subtotal, taxAmount, total, currency, lineItems: lineItems as any,
        issuedAt: new Date(), dueAt: new Date(Date.now() + 7 * 86_400_000),
      },
    });
  }
}

const round2 = (n: number) => Math.round(n * 100) / 100;
const rand6 = () => Math.random().toString(36).slice(2, 8).toUpperCase();
