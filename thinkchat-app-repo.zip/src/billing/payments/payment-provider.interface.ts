/** Result of starting a checkout for an invoice. */
export interface CheckoutSession {
  orderId: string;
  checkoutUrl?: string;
  raw?: unknown;
}

/** Normalized webhook outcome after signature verification. */
export interface PaymentEvent {
  ok: boolean;
  type: 'payment.succeeded' | 'payment.failed' | 'ignored';
  gatewayPaymentId?: string;
  invoiceNumber?: string;
  amount?: number;
}

export interface PaymentProvider {
  readonly gateway: 'STRIPE' | 'RAZORPAY' | 'MANUAL';
  createCheckout(args: { invoiceNumber: string; amount: number; currency: string }): Promise<CheckoutSession>;
  verifyWebhook(rawBody: string, headers: Record<string, string>): PaymentEvent;
}
