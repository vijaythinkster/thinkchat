import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { PaymentGateway } from '@prisma/client';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { PaymentProvider } from './payment-provider.interface';
import { RazorpayProvider } from './razorpay.provider';

@Injectable()
export class PaymentsService {
  private readonly providers: Record<string, PaymentProvider>;

  constructor(
    private readonly prisma: PrismaService,
    razorpay: RazorpayProvider,
  ) {
    this.providers = { RAZORPAY: razorpay };
  }

  private provider(gateway: string): PaymentProvider {
    const p = this.providers[gateway];
    if (!p) throw new BadRequestException(`Unsupported gateway ${gateway}`);
    return p;
  }

  async createCheckout(organizationId: string, invoiceId: string, gateway: PaymentGateway = 'RAZORPAY') {
    const invoice = await this.prisma.invoice.findFirst({ where: { id: invoiceId, organizationId } });
    if (!invoice) throw new NotFoundException('Invoice not found');
    if (invoice.status === 'PAID') throw new BadRequestException('Invoice already paid');

    const session = await this.provider(gateway).createCheckout({
      invoiceNumber: invoice.number, amount: Number(invoice.total), currency: invoice.currency,
    });
    await this.prisma.payment.create({
      data: {
        organizationId, invoiceId: invoice.id, subscriptionId: invoice.subscriptionId,
        amount: invoice.total, currency: invoice.currency, status: 'PENDING',
        gateway, gatewayPaymentId: session.orderId,
      },
    });
    return session;
  }

  /** Gateway webhook -> verify signature, then settle the invoice + payment. */
  async handleWebhook(gateway: string, rawBody: string, headers: Record<string, string>) {
    const event = this.provider(gateway).verifyWebhook(rawBody, headers);
    if (!event.ok || event.type === 'ignored') return { received: true, applied: false };

    const invoice = event.invoiceNumber
      ? await this.prisma.invoice.findUnique({ where: { number: event.invoiceNumber } })
      : null;

    if (event.type === 'payment.succeeded' && invoice) {
      await this.prisma.$transaction([
        this.prisma.invoice.update({ where: { id: invoice.id }, data: { status: 'PAID', paidAt: new Date() } }),
        this.prisma.payment.updateMany({
          where: { invoiceId: invoice.id, status: 'PENDING' },
          data: { status: 'SUCCEEDED', gatewayPaymentId: event.gatewayPaymentId },
        }),
      ]);
      return { received: true, applied: true };
    }
    if (event.type === 'payment.failed' && invoice) {
      await this.prisma.payment.updateMany({
        where: { invoiceId: invoice.id, status: 'PENDING' },
        data: { status: 'FAILED' },
      });
    }
    return { received: true, applied: false };
  }
}
