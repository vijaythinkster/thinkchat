import { Injectable, Logger } from '@nestjs/common';
import * as crypto from 'crypto';
import { CheckoutSession, PaymentEvent, PaymentProvider } from './payment-provider.interface';

/**
 * Razorpay (common in India). Signature verification is real; order creation is
 * stubbed — wiring the live API call needs RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET
 * and the razorpay SDK. The webhook secret verifies authenticity.
 */
@Injectable()
export class RazorpayProvider implements PaymentProvider {
  readonly gateway = 'RAZORPAY' as const;
  private readonly logger = new Logger(RazorpayProvider.name);

  async createCheckout(args: { invoiceNumber: string; amount: number; currency: string }): Promise<CheckoutSession> {
    const keyId = process.env.RAZORPAY_KEY_ID;
    if (!keyId) {
      // INTEGRATION STUB: replace with razorpay.orders.create(...) once keys are set.
      throw new Error('Razorpay not configured: set RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET');
    }
    return { orderId: `order_stub_${args.invoiceNumber}`, raw: { note: 'stub' } };
  }

  verifyWebhook(rawBody: string, headers: Record<string, string>): PaymentEvent {
    const secret = process.env.RAZORPAY_WEBHOOK_SECRET ?? '';
    const signature = headers['x-razorpay-signature'] ?? '';
    const expected = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');
    if (!secret || !timingSafeEqual(signature, expected)) {
      return { ok: false, type: 'ignored' };
    }
    const body = JSON.parse(rawBody);
    const entity = body?.payload?.payment?.entity ?? {};
    const succeeded = body?.event === 'payment.captured';
    return {
      ok: true,
      type: succeeded ? 'payment.succeeded' : 'payment.failed',
      gatewayPaymentId: entity.id,
      invoiceNumber: entity?.notes?.invoiceNumber,
      amount: entity.amount ? entity.amount / 100 : undefined,
    };
  }
}

function timingSafeEqual(a: string, b: string) {
  const ba = Buffer.from(a); const bb = Buffer.from(b);
  return ba.length === bb.length && crypto.timingSafeEqual(ba, bb);
}
