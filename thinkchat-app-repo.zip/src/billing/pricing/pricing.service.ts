import { Injectable, Logger } from '@nestjs/common';
import * as fs from 'fs';
import * as path from 'path';

type CategoryRates = Record<string, number>;
interface RateCard { currency: string; rates: Record<string, CategoryRates> }

export interface MessagePrice {
  metaRate: number;   // what Meta charges us, per message
  free: boolean;      // service-category / in-window => free
  currency: string;
}

/**
 * Resolves Meta's per-message price for (country, category). Rate card is loaded
 * from JSON for the MVP; production should move this to a versioned DB table so
 * rates can be updated and audited without a deploy (see PRODUCTION note below).
 */
@Injectable()
export class PricingService {
  private readonly logger = new Logger(PricingService.name);
  private card: RateCard;

  constructor() {
    const file = path.join(__dirname, 'rate-card.json');
    this.card = JSON.parse(fs.readFileSync(file, 'utf8')) as RateCard;
  }

  price(countryCode: string | null, category: string | null): MessagePrice {
    const cat = (category ?? 'marketing').toLowerCase();
    if (cat === 'service' || cat === 'referral_conversion') {
      return { metaRate: 0, free: true, currency: this.card.currency };
    }
    const table = this.card.rates[(countryCode ?? '').toUpperCase()] ?? this.card.rates.default;
    const rate = table[cat] ?? table.marketing ?? 0;
    return { metaRate: rate, free: false, currency: this.card.currency };
  }
}
