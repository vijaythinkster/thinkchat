import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { JOB, MeterMessageJob, QUEUE } from 'src/whatsapp/queue/queue.constants';
import { PricingService } from '../pricing/pricing.service';

/**
 * Meters one delivered message. Enqueued by the webhook worker on a genuine
 * transition to DELIVERED. Exactly-once is guaranteed by the conditional
 * `meteredAt` claim — a redelivered webhook or a BullMQ retry can never
 * double-bill, because only the first claim updates a row.
 */
@Processor(QUEUE.BILLING_METER, { concurrency: 10 })
export class BillingMeterProcessor extends WorkerHost {
  private readonly logger = new Logger(BillingMeterProcessor.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly pricing: PricingService,
  ) {
    super();
  }

  async process(job: Job<MeterMessageJob>): Promise<void> {
    if (job.name !== JOB.METER_MESSAGE) return;
    const { organizationId, whatsAppNumberId, category, countryCode, waMessageId } = job.data;

    const message = await this.prisma.message.findFirst({
      where: { waMessageId, organizationId },
      select: { id: true, deliveredAt: true },
    });
    if (!message) return;

    // Exactly-once claim.
    const claim = await this.prisma.message.updateMany({
      where: { id: message.id, meteredAt: null },
      data: { meteredAt: new Date() },
    });
    if (claim.count === 0) return; // already metered

    const { metaRate, free } = this.pricing.price(countryCode, category);
    const org = await this.prisma.organization.findUnique({
      where: { id: organizationId }, select: { settings: true },
    });
    const markupBps = Number((org?.settings as any)?.billing?.markupBps ?? 0); // 0 = transparent pass-through
    const metaCost = free ? 0 : metaRate;
    const billedCost = free ? 0 : metaRate * (1 + markupBps / 10_000);

    const { start, end } = monthRange(message.deliveredAt ?? new Date());
    const metric = `messages.${(category ?? 'unknown').toLowerCase()}`;
    const cat = (category ?? 'unknown').toLowerCase();
    const cc = (countryCode ?? 'XX').toUpperCase();

    await this.prisma.usageRecord.upsert({
      where: { usage_period_key: { organizationId, metric, category: cat, countryCode: cc, periodStart: start } },
      create: {
        organizationId, whatsAppNumberId, metric, category: cat, countryCode: cc,
        quantity: 1, metaCost, billedCost, periodStart: start, periodEnd: end,
      },
      update: {
        quantity: { increment: 1 },
        metaCost: { increment: metaCost },
        billedCost: { increment: billedCost },
      },
    });
  }
}

function monthRange(d: Date) {
  const start = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1));
  const end = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 1));
  return { start, end };
}
