import { Injectable } from '@nestjs/common';
import { PrismaService } from 'src/common/prisma/prisma.service';

export function monthRange(d = new Date()) {
  const start = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1));
  const end = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 1));
  return { start, end };
}

@Injectable()
export class UsageService {
  constructor(private readonly prisma: PrismaService) {}

  /** Current-period spend with the transparency split: Meta cost vs what we bill. */
  async currentPeriodUsage(organizationId: string) {
    const { start, end } = monthRange();
    const records = await this.prisma.usageRecord.findMany({
      where: { organizationId, periodStart: start },
    });

    let messages = 0, metaCost = 0, billedCost = 0;
    const byCategory: Record<string, { messages: number; metaCost: number; billedCost: number }> = {};
    const byCountry: Record<string, { messages: number; billedCost: number }> = {};

    for (const r of records) {
      const q = r.quantity;
      const meta = Number(r.metaCost);
      const billed = Number(r.billedCost);
      messages += q; metaCost += meta; billedCost += billed;

      const cat = r.metric.replace('messages.', '');
      byCategory[cat] ??= { messages: 0, metaCost: 0, billedCost: 0 };
      byCategory[cat].messages += q;
      byCategory[cat].metaCost += meta;
      byCategory[cat].billedCost += billed;

      const cc = r.countryCode ?? 'XX';
      byCountry[cc] ??= { messages: 0, billedCost: 0 };
      byCountry[cc].messages += q;
      byCountry[cc].billedCost += billed;
    }

    return {
      periodStart: start.toISOString(),
      periodEnd: end.toISOString(),
      totals: {
        messages,
        metaCost: round4(metaCost),
        billedCost: round4(billedCost),
        margin: round4(billedCost - metaCost),
      },
      byCategory: Object.entries(byCategory).map(([category, v]) => ({ category, ...round(v) })),
      byCountry: Object.entries(byCountry)
        .map(([countryCode, v]) => ({ countryCode, messages: v.messages, billedCost: round4(v.billedCost) }))
        .sort((a, b) => b.messages - a.messages),
    };
  }

  /** Sum billed usage for an arbitrary period (used by invoice generation). */
  async usageForPeriod(organizationId: string, periodStart: Date) {
    const records = await this.prisma.usageRecord.findMany({
      where: { organizationId, periodStart },
    });
    return records.map((r) => ({
      metric: r.metric,
      quantity: r.quantity,
      billedCost: Number(r.billedCost),
    }));
  }
}

const round4 = (n: number) => Math.round(n * 10000) / 10000;
const round = (v: { messages: number; metaCost: number; billedCost: number }) => ({
  messages: v.messages, metaCost: round4(v.metaCost), billedCost: round4(v.billedCost),
});
