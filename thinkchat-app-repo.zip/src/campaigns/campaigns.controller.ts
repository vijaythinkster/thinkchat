import {
  Body, Controller, Get, Param, Post,
} from '@nestjs/common';
import { OrgId } from 'src/common/tenant/org-id.decorator';
import { CampaignsService } from './campaigns.service';
import {
  AudiencePreviewDto, CreateCampaignDto, ScheduleCampaignDto,
} from './dto/campaign.dto';

@Controller('campaigns')
export class CampaignsController {
  constructor(private readonly campaigns: CampaignsService) {}

  @Post()
  create(@OrgId() orgId: string, @Body() dto: CreateCampaignDto) {
    return this.campaigns.create(orgId, dto);
  }

  @Get()
  list(@OrgId() orgId: string) {
    return this.campaigns.list(orgId);
  }

  @Get(':id')
  get(@OrgId() orgId: string, @Param('id') id: string) {
    return this.campaigns.get(orgId, id);
  }

  @Get(':id/analytics')
  analytics(@OrgId() orgId: string, @Param('id') id: string) {
    return this.campaigns.analytics(orgId, id);
  }

  @Post('audience-preview')
  preview(@OrgId() orgId: string, @Body() dto: AudiencePreviewDto) {
    return this.campaigns.previewAudience(orgId, dto);
  }

  @Post(':id/launch')
  launch(@OrgId() orgId: string, @Param('id') id: string) {
    return this.campaigns.launchNow(orgId, id);
  }

  @Post(':id/schedule')
  schedule(@OrgId() orgId: string, @Param('id') id: string, @Body() dto: ScheduleCampaignDto) {
    return this.campaigns.schedule(orgId, id, dto);
  }

  @Post(':id/pause')
  pause(@OrgId() orgId: string, @Param('id') id: string) {
    return this.campaigns.pause(orgId, id);
  }

  @Post(':id/cancel')
  cancel(@OrgId() orgId: string, @Param('id') id: string) {
    return this.campaigns.cancel(orgId, id);
  }
}
