import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { QUEUE } from 'src/whatsapp/queue/queue.constants';
import { CampaignsService } from './campaigns.service';
import { CampaignsController } from './campaigns.controller';
import { SegmentsService } from './segments.service';
import { CampaignDispatchProcessor } from './queue/campaign-dispatch.processor';

@Module({
  imports: [
    BullModule.registerQueue(
      { name: QUEUE.CAMPAIGN_DISPATCH },
      { name: QUEUE.MESSAGE_SEND },
    ),
  ],
  controllers: [CampaignsController],
  providers: [CampaignsService, SegmentsService, CampaignDispatchProcessor],
  exports: [CampaignsService, SegmentsService],
})
export class CampaignsModule {}
