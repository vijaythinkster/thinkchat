import {
  BadRequestException, Injectable, NotFoundException,
} from '@nestjs/common';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { QUEUE, JOB, DispatchCampaignJob } from 'src/whatsapp/queue/queue.constants';
import { SegmentsService } from './segments.service';
import {
  AudiencePreviewDto, CreateCampaignDto, ScheduleCampaignDto, SegmentDefinitionDto,
} from './dto/campaign.dto';

@Injectable()
export class CampaignsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly segments: SegmentsService,
    @InjectQueue(QUEUE.CAMPAIGN_DISPATCH) private readonly dispatchQueue: Queue,
  ) {}

  async create(organizationId: string, dto: CreateCampaignDto, userId?: string) {
    const template = await this.prisma.template.findFirst({
      where: { id: dto.templateId, organizationId, deletedAt: null },
    });
    if (!template) throw new NotFoundException('Template not found');
    if (template.status !== 'APPROVED')
      throw new BadRequestException('Template must be APPROVED before use in a campaign');

    const number = await this.prisma.whatsAppNumber.findFirst({
      where: { id: dto.whatsAppNumberId, organizationId },
    });
    if (!number) throw new NotFoundException('WhatsApp number not found');

    // Persist an inline segment definition if provided.
    let segmentId = dto.segmentId;
    if (!segmentId && dto.segment) {
      const seg = await this.prisma.segment.create({
        data: {
          organizationId, name: `${dto.name} — audience`,
          definition: dto.segment as any,
        },
      });
      segmentId = seg.id;
    }
    if (!segmentId) throw new BadRequestException('A segment or segment definition is required');

    return this.prisma.campaign.create({
      data: {
        organizationId, name: dto.name, templateId: dto.templateId,
        whatsAppNumberId: dto.whatsAppNumberId, segmentId,
        createdByUserId: userId, status: 'DRAFT',
        variables: (dto.variables ?? {}) as any,
      },
    });
  }

  list(organizationId: string) {
    return this.prisma.campaign.findMany({
      where: { organizationId },
      orderBy: { createdAt: 'desc' },
      include: { template: { select: { name: true } } },
    });
  }

  async get(organizationId: string, id: string) {
    const campaign = await this.prisma.campaign.findFirst({
      where: { id, organizationId },
      include: { template: true, whatsAppNumber: true, segment: true },
    });
    if (!campaign) throw new NotFoundException('Campaign not found');
    return campaign;
  }

  /** Audience size for a definition (used in the create UI before launch). */
  previewAudience(organizationId: string, dto: AudiencePreviewDto) {
    return this.segments
      .countAudience(organizationId, dto.segment)
      .then((count) => ({ count }));
  }

  async launchNow(organizationId: string, id: string) {
    const campaign = await this.assertLaunchable(organizationId, id);
    await this.prisma.campaign.update({
      where: { id: campaign.id }, data: { status: 'SCHEDULED' },
    });
    await this.enqueueDispatch({ organizationId, campaignId: id });
    return { status: 'SCHEDULED', launchedAt: new Date().toISOString() };
  }

  async schedule(organizationId: string, id: string, dto: ScheduleCampaignDto) {
    const campaign = await this.assertLaunchable(organizationId, id);
    const when = new Date(dto.scheduledAt);
    const delay = Math.max(0, when.getTime() - Date.now());
    await this.prisma.campaign.update({
      where: { id: campaign.id },
      data: { status: 'SCHEDULED', scheduledAt: when, recurrence: (dto.recurrence ?? null) as any },
    });
    await this.enqueueDispatch({ organizationId, campaignId: id }, delay);
    return { status: 'SCHEDULED', scheduledAt: when.toISOString() };
  }

  async pause(organizationId: string, id: string) {
    await this.get(organizationId, id);
    await this.prisma.campaign.update({ where: { id }, data: { status: 'PAUSED' } });
    return { status: 'PAUSED' };
  }

  async cancel(organizationId: string, id: string) {
    await this.get(organizationId, id);
    await this.prisma.campaign.update({ where: { id }, data: { status: 'CANCELED' } });
    return { status: 'CANCELED' };
  }

  /** Aggregate recipient states into the funnel + rates the dashboard renders. */
  async analytics(organizationId: string, id: string) {
    await this.get(organizationId, id);
    const grouped = await this.prisma.campaignRecipient.groupBy({
      by: ['status'], where: { campaignId: id, organizationId }, _count: { _all: true },
    });
    const by: Record<string, number> = {};
    for (const g of grouped) by[g.status] = g._count._all;

    const sent = (by.SENT ?? 0) + (by.DELIVERED ?? 0) + (by.READ ?? 0)
      + (by.CLICKED ?? 0) + (by.REPLIED ?? 0);
    const delivered = (by.DELIVERED ?? 0) + (by.READ ?? 0) + (by.CLICKED ?? 0) + (by.REPLIED ?? 0);
    const read = (by.READ ?? 0) + (by.CLICKED ?? 0) + (by.REPLIED ?? 0);
    const total = sent + (by.PENDING ?? 0) + (by.FAILED ?? 0);
    const pct = (n: number, d: number) => (d > 0 ? Math.round((n / d) * 1000) / 10 : 0);

    return {
      campaignId: id,
      totals: {
        audience: total, pending: by.PENDING ?? 0, sent, delivered, read,
        clicked: by.CLICKED ?? 0, replied: by.REPLIED ?? 0, failed: by.FAILED ?? 0,
      },
      rates: {
        deliveryRate: pct(delivered, sent),
        readRate: pct(read, delivered),
        clickRate: pct(by.CLICKED ?? 0, delivered),
        replyRate: pct(by.REPLIED ?? 0, delivered),
        failureRate: pct(by.FAILED ?? 0, total),
      },
    };
  }

  // --- helpers ---
  private async assertLaunchable(organizationId: string, id: string) {
    const campaign = await this.get(organizationId, id);
    if (!['DRAFT', 'SCHEDULED', 'PAUSED'].includes(campaign.status))
      throw new BadRequestException(`Cannot launch a campaign in status ${campaign.status}`);
    return campaign;
  }

  private enqueueDispatch(data: DispatchCampaignJob, delayMs = 0) {
    return this.dispatchQueue.add(JOB.DISPATCH_CAMPAIGN, data, {
      delay: delayMs,
      attempts: 3,
      backoff: { type: 'exponential', delay: 5000 },
      removeOnComplete: 100,
      removeOnFail: 500,
    });
  }
}
