import { Type } from 'class-transformer';
import {
  IsArray, IsEnum, IsISO8601, IsObject, IsOptional, IsString, ValidateNested,
} from 'class-validator';

export type SegmentMatch = 'all' | 'any';
export type ConditionOp = 'equals' | 'not' | 'contains' | 'in' | 'gt' | 'lt' | 'exists' | 'hasLabel';

export class SegmentCondition {
  @IsString() field!: string;        // name | phone | email | countryCode | optedIn | attr:<key> | label
  @IsString() op!: ConditionOp;
  @IsOptional() value?: unknown;
}

export class SegmentDefinitionDto {
  @IsEnum(['all', 'any'] as any) match: SegmentMatch = 'all';
  @IsArray() @ValidateNested({ each: true }) @Type(() => SegmentCondition)
  conditions: SegmentCondition[] = [];
}

export class CreateCampaignDto {
  @IsString() name!: string;
  @IsString() templateId!: string;
  @IsString() whatsAppNumberId!: string;
  @IsOptional() @IsString() segmentId?: string;
  @IsOptional() @ValidateNested() @Type(() => SegmentDefinitionDto) segment?: SegmentDefinitionDto;
  // Template variable mapping, e.g. { bodyParams: ["{{name}}", "Diwali Sale"] }
  @IsOptional() @IsObject() variables?: Record<string, unknown>;
}

export class ScheduleCampaignDto {
  @IsISO8601() scheduledAt!: string;
  // Optional recurrence, e.g. { everyDays: 7 } or { cron: "0 10 * * 1" }
  @IsOptional() @IsObject() recurrence?: Record<string, unknown>;
}

export class AudiencePreviewDto {
  @ValidateNested() @Type(() => SegmentDefinitionDto) segment!: SegmentDefinitionDto;
}
