import { Processor, WorkerHost, InjectQueue } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job, Queue } from 'bullmq';
import { PrismaService } from 'src/common/prisma/prisma.service';
import {
  DispatchCampaignJob, JOB, QUEUE, SendMessageJob,
} from 'src/whatsapp/queue/queue.constants';
import { SegmentsService } from '../segments.service';
import { SegmentDefinitionDto } from '../dto/campaign.dto';

const PAGE = 500; // recipients resolved + enqueued per dispatch job

/**
 * Fans a campaign out to its audience. Resolves the segment in pages, creates
 * PENDING CampaignRecipient rows (idempotent via the unique [campaignId,contactId]),
 * then for each builds a personalized template Message and hands it to the shared
 * MESSAGE_SEND worker. Large audiences re-enqueue the next page via cursor.
 */
@Processor(QUEUE.CAMPAIGN_DISPATCH, { concurrency: 4 })
export class CampaignDispatchProcessor extends WorkerHost {
  private readonly logger = new Logger(CampaignDispatchProcessor.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly segments: SegmentsService,
    @InjectQueue(QUEUE.MESSAGE_SEND) private readonly sendQueue: Queue,
    @InjectQueue(QUEUE.CAMPAIGN_DISPATCH) private readonly dispatchQueue: Queue,
  ) {
    super();
  }

  async process(job: Job<DispatchCampaignJob>): Promise<void> {
    if (job.name !== JOB.DISPATCH_CAMPAIGN) return;
    const { organizationId, campaignId, cursor } = job.data;

    const campaign = await this.prisma.campaign.findFirst({
      where: { id: campaignId, organizationId },
      include: { template: true, segment: true },
    });
    if (!campaign) return;
    if (['PAUSED', 'CANCELED', 'COMPLETED'].includes(campaign.status)) {
      this.logger.log(`Skipping dispatch for ${campaignId} (status ${campaign.status})`);
      return;
    }
    if (!campaign.segment || !campaign.template) {
      this.logger.warn(`Campaign ${campaignId} missing segment/template`);
      return;
    }

    if (!cursor) {
      await this.prisma.campaign.update({
        where: { id: campaignId }, data: { status: 'RUNNING', startedAt: new Date() },
      });
    }

    const def = campaign.segment.definition as unknown as SegmentDefinitionDto;
    const contacts = await this.segments.resolvePage(organizationId, def, PAGE, cursor);

    if (contacts.length === 0) {
      await this.finish(campaign.id, organizationId, campaign.recurrence);
      return;
    }

    // 1) Idempotently create recipient rows for this page.
    await this.prisma.campaignRecipient.createMany({
      data: contacts.map((c) => ({
        organizationId, campaignId, contactId: c.id, status: 'PENDING' as const,
      })),
      skipDuplicates: true,
    });
    const recipients = await this.prisma.campaignRecipient.findMany({
      where: { campaignId, contactId: { in: contacts.map((c) => c.id) }, status: 'PENDING' },
      include: { contact: { select: { id: true, phone: true, name: true } } },
    });

    // 2) For each recipient: ensure a conversation, create the template Message,
    //    and enqueue the actual send on the shared MESSAGE_SEND worker.
    for (const r of recipients) {
      const conversation = await this.ensureConversation(
        organizationId, r.contactId, campaign.whatsAppNumberId,
      );
      const graph = this.buildTemplatePayload(
        r.contact.phone, campaign.template, campaign.variables as any, r.contact,
      );
      const message = await this.prisma.message.create({
        data: {
          organizationId, conversationId: conversation.id,
          whatsAppNumberId: campaign.whatsAppNumberId, templateId: campaign.templateId,
          direction: 'OUTBOUND', type: 'TEMPLATE', status: 'QUEUED',
          payload: { graph, campaignRecipientId: r.id } as any,
        },
      });
      await this.sendQueue.add(
        JOB.SEND_MESSAGE,
        { organizationId, messageId: message.id } as SendMessageJob,
        { attempts: 5, backoff: { type: 'exponential', delay: 4000 }, removeOnComplete: 1000 },
      );
    }

    // 3) More to do? Re-enqueue the next page; else finish/recur.
    const last = contacts[contacts.length - 1];
    if (contacts.length === PAGE) {
      await this.dispatchQueue.add(
        JOB.DISPATCH_CAMPAIGN, { organizationId, campaignId, cursor: last.id }, { removeOnComplete: 50 },
      );
    } else {
      await this.finish(campaign.id, organizationId, campaign.recurrence);
    }
  }

  /** Reuse the most recent conversation for this contact+number, else open one. */
  private async ensureConversation(organizationId: string, contactId: string, whatsAppNumberId: string) {
    const existing = await this.prisma.conversation.findFirst({
      where: { organizationId, contactId, whatsAppNumberId },
      orderBy: { lastMessageAt: 'desc' },
    });
    if (existing) return existing;
    return this.prisma.conversation.create({
      data: { organizationId, contactId, whatsAppNumberId, status: 'OPEN', lastMessageAt: new Date() },
    });
  }

  /** Build a WhatsApp template payload, substituting {{name}} / {{phone}} per contact. */
  private buildTemplatePayload(
    to: string, template: { name: string; language: string },
    variables: { bodyParams?: string[] } | null,
    contact: { name: string | null; phone: string },
  ) {
    const subst = (s: string) =>
      s.replace(/\{\{\s*name\s*\}\}/gi, contact.name ?? 'there')
       .replace(/\{\{\s*phone\s*\}\}/gi, contact.phone);
    const components =
      variables?.bodyParams?.length
        ? [{ type: 'body', parameters: variables.bodyParams.map((p) => ({ type: 'text', text: subst(p) })) }]
        : undefined;
    return {
      messaging_product: 'whatsapp', to, type: 'template',
      template: { name: template.name, language: { code: template.language }, ...(components ? { components } : {}) },
    };
  }

  /** Mark COMPLETED, or schedule the next occurrence for recurring campaigns. */
  private async finish(campaignId: string, organizationId: string, recurrence: unknown) {
    const rec = recurrence as { everyDays?: number } | null;
    if (rec?.everyDays && rec.everyDays > 0) {
      const next = new Date(Date.now() + rec.everyDays * 86_400_000);
      await this.prisma.campaign.update({
        where: { id: campaignId }, data: { status: 'SCHEDULED', scheduledAt: next, startedAt: null },
      });
      await this.dispatchQueue.add(
        JOB.DISPATCH_CAMPAIGN, { organizationId, campaignId },
        { delay: rec.everyDays * 86_400_000, removeOnComplete: 50 },
      );
      this.logger.log(`Campaign ${campaignId} recurs on ${next.toISOString()}`);
      return;
    }
    await this.prisma.campaign.update({
      where: { id: campaignId }, data: { status: 'COMPLETED', completedAt: new Date() },
    });
  }
}
