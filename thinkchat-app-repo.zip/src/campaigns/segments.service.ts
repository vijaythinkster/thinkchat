import { BadRequestException, Injectable } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { SegmentCondition, SegmentDefinitionDto } from './dto/campaign.dto';

/**
 * Translates a saved segment definition (safe, whitelisted filter rules) into a
 * Prisma query over Contacts. Never accepts raw SQL or arbitrary fields.
 */
@Injectable()
export class SegmentsService {
  constructor(private readonly prisma: PrismaService) {}

  private condition(c: SegmentCondition): Prisma.ContactWhereInput {
    switch (c.field) {
      case 'name': case 'email': case 'phone': case 'countryCode': {
        const v = String(c.value ?? '');
        if (c.op === 'contains') return { [c.field]: { contains: v, mode: 'insensitive' } };
        if (c.op === 'not') return { NOT: { [c.field]: v } };
        if (c.op === 'in') return { [c.field]: { in: (c.value as string[]) ?? [] } };
        if (c.op === 'exists') return { NOT: { [c.field]: null } };
        return { [c.field]: v };
      }
      case 'optedIn':
        return { optedIn: Boolean(c.value) };
      case 'label':
        return { contactLabels: { some: { labelId: String(c.value) } } };
      default: {
        // attribute fields: "attr:plan", op equals/exists on the JSON column
        if (c.field.startsWith('attr:')) {
          const key = c.field.slice(5);
          if (c.op === 'exists') return { attributes: { path: [key], not: Prisma.DbNull } };
          return { attributes: { path: [key], equals: c.value as Prisma.InputJsonValue } };
        }
        throw new BadRequestException(`Unsupported segment field: ${c.field}`);
      }
    }
  }

  buildWhere(organizationId: string, def: SegmentDefinitionDto): Prisma.ContactWhereInput {
    const clauses = (def.conditions ?? []).map((c) => this.condition(c));
    const combined: Prisma.ContactWhereInput =
      def.match === 'any' ? { OR: clauses } : { AND: clauses };
    return {
      organizationId,
      deletedAt: null,
      optedIn: true, // marketing requires opt-in
      ...(clauses.length ? combined : {}),
    };
  }

  countAudience(organizationId: string, def: SegmentDefinitionDto) {
    return this.prisma.contact.count({ where: this.buildWhere(organizationId, def) });
  }

  /** Stream-friendly page of recipients to enqueue. */
  resolvePage(organizationId: string, def: SegmentDefinitionDto, take: number, cursor?: string) {
    return this.prisma.contact.findMany({
      where: this.buildWhere(organizationId, def),
      select: { id: true, phone: true, name: true, countryCode: true },
      orderBy: { id: 'asc' },
      take,
      ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
    });
  }
}
