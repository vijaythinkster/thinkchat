import { Global, Module } from '@nestjs/common';
import { PrismaService } from './prisma/prisma.service';
import { EncryptionService } from './security/encryption.service';
import { StorageService } from './storage/storage.service';

/**
 * Global providers shared across feature modules: the Prisma client, secret
 * encryption, and object storage. Marked @Global so they can be injected
 * anywhere without re-importing.
 */
@Global()
@Module({
  providers: [PrismaService, EncryptionService, StorageService],
  exports: [PrismaService, EncryptionService, StorageService],
})
export class CommonModule {}
