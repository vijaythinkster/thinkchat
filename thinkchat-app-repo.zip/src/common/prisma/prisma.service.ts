import { Injectable, OnModuleInit } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { tenantMiddleware } from '../tenant/tenant.middleware';

/**
 * Shared Prisma client with two layers of tenant isolation:
 *  1) the tenant middleware ($use) auto-scopes queries to the org in async-local
 *     context (set by the JWT guard);
 *  2) `forTenant()` sets the PostgreSQL RLS GUC inside a transaction for code
 *     paths that need the database itself to enforce isolation.
 *
 * Note on RLS + pooling: a bare `SET app.current_org_id` is not reliable across a
 * pooled connection, so hard RLS enforcement must run inside a transaction
 * (SET LOCAL). Request-path queries lean on the middleware; `forTenant` is for
 * sensitive operations and for verifying the RLS backstop.
 */
@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit {
  async onModuleInit() {
    this.$use(tenantMiddleware());
    await this.$connect();
  }

  /** Run a unit of work with the RLS session GUC bound to an org. */
  forTenant<T>(organizationId: string, fn: (tx: Prisma_TxClient) => Promise<T>): Promise<T> {
    return this.$transaction(async (tx) => {
      await tx.$executeRawUnsafe(
        "SELECT set_config('app.current_org_id', $1, true)",
        organizationId,
      );
      return fn(tx as unknown as Prisma_TxClient);
    });
  }
}

// Minimal alias for the transactional client type used by forTenant callbacks.
type Prisma_TxClient = Omit<PrismaClient, '$connect' | '$disconnect' | '$on' | '$transaction' | '$use' | '$extends'>;
