import { Injectable } from '@nestjs/common';

export interface StoredObject { key: string; url: string }

/**
 * S3-backed object storage abstraction (media). Implementation lives in the
 * shared infra module; interface shown here for the WhatsApp media flow.
 */
@Injectable()
export class StorageService {
  async putObject(
    _organizationId: string,
    _key: string,
    _body: Buffer,
    _contentType: string,
  ): Promise<StoredObject> {
    // s3.putObject({ Bucket, Key: scopedKey, Body, ContentType }) -> signed/CDN url
    throw new Error('StorageService.putObject not implemented in this excerpt');
  }
}
