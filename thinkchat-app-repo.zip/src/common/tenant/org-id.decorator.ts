import { createParamDecorator, ExecutionContext } from '@nestjs/common';

/**
 * Pulls the resolved tenant id off the request. The global AuthGuard validates
 * the JWT and the TenantGuard sets request.organizationId (Phase 13). Workers do
 * not use this — they receive organizationId explicitly in the job payload.
 */
export const OrgId = createParamDecorator(
  (_data: unknown, ctx: ExecutionContext): string => {
    const req = ctx.switchToHttp().getRequest();
    return req.organizationId;
  },
);
