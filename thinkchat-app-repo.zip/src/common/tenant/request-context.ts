import { AsyncLocalStorage } from 'async_hooks';

/** Per-request tenant identity, set by the JWT guard and read by the Prisma middleware. */
export interface TenantContext {
  userId: string;
  organizationId: string;
  permissions: string[];
  roles: string[];
  /**
   * When true, the Prisma tenant middleware skips org-scoping for this request.
   * Set ONLY by PlatformAdminGuard after verifying the caller is a platform
   * super-admin, so the cross-tenant admin panel can read/write every org.
   */
  bypassTenantScope?: boolean;
}

const als = new AsyncLocalStorage<TenantContext>();

export const tenantStorage = als;
export const getTenantContext = (): TenantContext | undefined => als.getStore();
export const enterTenantContext = (ctx: TenantContext): void => als.enterWith(ctx);
export const runWithTenant = <T>(ctx: TenantContext, fn: () => T): T => als.run(ctx, fn);
