import { Prisma } from '@prisma/client';
import { TENANT_MODELS } from './tenant-models';
import { getTenantContext } from './request-context';

/**
 * App-layer tenant isolation. Reads the current org from async-local context and
 * scopes reads, bulk ops, and creates to that org. update/delete/upsert keep their
 * unique-where semantics (so callers still get a row back) and rely on the service
 * convention of fetching by org first + PostgreSQL RLS as the hard backstop.
 *
 * Workers run outside request context (no org in ALS) and pass organizationId
 * explicitly, so this middleware is a no-op for them.
 */
export function tenantMiddleware(): Prisma.Middleware {
  return async (params, next) => {
    const ctx = getTenantContext();
    // Platform super-admin requests run unscoped (verified by PlatformAdminGuard).
    if (ctx?.bypassTenantScope) return next(params);
    const orgId = ctx?.organizationId;
    if (!orgId || !params.model || !TENANT_MODELS.has(params.model)) return next(params);

    switch (params.action) {
      case 'findUnique':
      case 'findUniqueOrThrow': {
        // unique-where can't take organizationId; widen to findFirst + org filter
        params.action = params.action === 'findUnique' ? 'findFirst' : 'findFirstOrThrow';
        params.args = params.args ?? {};
        params.args.where = { ...(params.args.where ?? {}), organizationId: orgId };
        break;
      }
      case 'findFirst':
      case 'findFirstOrThrow':
      case 'findMany':
      case 'count':
      case 'aggregate':
      case 'groupBy':
      case 'updateMany':
      case 'deleteMany': {
        params.args = params.args ?? {};
        params.args.where = { ...(params.args.where ?? {}), organizationId: orgId };
        break;
      }
      case 'create': {
        params.args = params.args ?? {};
        params.args.data = { organizationId: orgId, ...(params.args.data ?? {}) };
        break;
      }
      case 'createMany': {
        params.args = params.args ?? {};
        const data = params.args.data;
        if (Array.isArray(data)) {
          params.args.data = data.map((d: Record<string, unknown>) => ({ organizationId: orgId, ...d }));
        } else if (data) {
          params.args.data = { organizationId: orgId, ...data };
        }
        break;
      }
      case 'upsert': {
        params.args = params.args ?? {};
        params.args.create = { organizationId: orgId, ...(params.args.create ?? {}) };
        break;
      }
      default:
        break;
    }
    return next(params);
  };
}
