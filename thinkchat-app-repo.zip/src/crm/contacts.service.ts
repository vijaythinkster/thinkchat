import { Injectable, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from 'src/common/prisma/prisma.service';
import {
  CreateContactDto, ImportContactsDto, ListContactsDto, UpdateContactDto,
} from './dto/crm.dto';

@Injectable()
export class ContactsService {
  constructor(private readonly prisma: PrismaService) {}

  async list(organizationId: string, q: ListContactsDto) {
    const take = Math.min(q.take ?? 50, 200);
    const where: Prisma.ContactWhereInput = {
      organizationId, deletedAt: null,
      ...(q.optedIn !== undefined ? { optedIn: q.optedIn } : {}),
      ...(q.labelId ? { contactLabels: { some: { labelId: q.labelId } } } : {}),
      ...(q.q
        ? {
            OR: [
              { name: { contains: q.q, mode: 'insensitive' } },
              { phone: { contains: q.q } },
              { email: { contains: q.q, mode: 'insensitive' } },
            ],
          }
        : {}),
    };
    const items = await this.prisma.contact.findMany({
      where, orderBy: { createdAt: 'desc' }, take: take + 1,
      ...(q.cursor ? { cursor: { id: q.cursor }, skip: 1 } : {}),
      include: { contactLabels: { include: { label: true } } },
    });
    const nextCursor = items.length > take ? items[take].id : null;
    return { items: items.slice(0, take), nextCursor };
  }

  async create(organizationId: string, dto: CreateContactDto) {
    const contact = await this.prisma.contact.create({
      data: {
        organizationId, phone: dto.phone, name: dto.name, email: dto.email,
        countryCode: dto.countryCode, optedIn: dto.optedIn ?? true,
        attributes: (dto.attributes ?? {}) as any,
      },
    });
    if (dto.labelIds?.length) await this.setLabels(organizationId, contact.id, dto.labelIds);
    return this.get(organizationId, contact.id);
  }

  async update(organizationId: string, id: string, dto: UpdateContactDto) {
    await this.assertExists(organizationId, id);
    // Merge custom attributes rather than overwrite.
    let attributes: any;
    if (dto.attributes) {
      const existing = await this.prisma.contact.findUnique({ where: { id }, select: { attributes: true } });
      attributes = { ...((existing?.attributes as object) ?? {}), ...dto.attributes };
    }
    await this.prisma.contact.update({
      where: { id },
      data: {
        name: dto.name, email: dto.email, countryCode: dto.countryCode,
        optedIn: dto.optedIn, ...(attributes ? { attributes } : {}),
      },
    });
    return this.get(organizationId, id);
  }

  async softDelete(organizationId: string, id: string) {
    await this.assertExists(organizationId, id);
    await this.prisma.contact.update({ where: { id }, data: { deletedAt: new Date() } });
    return { deleted: true };
  }

  /** Contact profile + full activity timeline. */
  async get(organizationId: string, id: string) {
    const contact = await this.prisma.contact.findFirst({
      where: { id, organizationId },
      include: { contactLabels: { include: { label: true } } },
    });
    if (!contact) throw new NotFoundException('Contact not found');

    const [notes, deals, tasks, conversations] = await Promise.all([
      this.prisma.note.findMany({
        where: { organizationId, contactId: id, deletedAt: null },
        orderBy: { createdAt: 'desc' }, take: 50,
        include: { author: { select: { id: true, name: true } } },
      }),
      this.prisma.deal.findMany({
        where: { organizationId, contactId: id, deletedAt: null },
        orderBy: { createdAt: 'desc' },
        include: { stage: { select: { name: true } } },
      }),
      this.prisma.task.findMany({
        where: { organizationId, contactId: id, deletedAt: null },
        orderBy: { dueAt: 'asc' },
      }),
      this.prisma.conversation.findMany({
        where: { organizationId, contactId: id },
        orderBy: { lastMessageAt: 'desc' }, take: 10,
        select: { id: true, status: true, lastMessageAt: true },
      }),
    ]);
    return { contact, notes, deals, tasks, conversations };
  }

  async setLabels(organizationId: string, contactId: string, labelIds: string[]) {
    await this.assertExists(organizationId, contactId);
    // Only allow labels owned by this org.
    const valid = await this.prisma.label.findMany({
      where: { organizationId, id: { in: labelIds } }, select: { id: true },
    });
    const validIds = valid.map((l) => l.id);
    await this.prisma.$transaction([
      this.prisma.contactLabel.deleteMany({ where: { contactId } }),
      this.prisma.contactLabel.createMany({
        data: validIds.map((labelId) => ({ contactId, labelId })), skipDuplicates: true,
      }),
    ]);
    return this.get(organizationId, contactId);
  }

  /** Bulk upsert by [organizationId, phone]; merges attributes. Chunked. */
  async importContacts(organizationId: string, dto: ImportContactsDto) {
    let created = 0, updated = 0, skipped = 0;
    const chunks = chunk(dto.rows, 100);
    for (const rows of chunks) {
      await this.prisma.$transaction(async (tx) => {
        for (const r of rows) {
          if (!r.phone) { skipped++; continue; }
          const existing = await tx.contact.findUnique({
            where: { organizationId_phone: { organizationId, phone: r.phone } },
            select: { id: true, attributes: true },
          });
          if (existing) {
            await tx.contact.update({
              where: { id: existing.id },
              data: {
                name: r.name ?? undefined, email: r.email ?? undefined,
                countryCode: r.countryCode ?? undefined, deletedAt: null,
                attributes: { ...((existing.attributes as object) ?? {}), ...(r.attributes ?? {}) },
              },
            });
            updated++;
          } else {
            await tx.contact.create({
              data: {
                organizationId, phone: r.phone, name: r.name, email: r.email,
                countryCode: r.countryCode, attributes: (r.attributes ?? {}) as any,
              },
            });
            created++;
          }
        }
      });
    }
    return { created, updated, skipped, total: dto.rows.length };
  }

  private async assertExists(organizationId: string, id: string) {
    const c = await this.prisma.contact.findFirst({ where: { id, organizationId }, select: { id: true } });
    if (!c) throw new NotFoundException('Contact not found');
  }
}

function chunk<T>(arr: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}
