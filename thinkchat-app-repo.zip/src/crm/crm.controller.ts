import {
  Body, Controller, Delete, Get, Param, Patch, Post, Query,
} from '@nestjs/common';
import { TaskStatus } from '@prisma/client';
import { OrgId } from 'src/common/tenant/org-id.decorator';
import { ContactsService } from './contacts.service';
import { LabelsService } from './labels.service';
import { PipelinesService } from './pipelines.service';
import { DealsService } from './deals.service';
import { NotesService } from './notes.service';
import { TasksService } from './tasks.service';
import {
  AssignLabelsDto, CreateContactDto, CreateDealDto, CreateLabelDto, CreateNoteDto,
  CreateTaskDto, ImportContactsDto, ListContactsDto, MoveDealDto, UpdateContactDto,
} from './dto/crm.dto';

@Controller()
export class CrmController {
  constructor(
    private readonly contacts: ContactsService,
    private readonly labels: LabelsService,
    private readonly pipelines: PipelinesService,
    private readonly deals: DealsService,
    private readonly notes: NotesService,
    private readonly tasks: TasksService,
  ) {}

  // --- contacts ---
  @Get('contacts')
  listContacts(@OrgId() orgId: string, @Query() q: ListContactsDto) {
    return this.contacts.list(orgId, q);
  }
  @Post('contacts')
  createContact(@OrgId() orgId: string, @Body() dto: CreateContactDto) {
    return this.contacts.create(orgId, dto);
  }
  @Post('contacts/import')
  importContacts(@OrgId() orgId: string, @Body() dto: ImportContactsDto) {
    return this.contacts.importContacts(orgId, dto);
  }
  @Get('contacts/:id')
  getContact(@OrgId() orgId: string, @Param('id') id: string) {
    return this.contacts.get(orgId, id);
  }
  @Patch('contacts/:id')
  updateContact(@OrgId() orgId: string, @Param('id') id: string, @Body() dto: UpdateContactDto) {
    return this.contacts.update(orgId, id, dto);
  }
  @Delete('contacts/:id')
  deleteContact(@OrgId() orgId: string, @Param('id') id: string) {
    return this.contacts.softDelete(orgId, id);
  }
  @Post('contacts/:id/labels')
  setLabels(@OrgId() orgId: string, @Param('id') id: string, @Body() dto: AssignLabelsDto) {
    return this.contacts.setLabels(orgId, id, dto.labelIds);
  }

  // --- labels ---
  @Get('labels')
  listLabels(@OrgId() orgId: string) { return this.labels.list(orgId); }
  @Post('labels')
  createLabel(@OrgId() orgId: string, @Body() dto: CreateLabelDto) { return this.labels.create(orgId, dto); }
  @Delete('labels/:id')
  deleteLabel(@OrgId() orgId: string, @Param('id') id: string) { return this.labels.remove(orgId, id); }

  // --- pipeline / deals ---
  @Get('pipelines')
  listPipelines(@OrgId() orgId: string) { return this.pipelines.list(orgId); }
  @Get('pipelines/board')
  board(@OrgId() orgId: string, @Query('pipelineId') pipelineId?: string) {
    return this.pipelines.board(orgId, pipelineId);
  }
  @Post('deals')
  createDeal(@OrgId() orgId: string, @Body() dto: CreateDealDto) { return this.deals.create(orgId, dto); }
  @Patch('deals/:id/move')
  moveDeal(@OrgId() orgId: string, @Param('id') id: string, @Body() dto: MoveDealDto) {
    return this.deals.move(orgId, id, dto.stageId);
  }
  @Patch('deals/:id/won')
  winDeal(@OrgId() orgId: string, @Param('id') id: string) { return this.deals.setOutcome(orgId, id, 'WON'); }
  @Patch('deals/:id/lost')
  loseDeal(@OrgId() orgId: string, @Param('id') id: string) { return this.deals.setOutcome(orgId, id, 'LOST'); }

  // --- notes & tasks ---
  @Post('notes')
  createNote(@OrgId() orgId: string, @Body() dto: CreateNoteDto) { return this.notes.create(orgId, dto); }
  @Get('tasks')
  listTasks(@OrgId() orgId: string, @Query('assigneeUserId') a?: string, @Query('status') s?: TaskStatus) {
    return this.tasks.list(orgId, { assigneeUserId: a, status: s });
  }
  @Post('tasks')
  createTask(@OrgId() orgId: string, @Body() dto: CreateTaskDto) { return this.tasks.create(orgId, dto); }
  @Patch('tasks/:id/complete')
  completeTask(@OrgId() orgId: string, @Param('id') id: string) { return this.tasks.complete(orgId, id); }
}
