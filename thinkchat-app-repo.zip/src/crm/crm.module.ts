import { Module } from '@nestjs/common';
import { ContactsService } from './contacts.service';
import { LabelsService } from './labels.service';
import { PipelinesService } from './pipelines.service';
import { DealsService } from './deals.service';
import { NotesService } from './notes.service';
import { TasksService } from './tasks.service';
import { CrmController } from './crm.controller';

@Module({
  controllers: [CrmController],
  providers: [ContactsService, LabelsService, PipelinesService, DealsService, NotesService, TasksService],
  exports: [ContactsService, LabelsService, PipelinesService],
})
export class CrmModule {}
