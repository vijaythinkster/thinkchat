import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { PipelinesService } from './pipelines.service';
import { CreateDealDto } from './dto/crm.dto';

@Injectable()
export class DealsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly pipelines: PipelinesService,
  ) {}

  async create(organizationId: string, dto: CreateDealDto) {
    const pipeline = dto.pipelineId
      ? await this.prisma.pipeline.findFirst({ where: { id: dto.pipelineId, organizationId }, include: { stages: { orderBy: { order: 'asc' } } } })
      : await this.pipelines.ensureDefault(organizationId);
    if (!pipeline) throw new NotFoundException('Pipeline not found');

    const stageId = dto.stageId ?? pipeline.stages[0]?.id;
    if (!stageId) throw new BadRequestException('Pipeline has no stages');

    return this.prisma.deal.create({
      data: {
        organizationId, pipelineId: pipeline.id, stageId,
        contactId: dto.contactId, title: dto.title,
        value: dto.value ?? 0, currency: dto.currency ?? 'USD',
        ownerUserId: dto.ownerUserId, status: 'OPEN',
      },
    });
  }

  /** Move a deal to another stage (Kanban drag). Validates stage is in same pipeline. */
  async move(organizationId: string, dealId: string, stageId: string) {
    const deal = await this.prisma.deal.findFirst({ where: { id: dealId, organizationId } });
    if (!deal) throw new NotFoundException('Deal not found');
    const stage = await this.prisma.pipelineStage.findFirst({
      where: { id: stageId, pipelineId: deal.pipelineId },
    });
    if (!stage) throw new BadRequestException('Stage not in this pipeline');
    return this.prisma.deal.update({ where: { id: dealId }, data: { stageId } });
  }

  async setOutcome(organizationId: string, dealId: string, status: 'WON' | 'LOST') {
    const deal = await this.prisma.deal.findFirst({ where: { id: dealId, organizationId } });
    if (!deal) throw new NotFoundException('Deal not found');
    return this.prisma.deal.update({
      where: { id: dealId }, data: { status, closedAt: new Date() },
    });
  }
}
