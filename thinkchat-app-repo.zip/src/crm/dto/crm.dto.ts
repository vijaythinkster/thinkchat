import { Type } from 'class-transformer';
import {
  IsArray, IsBoolean, IsInt, IsNumber, IsObject, IsOptional, IsString, ValidateNested,
} from 'class-validator';

export class CreateContactDto {
  @IsString() phone!: string;
  @IsOptional() @IsString() name?: string;
  @IsOptional() @IsString() email?: string;
  @IsOptional() @IsString() countryCode?: string;
  @IsOptional() @IsObject() attributes?: Record<string, unknown>;
  @IsOptional() @IsBoolean() optedIn?: boolean;
  @IsOptional() @IsArray() labelIds?: string[];
}

export class UpdateContactDto {
  @IsOptional() @IsString() name?: string;
  @IsOptional() @IsString() email?: string;
  @IsOptional() @IsString() countryCode?: string;
  @IsOptional() @IsObject() attributes?: Record<string, unknown>;
  @IsOptional() @IsBoolean() optedIn?: boolean;
}

export class ListContactsDto {
  @IsOptional() @IsString() q?: string;          // search name/phone/email
  @IsOptional() @IsString() labelId?: string;
  @IsOptional() @IsBoolean() @Type(() => Boolean) optedIn?: boolean;
  @IsOptional() @IsString() cursor?: string;
  @IsOptional() @IsInt() @Type(() => Number) take?: number;
}

export class AssignLabelsDto {
  @IsArray() labelIds!: string[];
}

export class CreateLabelDto {
  @IsString() name!: string;
  @IsOptional() @IsString() color?: string;
}

class ImportRow {
  @IsString() phone!: string;
  @IsOptional() @IsString() name?: string;
  @IsOptional() @IsString() email?: string;
  @IsOptional() @IsString() countryCode?: string;
  @IsOptional() @IsObject() attributes?: Record<string, unknown>;
}
export class ImportContactsDto {
  @IsArray() @ValidateNested({ each: true }) @Type(() => ImportRow) rows!: ImportRow[];
}

export class CreateDealDto {
  @IsString() title!: string;
  @IsOptional() @IsString() pipelineId?: string;
  @IsOptional() @IsString() stageId?: string;
  @IsOptional() @IsString() contactId?: string;
  @IsOptional() @IsNumber() value?: number;
  @IsOptional() @IsString() currency?: string;
  @IsOptional() @IsString() ownerUserId?: string;
}

export class MoveDealDto {
  @IsString() stageId!: string;
}

export class CreateNoteDto {
  @IsString() body!: string;
  @IsOptional() @IsString() contactId?: string;
  @IsOptional() @IsString() dealId?: string;
}

export class CreateTaskDto {
  @IsString() title!: string;
  @IsOptional() @IsString() description?: string;
  @IsOptional() @IsString() assigneeUserId?: string;
  @IsOptional() @IsString() contactId?: string;
  @IsOptional() @IsString() dealId?: string;
  @IsOptional() @IsString() dueAt?: string;
}
