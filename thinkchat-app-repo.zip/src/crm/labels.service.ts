import { Injectable } from '@nestjs/common';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { CreateLabelDto } from './dto/crm.dto';

@Injectable()
export class LabelsService {
  constructor(private readonly prisma: PrismaService) {}

  list(organizationId: string) {
    return this.prisma.label.findMany({ where: { organizationId }, orderBy: { name: 'asc' } });
  }

  create(organizationId: string, dto: CreateLabelDto) {
    return this.prisma.label.create({
      data: { organizationId, name: dto.name, color: dto.color ?? '#888888' },
    });
  }

  async remove(organizationId: string, id: string) {
    await this.prisma.label.deleteMany({ where: { id, organizationId } });
    return { deleted: true };
  }
}
