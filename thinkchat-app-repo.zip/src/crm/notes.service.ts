import { BadRequestException, Injectable } from '@nestjs/common';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { CreateNoteDto } from './dto/crm.dto';

@Injectable()
export class NotesService {
  constructor(private readonly prisma: PrismaService) {}

  create(organizationId: string, dto: CreateNoteDto, authorUserId?: string) {
    if (!dto.contactId && !dto.dealId)
      throw new BadRequestException('Note must attach to a contact or deal');
    return this.prisma.note.create({
      data: {
        organizationId, authorUserId, body: dto.body,
        contactId: dto.contactId, dealId: dto.dealId,
      },
    });
  }
}
