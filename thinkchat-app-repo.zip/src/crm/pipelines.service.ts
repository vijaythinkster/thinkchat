import { Injectable } from '@nestjs/common';
import { PrismaService } from 'src/common/prisma/prisma.service';

const DEFAULT_STAGES = [
  { name: 'New', order: 1, probability: 10 },
  { name: 'Contacted', order: 2, probability: 25 },
  { name: 'Qualified', order: 3, probability: 50 },
  { name: 'Proposal', order: 4, probability: 75 },
  { name: 'Closing', order: 5, probability: 90 },
];

@Injectable()
export class PipelinesService {
  constructor(private readonly prisma: PrismaService) {}

  /** Idempotently ensure the org has a default pipeline with seeded stages. */
  async ensureDefault(organizationId: string) {
    const existing = await this.prisma.pipeline.findFirst({
      where: { organizationId, isDefault: true, deletedAt: null },
      include: { stages: { orderBy: { order: 'asc' } } },
    });
    if (existing) return existing;
    return this.prisma.pipeline.create({
      data: {
        organizationId, name: 'Sales pipeline', isDefault: true,
        stages: { create: DEFAULT_STAGES },
      },
      include: { stages: { orderBy: { order: 'asc' } } },
    });
  }

  async list(organizationId: string) {
    const pipelines = await this.prisma.pipeline.findMany({
      where: { organizationId, deletedAt: null },
      include: { stages: { orderBy: { order: 'asc' } } },
      orderBy: { createdAt: 'asc' },
    });
    return pipelines.length ? pipelines : [await this.ensureDefault(organizationId)];
  }

  /** Kanban board: stages, each with its open deals. */
  async board(organizationId: string, pipelineId?: string) {
    const pipeline = pipelineId
      ? await this.prisma.pipeline.findFirst({
          where: { id: pipelineId, organizationId },
          include: { stages: { orderBy: { order: 'asc' } } },
        })
      : await this.ensureDefault(organizationId);
    if (!pipeline) return { pipeline: null, columns: [] };

    const deals = await this.prisma.deal.findMany({
      where: { organizationId, pipelineId: pipeline.id, status: 'OPEN', deletedAt: null },
      include: { contact: { select: { id: true, name: true, phone: true } } },
      orderBy: { updatedAt: 'desc' },
    });

    const columns = pipeline.stages.map((stage) => ({
      stage,
      deals: deals.filter((d) => d.stageId === stage.id),
      totalValue: deals
        .filter((d) => d.stageId === stage.id)
        .reduce((sum, d) => sum + Number(d.value), 0),
    }));
    return { pipeline, columns };
  }
}
