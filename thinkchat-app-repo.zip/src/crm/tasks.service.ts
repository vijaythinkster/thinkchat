import { Injectable } from '@nestjs/common';
import { Prisma, TaskStatus } from '@prisma/client';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { CreateTaskDto } from './dto/crm.dto';

@Injectable()
export class TasksService {
  constructor(private readonly prisma: PrismaService) {}

  list(organizationId: string, filter: { assigneeUserId?: string; status?: TaskStatus } = {}) {
    const where: Prisma.TaskWhereInput = {
      organizationId, deletedAt: null,
      ...(filter.assigneeUserId ? { assigneeUserId: filter.assigneeUserId } : {}),
      ...(filter.status ? { status: filter.status } : {}),
    };
    return this.prisma.task.findMany({ where, orderBy: { dueAt: 'asc' }, take: 200 });
  }

  create(organizationId: string, dto: CreateTaskDto) {
    return this.prisma.task.create({
      data: {
        organizationId, title: dto.title, description: dto.description,
        assigneeUserId: dto.assigneeUserId, contactId: dto.contactId, dealId: dto.dealId,
        dueAt: dto.dueAt ? new Date(dto.dueAt) : null,
      },
    });
  }

  async complete(organizationId: string, id: string) {
    await this.prisma.task.updateMany({
      where: { id, organizationId },
      data: { status: 'DONE', completedAt: new Date() },
    });
    return { status: 'DONE' };
  }
}
