import { Type } from 'class-transformer';
import {
  IsArray, IsEnum, IsObject, IsOptional, IsString, ValidateNested,
} from 'class-validator';
import { FlowNodeType, FlowStatus } from '@prisma/client';

export class CreateFlowDto {
  @IsString() name!: string;
  @IsOptional() @IsString() description?: string;
  @IsObject() trigger!: Record<string, unknown>; // { type:'keyword', config:{ keywords:[], match:'contains' } }
}

export class UpdateFlowDto {
  @IsOptional() @IsString() name?: string;
  @IsOptional() @IsString() description?: string;
  @IsOptional() @IsObject() trigger?: Record<string, unknown>;
  @IsOptional() @IsEnum(FlowStatus) status?: FlowStatus;
}

class CanvasNode {
  @IsString() id!: string;
  @IsEnum(FlowNodeType) type!: FlowNodeType;
  @IsOptional() @IsString() label?: string;
  @IsObject() config!: Record<string, unknown>;
  @IsObject() position!: { x: number; y: number };
}
class CanvasConnection {
  @IsOptional() @IsString() id?: string;
  @IsString() sourceNodeId!: string;
  @IsString() targetNodeId!: string;
  @IsOptional() @IsObject() condition?: Record<string, unknown>;
}
export class SaveCanvasDto {
  @IsArray() @ValidateNested({ each: true }) @Type(() => CanvasNode) nodes!: CanvasNode[];
  @IsArray() @ValidateNested({ each: true }) @Type(() => CanvasConnection) connections!: CanvasConnection[];
}
