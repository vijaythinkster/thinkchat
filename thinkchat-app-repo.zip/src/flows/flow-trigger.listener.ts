import { Injectable, Logger } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { QUEUE } from 'src/whatsapp/queue/queue.constants';
import { FLOW_JOB, RunFlowJob } from './queue/flow-exec.processor';

interface MessageReceivedEvent {
  organizationId: string;
  conversationId: string;
  messageId: string;
}

/**
 * On each inbound message: first resume any flow run that's waiting on this
 * conversation for a reply; otherwise match published-flow keyword triggers and
 * start a new run. Resume wins so we don't start a second flow mid-conversation.
 */
@Injectable()
export class FlowTriggerListener {
  private readonly logger = new Logger(FlowTriggerListener.name);

  constructor(
    private readonly prisma: PrismaService,
    @InjectQueue(QUEUE.FLOW_EXEC) private readonly queue: Queue<RunFlowJob>,
  ) {}

  @OnEvent('whatsapp.message.received')
  async onInbound(evt: MessageReceivedEvent) {
    const { organizationId, conversationId, messageId } = evt;

    const message = await this.prisma.message.findFirst({
      where: { id: messageId, organizationId }, select: { body: true },
    });
    const text = (message?.body ?? '').trim();

    // 1) Resume a waiting run for this conversation.
    const waiting = await this.prisma.flowRun.findFirst({
      where: { organizationId, conversationId, status: 'WAITING', waitingFor: 'reply' },
      orderBy: { updatedAt: 'desc' },
    });
    if (waiting) {
      await this.queue.add(FLOW_JOB.RUN, { organizationId, flowRunId: waiting.id, reply: text });
      return;
    }

    // 2) Match keyword triggers on published flows.
    if (!text) return;
    const flows = await this.prisma.automationFlow.findMany({
      where: { organizationId, status: 'PUBLISHED', deletedAt: null },
      include: { nodes: { select: { id: true } } },
    });
    const lower = text.toLowerCase();

    for (const flow of flows) {
      const trigger = flow.trigger as any;
      if (trigger?.type !== 'keyword') continue;
      const keywords: string[] = (trigger.config?.keywords ?? []).map((k: string) => k.toLowerCase());
      const match = trigger.config?.match ?? 'contains';
      const hit = keywords.some((k) => (match === 'exact' ? lower === k : lower.includes(k)));
      if (!hit) continue;

      // Avoid duplicate concurrent runs of the same flow for this conversation.
      const active = await this.prisma.flowRun.count({
        where: { organizationId, flowId: flow.id, conversationId, status: { in: ['RUNNING', 'WAITING'] } },
      });
      if (active > 0) continue;

      const contact = await this.prisma.conversation.findFirst({
        where: { id: conversationId, organizationId }, select: { contactId: true },
      });
      if (!contact) continue;

      const run = await this.prisma.flowRun.create({
        data: {
          organizationId, flowId: flow.id, contactId: contact.contactId, conversationId,
          status: 'RUNNING', context: { __contactId: contact.contactId } as any,
        },
      });
      await this.queue.add(FLOW_JOB.RUN, { organizationId, flowRunId: run.id });
      this.logger.log(`Flow ${flow.id} triggered for conversation ${conversationId}`);
      break; // one flow per inbound
    }
  }
}
