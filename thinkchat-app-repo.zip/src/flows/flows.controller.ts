import { Body, Controller, Delete, Get, Param, Post, Put } from '@nestjs/common';
import { OrgId } from 'src/common/tenant/org-id.decorator';
import { RequirePermissions } from 'src/auth/decorators/permissions.decorator';
import { FlowsService } from './flows.service';
import { CreateFlowDto, SaveCanvasDto, UpdateFlowDto } from './dto/flow.dto';

@Controller('flows')
@RequirePermissions('flows.manage')
export class FlowsController {
  constructor(private readonly flows: FlowsService) {}

  @Get()
  list(@OrgId() orgId: string) { return this.flows.list(orgId); }

  @Post()
  create(@OrgId() orgId: string, @Body() dto: CreateFlowDto) { return this.flows.create(orgId, dto); }

  @Get(':id')
  get(@OrgId() orgId: string, @Param('id') id: string) { return this.flows.get(orgId, id); }

  @Put(':id')
  update(@OrgId() orgId: string, @Param('id') id: string, @Body() dto: UpdateFlowDto) {
    return this.flows.update(orgId, id, dto);
  }

  @Put(':id/canvas')
  saveCanvas(@OrgId() orgId: string, @Param('id') id: string, @Body() dto: SaveCanvasDto) {
    return this.flows.saveCanvas(orgId, id, dto);
  }

  @Post(':id/publish')
  publish(@OrgId() orgId: string, @Param('id') id: string) { return this.flows.publish(orgId, id); }

  @Post(':id/archive')
  archive(@OrgId() orgId: string, @Param('id') id: string) { return this.flows.archive(orgId, id); }
}
