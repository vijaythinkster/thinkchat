import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { QUEUE } from 'src/whatsapp/queue/queue.constants';
import { AIModule } from 'src/ai/ai.module';
import { FlowsService } from './flows.service';
import { FlowsController } from './flows.controller';
import { FlowExecProcessor } from './queue/flow-exec.processor';
import { FlowTriggerListener } from './flow-trigger.listener';

@Module({
  imports: [
    AIModule, // AI nodes reuse AIService
    BullModule.registerQueue({ name: QUEUE.FLOW_EXEC }, { name: QUEUE.MESSAGE_SEND }),
  ],
  controllers: [FlowsController],
  providers: [FlowsService, FlowExecProcessor, FlowTriggerListener],
  exports: [FlowsService],
})
export class FlowsModule {}
