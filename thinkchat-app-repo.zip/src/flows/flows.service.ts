import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { CreateFlowDto, SaveCanvasDto, UpdateFlowDto } from './dto/flow.dto';

@Injectable()
export class FlowsService {
  constructor(private readonly prisma: PrismaService) {}

  list(organizationId: string) {
    return this.prisma.automationFlow.findMany({
      where: { organizationId, deletedAt: null }, orderBy: { updatedAt: 'desc' },
    });
  }

  async get(organizationId: string, id: string) {
    const flow = await this.prisma.automationFlow.findFirst({
      where: { id, organizationId, deletedAt: null },
      include: { nodes: true, connections: true },
    });
    if (!flow) throw new NotFoundException('Flow not found');
    return flow;
  }

  create(organizationId: string, dto: CreateFlowDto) {
    return this.prisma.automationFlow.create({
      data: {
        organizationId, name: dto.name, description: dto.description,
        trigger: dto.trigger as any, status: 'DRAFT',
      },
    });
  }

  async update(organizationId: string, id: string, dto: UpdateFlowDto) {
    await this.get(organizationId, id);
    return this.prisma.automationFlow.update({
      where: { id },
      data: {
        name: dto.name, description: dto.description,
        ...(dto.trigger ? { trigger: dto.trigger as any } : {}),
        ...(dto.status ? { status: dto.status } : {}),
      },
    });
  }

  /** Replace the whole canvas atomically (client owns node ids for stability). */
  async saveCanvas(organizationId: string, id: string, dto: SaveCanvasDto) {
    await this.get(organizationId, id);
    await this.prisma.$transaction([
      this.prisma.flowConnection.deleteMany({ where: { flowId: id } }),
      this.prisma.flowNode.deleteMany({ where: { flowId: id } }),
      this.prisma.flowNode.createMany({
        data: dto.nodes.map((n) => ({
          id: n.id, flowId: id, type: n.type, label: n.label,
          config: n.config as any, position: n.position as any,
        })),
      }),
      this.prisma.flowConnection.createMany({
        data: dto.connections.map((c) => ({
          flowId: id, sourceNodeId: c.sourceNodeId, targetNodeId: c.targetNodeId,
          condition: (c.condition ?? null) as any,
        })),
      }),
      this.prisma.automationFlow.update({ where: { id }, data: { version: { increment: 1 } } }),
    ]);
    return this.get(organizationId, id);
  }

  async publish(organizationId: string, id: string) {
    const flow = await this.get(organizationId, id);
    if (flow.nodes.length === 0) throw new BadRequestException('Add at least one node before publishing');
    return this.prisma.automationFlow.update({ where: { id }, data: { status: 'PUBLISHED' } });
  }

  async archive(organizationId: string, id: string) {
    await this.get(organizationId, id);
    return this.prisma.automationFlow.update({ where: { id }, data: { status: 'ARCHIVED' } });
  }
}
