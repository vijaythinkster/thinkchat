import { Processor, WorkerHost, InjectQueue } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job, Queue } from 'bullmq';
import { Prisma } from '@prisma/client';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { JOB, QUEUE, SendMessageJob } from 'src/whatsapp/queue/queue.constants';
import { AIService } from 'src/ai/ai.service';

export const FLOW_JOB = { RUN: 'run-flow' } as const;
export interface RunFlowJob {
  organizationId: string;
  flowRunId: string;
  reply?: string; // the customer's answer when resuming a QUESTION node
}

type Node = { id: string; type: string; label: string | null; config: any; position: any };
type Conn = { sourceNodeId: string; targetNodeId: string; condition: any };

const MAX_STEPS = 50; // loop guard per invocation

/**
 * Flow execution engine. Walks nodes from the current position, executing each,
 * until it hits a QUESTION (waits for the next inbound reply), a DELAY (re-enqueues
 * itself later), a HUMAN_AGENT/end (completes), or the loop guard. State lives in
 * FlowRun so runs survive restarts and long waits. Runs outside request scope, so
 * all queries pass organizationId explicitly.
 */
@Processor(QUEUE.FLOW_EXEC, { concurrency: 6 })
export class FlowExecProcessor extends WorkerHost {
  private readonly logger = new Logger(FlowExecProcessor.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly ai: AIService,
    @InjectQueue(QUEUE.MESSAGE_SEND) private readonly sendQueue: Queue,
    @InjectQueue(QUEUE.FLOW_EXEC) private readonly flowQueue: Queue,
  ) {
    super();
  }

  async process(job: Job<RunFlowJob>): Promise<void> {
    if (job.name !== FLOW_JOB.RUN) return;
    const { organizationId, flowRunId, reply } = job.data;

    const run = await this.prisma.flowRun.findFirst({ where: { id: flowRunId, organizationId } });
    if (!run || run.status === 'COMPLETED' || run.status === 'FAILED') return;

    const flow = await this.prisma.automationFlow.findFirst({
      where: { id: run.flowId, organizationId },
      include: { nodes: true, connections: true },
    });
    if (!flow) return;

    const nodes = new Map<string, Node>(flow.nodes.map((n) => [n.id, n as Node]));
    const conns = flow.connections as Conn[];
    const context: Record<string, unknown> = (run.context as any) ?? {};

    const contact = await this.prisma.contact.findFirst({
      where: { id: run.contactId, organizationId }, select: { phone: true, name: true },
    });

    let currentId: string | null = run.currentNodeId ?? entryNode(flow.nodes as Node[], conns);

    // Resume a QUESTION: store the reply, then advance past the question node.
    if (run.status === 'WAITING' && run.waitingFor === 'reply' && reply != null && currentId) {
      const q = nodes.get(currentId);
      if (q) {
        const key = (q.config?.saveAs as string) || 'lastAnswer';
        context[key] = reply;
        currentId = pickNext(q, undefined, conns);
      }
    }

    let steps = 0;
    try {
      while (currentId && steps++ < MAX_STEPS) {
        const node = nodes.get(currentId);
        if (!node) break;

        // DELAY: schedule resume and stop this invocation.
        if (node.type === 'DELAY') {
          const ms = delayMs(node.config);
          const next = pickNext(node, undefined, conns);
          await this.prisma.flowRun.update({
            where: { id: run.id },
            data: { status: 'WAITING', currentNodeId: next, waitingFor: null, resumeAt: new Date(Date.now() + ms), context: context as any },
          });
          await this.flowQueue.add(FLOW_JOB.RUN, { organizationId, flowRunId: run.id } as RunFlowJob,
            { delay: ms, removeOnComplete: 100 });
          return;
        }

        // QUESTION: send prompt, then wait for the next inbound message.
        if (node.type === 'QUESTION') {
          await this.send(organizationId, run.conversationId, contact?.phone, interpolate(String(node.config?.text ?? ''), context, contact));
          await this.prisma.flowRun.update({
            where: { id: run.id },
            data: { status: 'WAITING', currentNodeId: node.id, waitingFor: 'reply', context: context as any },
          });
          return;
        }

        const branch = await this.execute(organizationId, node, context, contact, run.conversationId);
        if (branch === '__STOP__') {
          await this.complete(run.id, context);
          return;
        }
        currentId = pickNext(node, branch, conns);
      }
      await this.complete(run.id, context);
    } catch (err) {
      this.logger.error(`Flow run ${run.id} failed at ${currentId}: ${(err as Error).message}`);
      await this.prisma.flowRun.update({ where: { id: run.id }, data: { status: 'FAILED', context: context as any } });
    }
  }

  /** Execute a non-pausing node. Returns a branch label, or '__STOP__' to end. */
  private async execute(
    orgId: string, node: Node, context: Record<string, unknown>,
    contact: { phone: string; name: string | null } | null, conversationId: string | null,
  ): Promise<string | undefined> {
    switch (node.type) {
      case 'MESSAGE':
        await this.send(orgId, conversationId, contact?.phone, interpolate(String(node.config?.text ?? ''), context, contact));
        return undefined;

      case 'CONDITION': {
        const left = String(context[String(node.config?.variable ?? '')] ?? '').toLowerCase();
        const right = String(node.config?.value ?? '').toLowerCase();
        const op = String(node.config?.op ?? 'equals');
        const result = op === 'contains' ? left.includes(right) : left === right;
        return result ? 'true' : 'false';
      }

      case 'AI': {
        const assistantId = String(node.config?.assistantId ?? '');
        const prompt = interpolate(String(node.config?.prompt ?? '{{lastAnswer}}'), context, contact);
        if (assistantId) {
          const { reply } = await this.ai.reply(orgId, assistantId, prompt);
          context.aiReply = reply;
          await this.send(orgId, conversationId, contact?.phone, reply);
        }
        return undefined;
      }

      case 'API_CALL': {
        const url = String(node.config?.url ?? '');
        if (url) {
          const res = await fetch(url, {
            method: String(node.config?.method ?? 'GET'),
            headers: (node.config?.headers as Record<string, string>) ?? {},
            body: node.config?.body ? JSON.stringify(node.config.body) : undefined,
          });
          context[String(node.config?.saveAs ?? 'apiResult')] = await res.json().catch(() => null);
        }
        return undefined;
      }

      case 'TAG': {
        const labelId = String(node.config?.labelId ?? '');
        if (labelId && context.__contactId) {
          await this.prisma.contactLabel.upsert({
            where: { contactId_labelId: { contactId: String(context.__contactId), labelId } },
            create: { contactId: String(context.__contactId), labelId }, update: {},
          });
        }
        return undefined;
      }

      case 'CRM_UPDATE': {
        const set = (node.config?.set as Record<string, unknown>) ?? {};
        if (context.__contactId && Object.keys(set).length) {
          const c = await this.prisma.contact.findFirst({ where: { id: String(context.__contactId), organizationId: orgId }, select: { attributes: true } });
          await this.prisma.contact.update({
            where: { id: String(context.__contactId) },
            data: { attributes: ({ ...((c?.attributes as object) ?? {}), ...set }) as Prisma.InputJsonValue },
          });
        }
        return undefined;
      }

      case 'HUMAN_AGENT': {
        if (conversationId) {
          await this.prisma.conversation.updateMany({
            where: { id: conversationId, organizationId: orgId },
            data: {
              assignedAgentId: (node.config?.agentId as string) ?? undefined,
              assignedTeamId: (node.config?.teamId as string) ?? undefined,
              status: 'OPEN',
            },
          });
        }
        return '__STOP__'; // handed to a human; flow ends
      }

      default:
        return undefined;
    }
  }

  private async send(orgId: string, conversationId: string | null, to: string | undefined, body: string) {
    if (!conversationId || !to || !body) return;
    const conv = await this.prisma.conversation.findFirst({
      where: { id: conversationId, organizationId: orgId }, select: { whatsAppNumberId: true },
    });
    if (!conv) return;
    const graph = { messaging_product: 'whatsapp', to, type: 'text', text: { body } };
    const message = await this.prisma.message.create({
      data: {
        organizationId: orgId, conversationId, whatsAppNumberId: conv.whatsAppNumberId,
        direction: 'OUTBOUND', type: 'TEXT', status: 'QUEUED', body, payload: { graph } as any,
      },
    });
    await this.sendQueue.add(JOB.SEND_MESSAGE, { organizationId: orgId, messageId: message.id } as SendMessageJob,
      { attempts: 5, backoff: { type: 'exponential', delay: 4000 }, removeOnComplete: 1000 });
  }

  private async complete(runId: string, context: Record<string, unknown>) {
    await this.prisma.flowRun.update({
      where: { id: runId },
      data: { status: 'COMPLETED', currentNodeId: null, completedAt: new Date(), context: context as any },
    });
  }
}

function entryNode(nodes: Node[], conns: Conn[]): string | null {
  const targets = new Set(conns.map((c) => c.targetNodeId));
  return (nodes.find((n) => !targets.has(n.id)) ?? nodes[0])?.id ?? null;
}
function pickNext(node: Node, branch: string | undefined, conns: Conn[]): string | null {
  const outgoing = conns.filter((c) => c.sourceNodeId === node.id);
  if (branch) {
    const match = outgoing.find((c) => (c.condition as any)?.branch === branch);
    if (match) return match.targetNodeId;
  }
  return outgoing[0]?.targetNodeId ?? null;
}
function delayMs(config: any): number {
  const n = Number(config?.value ?? 1);
  const unit = String(config?.unit ?? 'minutes');
  const mult = unit === 'seconds' ? 1000 : unit === 'hours' ? 3_600_000 : unit === 'days' ? 86_400_000 : 60_000;
  return Math.max(1000, n * mult);
}
function interpolate(tpl: string, context: Record<string, unknown>, contact: { name: string | null } | null): string {
  return tpl
    .replace(/\{\{\s*name\s*\}\}/gi, contact?.name ?? 'there')
    .replace(/\{\{\s*(\w+)\s*\}\}/g, (_, k) => String(context[k] ?? ''));
}
