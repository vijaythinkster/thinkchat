import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { OrgId } from 'src/common/tenant/org-id.decorator';
import { ConversationsService } from './conversations.service';
import { MessagesService } from 'src/whatsapp/messages/messages.service';
import { SendMessageDto } from 'src/whatsapp/dto/send-message.dto';
import { AddNoteDto, AssignDto, ListConversationsDto, ResolveDto } from './dto/inbox.dto';

/**
 * REST surface the inbox frontend reads from. Sending reuses the Phase 4
 * MessagesService (enqueue + worker), so the controller stays thin.
 * userId/agentId come from the auth context (decorators elided for brevity).
 */
@Controller('conversations')
export class ConversationsController {
  constructor(
    private readonly conversations: ConversationsService,
    private readonly messages: MessagesService,
  ) {}

  @Get()
  list(@OrgId() orgId: string, @Query() q: ListConversationsDto) {
    return this.conversations.list(orgId, q);
  }

  @Get(':id/messages')
  thread(@OrgId() orgId: string, @Param('id') id: string) {
    return this.conversations.thread(orgId, id);
  }

  @Post(':id/messages')
  send(@OrgId() orgId: string, @Param('id') id: string, @Body() dto: SendMessageDto) {
    return this.messages.send(orgId, { ...dto, conversationId: id });
  }

  @Post(':id/assign')
  assign(@OrgId() orgId: string, @Param('id') id: string, @Body() dto: AssignDto) {
    return this.conversations.assign(orgId, id, dto);
  }

  @Post(':id/resolve')
  resolve(@OrgId() orgId: string, @Param('id') id: string, @Body() dto: ResolveDto) {
    return this.conversations.resolve(orgId, id, dto.status);
  }

  @Post(':id/notes')
  addNote(@OrgId() orgId: string, @Param('id') id: string, @Body() dto: AddNoteDto) {
    // authorUserId resolved from request user; passed through here.
    return this.conversations.addNote(orgId, id, (dto as any).authorUserId ?? '', dto);
  }
}
