import { Injectable, NotFoundException } from '@nestjs/common';
import { ConversationStatus } from '@prisma/client';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { AddNoteDto, AssignDto, ListConversationsDto } from './dto/inbox.dto';

@Injectable()
export class ConversationsService {
  constructor(private readonly prisma: PrismaService) {}

  /** Paginated conversation list for the left pane, newest activity first. */
  async list(organizationId: string, q: ListConversationsDto, currentAgentId?: string) {
    const limit = q.limit ?? 25;
    const assignedAgentId = q.assigneeId === 'me' ? currentAgentId : q.assigneeId;

    const rows = await this.prisma.conversation.findMany({
      where: {
        organizationId,
        deletedAt: null,
        ...(q.status ? { status: q.status } : {}),
        ...(assignedAgentId ? { assignedAgentId } : {}),
      },
      include: {
        contact: { select: { id: true, name: true, phone: true } },
        assignedAgent: { include: { user: { select: { firstName: true, lastName: true } } } },
        messages: { orderBy: { createdAt: 'desc' }, take: 1 },
        conversationLabels: { include: { label: true } },
      },
      orderBy: { lastMessageAt: 'desc' },
      take: limit + 1,
      ...(q.cursor ? { cursor: { id: q.cursor }, skip: 1 } : {}),
    });

    const hasMore = rows.length > limit;
    const items = hasMore ? rows.slice(0, limit) : rows;
    return { items, nextCursor: hasMore ? items[items.length - 1].id : null };
  }

  /** Full thread for the center pane; opening a conversation clears its unread count. */
  async thread(organizationId: string, conversationId: string) {
    const conversation = await this.prisma.conversation.findFirst({
      where: { id: conversationId, organizationId, deletedAt: null },
      include: {
        contact: true,
        assignedAgent: { include: { user: true } },
        conversationLabels: { include: { label: true } },
      },
    });
    if (!conversation) throw new NotFoundException('Conversation not found');

    const [messages] = await Promise.all([
      this.prisma.message.findMany({
        where: { conversationId, organizationId },
        orderBy: { createdAt: 'asc' },
        take: 100,
      }),
      this.prisma.conversation.update({
        where: { id: conversationId },
        data: { unreadCount: 0 },
      }),
    ]);

    return { conversation, messages };
  }

  assign(organizationId: string, conversationId: string, dto: AssignDto) {
    return this.update(organizationId, conversationId, {
      assignedAgentId: dto.agentId ?? null,
      assignedTeamId: dto.teamId ?? null,
    });
  }

  resolve(organizationId: string, conversationId: string, status: ConversationStatus) {
    return this.update(organizationId, conversationId, { status });
  }

  async addNote(organizationId: string, conversationId: string, authorUserId: string, dto: AddNoteDto) {
    await this.ensure(organizationId, conversationId);
    return this.prisma.note.create({
      data: { organizationId, conversationId, authorUserId, body: dto.body },
    });
  }

  private async update(organizationId: string, conversationId: string, data: Record<string, unknown>) {
    await this.ensure(organizationId, conversationId);
    return this.prisma.conversation.update({ where: { id: conversationId }, data });
  }

  private async ensure(organizationId: string, conversationId: string) {
    const exists = await this.prisma.conversation.findFirst({
      where: { id: conversationId, organizationId, deletedAt: null },
      select: { id: true },
    });
    if (!exists) throw new NotFoundException('Conversation not found');
  }
}
