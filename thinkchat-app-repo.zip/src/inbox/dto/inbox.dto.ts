import { IsEnum, IsInt, IsOptional, IsString, Max, Min } from 'class-validator';
import { Type } from 'class-transformer';
import { ConversationStatus } from '@prisma/client';

export class ListConversationsDto {
  @IsOptional() @IsEnum(ConversationStatus) status?: ConversationStatus;
  @IsOptional() @IsString() assigneeId?: string; // agent id, or "me"
  @IsOptional() @IsString() cursor?: string;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(50) limit?: number;
}

export class AssignDto {
  @IsOptional() @IsString() agentId?: string;
  @IsOptional() @IsString() teamId?: string;
}

export class ResolveDto {
  @IsEnum(ConversationStatus) status!: ConversationStatus;
}

export class AddNoteDto {
  @IsString() body!: string;
}
