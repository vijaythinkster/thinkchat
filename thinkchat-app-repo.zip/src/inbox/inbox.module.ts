import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { WhatsAppModule } from 'src/whatsapp/whatsapp.module';
import { ConversationsController } from './conversations.controller';
import { ConversationsService } from './conversations.service';
import { InboxGateway } from 'src/realtime/inbox.gateway';

@Module({
  imports: [
    WhatsAppModule, // re-uses exported MessagesService for sending
    JwtModule.register({ secret: process.env.JWT_ACCESS_SECRET }),
  ],
  controllers: [ConversationsController],
  providers: [ConversationsService, InboxGateway],
  exports: [ConversationsService],
})
export class InboxModule {}
