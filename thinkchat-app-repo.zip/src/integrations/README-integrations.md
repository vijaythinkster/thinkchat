# Phase 10 — Integrations

Connects the platform to the ten providers in the `IntegrationProvider` schema enum.
No schema changes were needed.

## How it works
A provider-abstraction (mirrors the AI providers): one `IntegrationProviderImpl`
per provider, resolved by `IntegrationProviderFactory`. Two directions:

- **Inbound lead capture / bridges** → a webhook arrives at the public receiver →
  verified → deduped + stored as a `WebhookEvent` → fast `200` → enqueued to the
  `integration-sync` worker → parsed into a normalized lead → `Contact` upsert +
  `Lead` create → emits `integration.lead.received` (flows/campaigns can trigger on
  it later).
- **Outbound CRM** → a `push-contact` job ships a contact to HubSpot / Salesforce /
  Asana.

Same webhook discipline as WhatsApp: verify → dedupe → 200 → enqueue. Idempotent on
`(provider, externalId)` where `externalId = "<provider>:sha256(rawBody)"`.

## Providers
| Provider | Direction | Auth |
|---|---|---|
| Meta Lead Ads | inbound | `X-Hub-Signature-256` HMAC (appSecret) |
| Shopify | inbound | `X-Shopify-Hmac-Sha256` (base64 HMAC) |
| WooCommerce | inbound | `X-WC-Webhook-Signature` (base64 HMAC) |
| WordPress / Google Lead Forms / Zapier / n8n | inbound (generic) | shared token (`x-webhook-token`) |
| HubSpot / Salesforce / Asana | outbound | API token / OAuth |

## Files
- `providers/` — interface, field-map util, the provider impls, factory
- `integrations.service.ts` — connect/disconnect/list/test; encrypts credentials at rest
- `integrations.controller.ts` — authenticated management API (`integrations.manage`)
- `webhooks/integrations-webhook.controller.ts` — public receiver
- `queue/integration-sync.processor.ts` — the worker
- frontend: `web/src/features/integrations/integrations-grid.tsx`,
  `app/(dashboard)/integrations/page.tsx`, api client + types

## Webhook URL given to each source platform
`{API}/webhooks/integrations/{provider}/{organizationId}`

## Edited shared files (deltas)
- `src/whatsapp/queue/queue.constants.ts` — added `INTEGRATION_SYNC` queue + jobs
- `src/auth/rbac/permissions.ts` — added `integrations.manage`
- `src/app.module.ts` — registered `IntegrationsModule`

## Flagged / left for the developer
- **Meta Lead Ads field fetch**: Meta sends a `leadgen_id`; fetching the actual
  `field_data` from the Graph API (needs the page token) is a marked stub. Sandbox
  payloads that already include `field_data` are parsed directly.
- **Outbound pushes** (HubSpot/Salesforce/Asana): structure + auth checks are done;
  the actual HTTP calls are marked `TODO(dev)` stubs (each needs its own OAuth/token
  setup). They log and return ok so the pipeline runs end-to-end.
- **Auto-trigger**: `integration.lead.received` is emitted but not yet wired to start
  a flow/campaign — hook it in `flow-trigger.listener` if you want lead→automation.
- **Email-only leads**: contacts key on phone (org+phone unique). A lead with no
  phone is matched to an existing contact by email, else skipped (WhatsApp needs a
  number).

## Validation
All 21 new/edited files pass `ts.transpileModule` (syntax). Not yet type-checked
against generated Prisma types or compiled with the rest of the app — that happens at
first real build, same as every other subsystem.
