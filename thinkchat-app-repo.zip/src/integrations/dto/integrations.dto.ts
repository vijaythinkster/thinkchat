import { IsObject, IsOptional } from 'class-validator';

export class ConnectIntegrationDto {
  /** Provider-specific secrets (signing secrets, API tokens). Stored encrypted. */
  @IsOptional()
  @IsObject()
  credentials?: Record<string, string>;

  /** Non-secret settings: field maps, target ids, toggles. Stored as-is. */
  @IsOptional()
  @IsObject()
  config?: Record<string, unknown>;
}
