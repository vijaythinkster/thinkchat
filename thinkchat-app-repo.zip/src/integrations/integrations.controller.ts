import { Body, Controller, Delete, Get, Param, Post } from '@nestjs/common';
import { RequirePermissions } from 'src/auth/decorators/permissions.decorator';
import { CurrentUser, AuthUser } from 'src/auth/decorators/current-user.decorator';
import { IntegrationsService } from './integrations.service';
import { ConnectIntegrationDto } from './dto/integrations.dto';

@Controller('integrations')
@RequirePermissions('integrations.manage')
export class IntegrationsController {
  constructor(private readonly integrations: IntegrationsService) {}

  /** Catalog of all ten providers with this org's connection state. */
  @Get()
  list(@CurrentUser() user: AuthUser) {
    return this.integrations.list(user.organizationId);
  }

  @Post(':provider/connect')
  connect(
    @CurrentUser() user: AuthUser,
    @Param('provider') provider: string,
    @Body() dto: ConnectIntegrationDto,
  ) {
    return this.integrations.connect(user.organizationId, provider, dto);
  }

  @Post(':provider/test')
  test(@CurrentUser() user: AuthUser, @Param('provider') provider: string) {
    return this.integrations.test(user.organizationId, provider);
  }

  @Delete(':provider')
  disconnect(@CurrentUser() user: AuthUser, @Param('provider') provider: string) {
    return this.integrations.disconnect(user.organizationId, provider);
  }

  @Get(':provider/events')
  events(@CurrentUser() user: AuthUser, @Param('provider') provider: string) {
    return this.integrations.recentEvents(user.organizationId, provider);
  }
}
