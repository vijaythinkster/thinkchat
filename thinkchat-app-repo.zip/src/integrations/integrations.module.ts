import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { QUEUE } from 'src/whatsapp/queue/queue.constants';
import { IntegrationsService } from './integrations.service';
import { IntegrationsController } from './integrations.controller';
import { IntegrationsWebhookController } from './webhooks/integrations-webhook.controller';
import { IntegrationSyncProcessor } from './queue/integration-sync.processor';
import { IntegrationProviderFactory } from './providers/integration-provider.factory';
import { ShopifyProvider } from './providers/shopify.provider';
import { WooCommerceProvider } from './providers/woocommerce.provider';
import { MetaLeadAdsProvider } from './providers/meta-lead-ads.provider';
import {
  GoogleLeadFormsProvider,
  N8nProvider,
  WordPressProvider,
  ZapierProvider,
} from './providers/generic-webhook.provider';
import { AsanaProvider, HubSpotProvider, SalesforceProvider } from './providers/crm-sync.provider';

@Module({
  imports: [BullModule.registerQueue({ name: QUEUE.INTEGRATION_SYNC })],
  controllers: [IntegrationsController, IntegrationsWebhookController],
  providers: [
    IntegrationsService,
    IntegrationProviderFactory,
    IntegrationSyncProcessor,
    // provider implementations
    ShopifyProvider,
    WooCommerceProvider,
    MetaLeadAdsProvider,
    WordPressProvider,
    GoogleLeadFormsProvider,
    ZapierProvider,
    N8nProvider,
    HubSpotProvider,
    SalesforceProvider,
    AsanaProvider,
  ],
  exports: [IntegrationsService],
})
export class IntegrationsModule {}
