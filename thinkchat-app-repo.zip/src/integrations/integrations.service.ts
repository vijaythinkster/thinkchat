import { BadRequestException, Injectable, Logger } from '@nestjs/common';
import { IntegrationProvider as ProviderEnum, Prisma } from '@prisma/client';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { EncryptionService } from 'src/common/security/encryption.service';
import { IntegrationProviderFactory } from './providers/integration-provider.factory';
import { ProviderContext, TestResult } from './providers/integration-provider.interface';
import { ConnectIntegrationDto } from './dto/integrations.dto';

const ALL_PROVIDERS = Object.values(ProviderEnum);

/** Public, non-secret view of an integration for the management UI. */
export interface IntegrationView {
  provider: ProviderEnum;
  kind: string;
  status: string;
  connected: boolean;
  config: Record<string, unknown>;
  hasCredentials: boolean;
  lastSyncedAt: Date | null;
}

@Injectable()
export class IntegrationsService {
  private readonly logger = new Logger(IntegrationsService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly encryption: EncryptionService,
    private readonly factory: IntegrationProviderFactory,
  ) {}

  private parseProvider(raw: string): ProviderEnum {
    const p = raw.toUpperCase() as ProviderEnum;
    if (!ALL_PROVIDERS.includes(p)) throw new BadRequestException(`Unknown provider: ${raw}`);
    return p;
  }

  /** Catalog of all providers with this org's connection state merged in. */
  async list(organizationId: string): Promise<IntegrationView[]> {
    const rows = await this.prisma.integration.findMany({
      where: { organizationId, deletedAt: null },
    });
    const byProvider = new Map(rows.map((r) => [r.provider, r]));
    return this.factory.list().map((impl) => {
      const row = byProvider.get(impl.provider);
      return {
        provider: impl.provider,
        kind: impl.kind,
        status: row?.status ?? 'DISCONNECTED',
        connected: row?.status === 'CONNECTED',
        config: (row?.config as Record<string, unknown>) ?? {},
        hasCredentials: Boolean(row?.credentials),
        lastSyncedAt: row?.lastSyncedAt ?? null,
      };
    });
  }

  /** Decrypt stored credentials into a usable context (for controllers/workers). */
  async getContext(organizationId: string, provider: ProviderEnum): Promise<ProviderContext | null> {
    const row = await this.prisma.integration.findUnique({
      where: { organizationId_provider: { organizationId, provider } },
    });
    if (!row) return null;
    let credentials: Record<string, string> = {};
    if (row.credentials) {
      try {
        credentials = JSON.parse(this.encryption.decrypt(row.credentials as unknown as string));
      } catch {
        this.logger.error(`Failed to decrypt credentials for ${provider} / ${organizationId}`);
      }
    }
    return { provider, credentials, config: (row.config as Record<string, unknown>) ?? {} };
  }

  /**
   * Upsert an integration, encrypt credentials at rest, then run the provider's
   * own connection test and persist the resulting status.
   */
  async connect(
    organizationId: string,
    rawProvider: string,
    dto: ConnectIntegrationDto,
  ): Promise<{ view: IntegrationView; test: TestResult }> {
    const provider = this.parseProvider(rawProvider);
    const impl = this.factory.get(provider);
    const credentials = dto.credentials ?? {};
    const config = dto.config ?? {};

    const test = await impl.testConnection({ provider, credentials, config });
    const status = test.ok ? 'CONNECTED' : 'ERROR';
    const encrypted = Object.keys(credentials).length
      ? (this.encryption.encrypt(JSON.stringify(credentials)) as unknown as Prisma.InputJsonValue)
      : Prisma.JsonNull;

    await this.prisma.integration.upsert({
      where: { organizationId_provider: { organizationId, provider } },
      create: {
        organizationId,
        provider,
        status,
        credentials: encrypted,
        config: config as Prisma.InputJsonValue,
      },
      update: {
        status,
        credentials: encrypted,
        config: config as Prisma.InputJsonValue,
        deletedAt: null,
      },
    });

    const view = (await this.list(organizationId)).find((v) => v.provider === provider)!;
    return { view, test };
  }

  async test(organizationId: string, rawProvider: string): Promise<TestResult> {
    const provider = this.parseProvider(rawProvider);
    const ctx = await this.getContext(organizationId, provider);
    if (!ctx) return { ok: false, detail: 'Not connected' };
    const result = await this.factory.get(provider).testConnection(ctx);
    await this.prisma.integration.update({
      where: { organizationId_provider: { organizationId, provider } },
      data: { status: result.ok ? 'CONNECTED' : 'ERROR' },
    });
    return result;
  }

  async disconnect(organizationId: string, rawProvider: string): Promise<void> {
    const provider = this.parseProvider(rawProvider);
    await this.prisma.integration.updateMany({
      where: { organizationId, provider },
      data: { status: 'DISCONNECTED', credentials: Prisma.JsonNull, deletedAt: new Date() },
    });
  }

  /** Recent inbound webhook events for a provider, for the activity panel. */
  async recentEvents(organizationId: string, rawProvider: string, take = 20) {
    const provider = this.parseProvider(rawProvider);
    const impl = this.factory.get(provider);
    return this.prisma.webhookEvent.findMany({
      where: {
        organizationId,
        provider: impl.webhookProvider,
        ...(impl.webhookProvider === 'CUSTOM' ? { eventType: provider } : {}),
      },
      orderBy: { createdAt: 'desc' },
      take,
      select: { id: true, eventType: true, status: true, error: true, createdAt: true },
    });
  }
}
