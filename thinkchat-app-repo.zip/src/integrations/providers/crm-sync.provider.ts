import { Injectable, Logger } from '@nestjs/common';
import { IntegrationProvider as ProviderEnum, WebhookProvider } from '@prisma/client';
import {
  IntegrationProviderImpl,
  NormalizedLead,
  ProviderContext,
  PushResult,
  TestResult,
} from './integration-provider.interface';

/**
 * Outbound CRM connectors. These push a contact/lead OUT to an external CRM when
 * one is created in our platform (driven by the PUSH_CONTACT job). They do not
 * receive inbound webhooks, so the inbound interface methods are inert.
 *
 * The network calls are intentionally left as marked stubs: each CRM needs its own
 * OAuth/token setup and request shape, and credentials are per-tenant. The request
 * each would make is documented inline so a developer can finish it quickly.
 */
abstract class OutboundCrmProvider implements IntegrationProviderImpl {
  protected readonly logger = new Logger(this.constructor.name);
  abstract readonly provider: ProviderEnum;
  readonly kind = 'OUTBOUND_CRM' as const;
  readonly webhookProvider: WebhookProvider = 'CUSTOM';

  verifySignature(): boolean {
    return false; // outbound only — no inbound webhook surface
  }
  parseWebhook(): NormalizedLead[] {
    return [];
  }

  abstract testConnection(ctx: ProviderContext): Promise<TestResult>;
  abstract pushContact(lead: NormalizedLead, ctx: ProviderContext): Promise<PushResult>;
}

@Injectable()
export class HubSpotProvider extends OutboundCrmProvider {
  readonly provider: ProviderEnum = 'HUBSPOT';

  async testConnection(ctx: ProviderContext): Promise<TestResult> {
    if (!ctx.credentials.accessToken) return { ok: false, detail: 'Missing private app accessToken' };
    return { ok: true, detail: 'Token stored.' };
  }

  async pushContact(lead: NormalizedLead, ctx: ProviderContext): Promise<PushResult> {
    if (!ctx.credentials.accessToken) return { ok: false, detail: 'Not connected' };
    // TODO(dev): POST https://api.hubapi.com/crm/v3/objects/contacts
    //   Authorization: Bearer <accessToken>
    //   { properties: { firstname, phone, email } }
    this.logger.log(`(stub) would upsert HubSpot contact for ${lead.phone ?? lead.email}`);
    return { ok: true, detail: 'stub: HubSpot push not yet wired' };
  }
}

@Injectable()
export class SalesforceProvider extends OutboundCrmProvider {
  readonly provider: ProviderEnum = 'SALESFORCE';

  async testConnection(ctx: ProviderContext): Promise<TestResult> {
    if (!ctx.credentials.accessToken || !ctx.credentials.instanceUrl) {
      return { ok: false, detail: 'Missing OAuth accessToken / instanceUrl' };
    }
    return { ok: true, detail: 'Credentials stored.' };
  }

  async pushContact(lead: NormalizedLead, ctx: ProviderContext): Promise<PushResult> {
    if (!ctx.credentials.accessToken) return { ok: false, detail: 'Not connected' };
    // TODO(dev): POST <instanceUrl>/services/data/vXX.0/sobjects/Lead
    //   Authorization: Bearer <accessToken>
    //   { LastName, Phone, Email, Company, LeadSource }
    this.logger.log(`(stub) would create Salesforce lead for ${lead.phone ?? lead.email}`);
    return { ok: true, detail: 'stub: Salesforce push not yet wired' };
  }
}

@Injectable()
export class AsanaProvider extends OutboundCrmProvider {
  readonly provider: ProviderEnum = 'ASANA';

  async testConnection(ctx: ProviderContext): Promise<TestResult> {
    if (!ctx.credentials.accessToken) return { ok: false, detail: 'Missing personal access token' };
    if (!ctx.config.projectGid) return { ok: false, detail: 'Missing target projectGid in config' };
    return { ok: true, detail: 'Token + project stored.' };
  }

  async pushContact(lead: NormalizedLead, ctx: ProviderContext): Promise<PushResult> {
    if (!ctx.credentials.accessToken) return { ok: false, detail: 'Not connected' };
    // TODO(dev): POST https://app.asana.com/api/1.0/tasks
    //   Authorization: Bearer <accessToken>
    //   { data: { projects: [projectGid], name: "Lead: <name/phone>", notes: <attributes> } }
    this.logger.log(`(stub) would create Asana task for lead ${lead.phone ?? lead.email}`);
    return { ok: true, detail: 'stub: Asana task creation not yet wired' };
  }
}
