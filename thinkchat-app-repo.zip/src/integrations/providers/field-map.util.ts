import { createHmac, timingSafeEqual } from 'crypto';

/** Safe constant-time string compare (avoids timing leaks on token checks). */
export function safeEqual(a: string, b: string): boolean {
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  if (ab.length !== bb.length) return false;
  return timingSafeEqual(ab, bb);
}

/** HMAC of `raw` with `secret`, returned in the given encoding. */
export function hmac(raw: Buffer, secret: string, encoding: 'hex' | 'base64'): string {
  return createHmac('sha256', secret).update(raw).digest(encoding);
}

/** Read a possibly dotted path ("customer.email") out of a nested object. */
export function getPath(obj: unknown, path: string): unknown {
  return path.split('.').reduce<unknown>((acc, key) => {
    if (acc && typeof acc === 'object' && key in (acc as Record<string, unknown>)) {
      return (acc as Record<string, unknown>)[key];
    }
    return undefined;
  }, obj);
}

const asString = (v: unknown): string | undefined =>
  v === undefined || v === null ? undefined : String(v);

/**
 * Apply a per-integration field map to a record. config.fieldMap lets an org point
 * our canonical fields at wherever the provider puts them, e.g.
 *   { "name": "full_name", "phone": "phone_number", "email": "contact.email" }
 * Falls back to common defaults when no map is provided.
 */
export function mapLead(
  record: Record<string, unknown>,
  config: Record<string, unknown>,
): { name?: string; phone?: string; email?: string } {
  const fieldMap = (config.fieldMap as Record<string, string> | undefined) ?? {};
  const pick = (canonical: string, defaults: string[]): string | undefined => {
    const mapped = fieldMap[canonical];
    if (mapped) return asString(getPath(record, mapped));
    for (const d of defaults) {
      const v = getPath(record, d);
      if (v !== undefined && v !== null && v !== '') return asString(v);
    }
    return undefined;
  };
  return {
    name: pick('name', ['name', 'full_name', 'fullName', 'first_name']),
    phone: pick('phone', ['phone', 'phone_number', 'phoneNumber', 'mobile', 'whatsapp']),
    email: pick('email', ['email', 'email_address', 'contact_email']),
  };
}
