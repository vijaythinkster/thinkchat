import { Injectable } from '@nestjs/common';
import { IntegrationProvider as ProviderEnum, WebhookProvider } from '@prisma/client';
import {
  IntegrationProviderImpl,
  NormalizedLead,
  ProviderContext,
  TestResult,
} from './integration-provider.interface';
import { mapLead, safeEqual } from './field-map.util';

/**
 * Base for providers that deliver a simple JSON form/record and are authenticated
 * by a shared token (no HMAC): WordPress (CF7/WPForms webhooks), Google Lead Forms
 * (via Apps Script / Zapier relay), Zapier, and n8n. The token is sent in the
 * `x-webhook-token` header and compared in constant time against the stored secret.
 *
 * Field mapping is driven entirely by config.fieldMap so an org can wire arbitrary
 * form fields to name/phone/email without code changes.
 */
abstract class GenericWebhookProvider implements IntegrationProviderImpl {
  abstract readonly provider: ProviderEnum;
  abstract readonly source: string;
  readonly kind = 'BRIDGE' as const;
  readonly webhookProvider: WebhookProvider = 'CUSTOM';

  verifySignature(_raw: Buffer, headers: Record<string, string | undefined>, secret: string): boolean {
    // No secret set => open endpoint (allowed for trusted internal bridges, but a
    // token is strongly recommended and surfaced in the UI).
    if (!secret) return true;
    const token = headers['x-webhook-token'] ?? '';
    return safeEqual(token, secret);
  }

  parseWebhook(body: unknown, config: Record<string, unknown>): NormalizedLead[] {
    // Accept either a single record or an array (n8n/Zapier batch).
    const records = Array.isArray(body) ? body : [body];
    const leads: NormalizedLead[] = [];
    for (const r of records) {
      const rec = (r ?? {}) as Record<string, unknown>;
      const mapped = mapLead(rec, config);
      if (!mapped.phone && !mapped.email) continue;
      leads.push({
        externalId: rec.id !== undefined ? String(rec.id) : undefined,
        name: mapped.name,
        phone: mapped.phone,
        email: mapped.email,
        source: this.source,
        attributes: rec,
        raw: r,
      });
    }
    return leads;
  }

  async testConnection(ctx: ProviderContext): Promise<TestResult> {
    if (!ctx.credentials.token) {
      return { ok: true, detail: 'No token set — endpoint is open. Set a token to secure it.' };
    }
    return { ok: true, detail: 'Token stored. POST a sample record to the webhook URL to confirm mapping.' };
  }
}

@Injectable()
export class WordPressProvider extends GenericWebhookProvider {
  readonly provider: ProviderEnum = 'WORDPRESS';
  readonly source = 'wordpress';
}

@Injectable()
export class GoogleLeadFormsProvider extends GenericWebhookProvider {
  readonly provider: ProviderEnum = 'GOOGLE_LEAD_FORMS';
  readonly source = 'google_lead_forms';
}

@Injectable()
export class ZapierProvider extends GenericWebhookProvider {
  readonly provider: ProviderEnum = 'ZAPIER';
  readonly source = 'zapier';
}

@Injectable()
export class N8nProvider extends GenericWebhookProvider {
  readonly provider: ProviderEnum = 'N8N';
  readonly source = 'n8n';
}
