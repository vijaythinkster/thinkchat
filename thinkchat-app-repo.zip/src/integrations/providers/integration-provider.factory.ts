import { Injectable, NotFoundException } from '@nestjs/common';
import { IntegrationProvider as ProviderEnum } from '@prisma/client';
import { IntegrationProviderImpl } from './integration-provider.interface';
import { ShopifyProvider } from './shopify.provider';
import { WooCommerceProvider } from './woocommerce.provider';
import { MetaLeadAdsProvider } from './meta-lead-ads.provider';
import {
  GoogleLeadFormsProvider,
  N8nProvider,
  WordPressProvider,
  ZapierProvider,
} from './generic-webhook.provider';
import { AsanaProvider, HubSpotProvider, SalesforceProvider } from './crm-sync.provider';

@Injectable()
export class IntegrationProviderFactory {
  private readonly registry: Map<ProviderEnum, IntegrationProviderImpl>;

  constructor(
    shopify: ShopifyProvider,
    woo: WooCommerceProvider,
    metaLeadAds: MetaLeadAdsProvider,
    wordpress: WordPressProvider,
    googleLeadForms: GoogleLeadFormsProvider,
    zapier: ZapierProvider,
    n8n: N8nProvider,
    hubspot: HubSpotProvider,
    salesforce: SalesforceProvider,
    asana: AsanaProvider,
  ) {
    const all = [
      shopify,
      woo,
      metaLeadAds,
      wordpress,
      googleLeadForms,
      zapier,
      n8n,
      hubspot,
      salesforce,
      asana,
    ];
    this.registry = new Map(all.map((p) => [p.provider, p]));
  }

  get(provider: ProviderEnum): IntegrationProviderImpl {
    const impl = this.registry.get(provider);
    if (!impl) throw new NotFoundException(`Unsupported integration provider: ${provider}`);
    return impl;
  }

  list(): IntegrationProviderImpl[] {
    return [...this.registry.values()];
  }
}
