import { IntegrationProvider as ProviderEnum, WebhookProvider } from '@prisma/client';

/**
 * Provider abstraction for Phase 10 integrations. Each of the ten providers in
 * the IntegrationProvider enum is fronted by one implementation of this
 * interface, resolved through IntegrationProviderFactory. Implementations are
 * stateless: everything they need (decrypted credentials, per-org config) is
 * passed in, so a single instance serves all tenants.
 *
 * Two directions are modelled:
 *   - INBOUND_LEAD / BRIDGE: a webhook arrives -> parseWebhook() -> NormalizedLead[]
 *     -> the sync worker upserts Contact + Lead.
 *   - OUTBOUND_CRM: pushContact() ships a contact/lead out to a CRM.
 */
export type IntegrationKind = 'INBOUND_LEAD' | 'OUTBOUND_CRM' | 'BRIDGE';

/** A lead/contact normalized from any provider's payload into our shape. */
export interface NormalizedLead {
  externalId?: string; // provider-side id, for traceability/dedupe
  name?: string;
  phone?: string; // E.164 where possible
  email?: string;
  countryCode?: string;
  source: string; // e.g. "shopify", "meta_lead_ads"
  attributes?: Record<string, unknown>;
  raw?: unknown; // original record, for debugging
}

export interface TestResult {
  ok: boolean;
  detail?: string;
}

export interface PushResult {
  ok: boolean;
  externalId?: string;
  detail?: string;
}

export interface ProviderContext {
  provider: ProviderEnum;
  credentials: Record<string, string>;
  config: Record<string, unknown>;
}

export interface IntegrationProviderImpl {
  readonly provider: ProviderEnum;
  readonly kind: IntegrationKind;
  /** Which WebhookEvent.provider enum value inbound events are stored under. */
  readonly webhookProvider: WebhookProvider;

  /**
   * Verify an inbound webhook's authenticity. `secret` is the provider's signing
   * secret / shared token pulled from the integration credentials. Providers that
   * don't sign (verified by URL token instead) return the token comparison here.
   */
  verifySignature(raw: Buffer, headers: Record<string, string | undefined>, secret: string): boolean;

  /** Turn a verified webhook body into zero or more normalized leads. */
  parseWebhook(body: unknown, config: Record<string, unknown>): NormalizedLead[];

  /** Check that stored credentials actually work. */
  testConnection(ctx: ProviderContext): Promise<TestResult>;

  /** Outbound providers only: push a contact out. INBOUND providers omit this. */
  pushContact?(lead: NormalizedLead, ctx: ProviderContext): Promise<PushResult>;
}

/** Maps an IntegrationProvider to the (narrower) WebhookProvider enum used for storage. */
export function toWebhookProvider(p: ProviderEnum): WebhookProvider {
  switch (p) {
    case 'META_LEAD_ADS':
      return 'META_LEAD_ADS';
    case 'SHOPIFY':
      return 'SHOPIFY';
    default:
      // WordPress, WooCommerce, Google Lead Forms, Zapier, n8n, HubSpot, Salesforce, Asana
      // share the CUSTOM bucket; the real provider is kept in WebhookEvent.eventType.
      return 'CUSTOM';
  }
}
