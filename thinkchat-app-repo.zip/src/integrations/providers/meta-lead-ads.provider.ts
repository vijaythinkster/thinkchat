import { Injectable } from '@nestjs/common';
import { IntegrationProvider as ProviderEnum, WebhookProvider } from '@prisma/client';
import {
  IntegrationProviderImpl,
  NormalizedLead,
  ProviderContext,
  TestResult,
} from './integration-provider.interface';
import { hmac, safeEqual } from './field-map.util';

/**
 * Meta Lead Ads. Meta posts a `leadgen` change containing a leadgen_id; the actual
 * field_data must then be fetched from the Graph API with a page access token. That
 * fetch is left as a clearly-marked stub (needs the org's page token + a Graph call);
 * if a test/sandbox payload already includes field_data, we parse it directly.
 *
 * Signature: X-Hub-Signature-256 = "sha256=" + HMAC-SHA256(rawBody, appSecret),
 * identical to the WhatsApp webhook scheme.
 */
@Injectable()
export class MetaLeadAdsProvider implements IntegrationProviderImpl {
  readonly provider: ProviderEnum = 'META_LEAD_ADS';
  readonly kind = 'INBOUND_LEAD' as const;
  readonly webhookProvider: WebhookProvider = 'META_LEAD_ADS';

  verifySignature(raw: Buffer, headers: Record<string, string | undefined>, secret: string): boolean {
    const sig = headers['x-hub-signature-256'];
    if (!sig || !secret) return false;
    const expected = `sha256=${hmac(raw, secret, 'hex')}`;
    return safeEqual(sig, expected);
  }

  parseWebhook(body: unknown, _config: Record<string, unknown>): NormalizedLead[] {
    const root = (body ?? {}) as Record<string, unknown>;
    const entries = (root.entry as Array<Record<string, unknown>>) ?? [];
    const leads: NormalizedLead[] = [];
    for (const entry of entries) {
      const changes = (entry.changes as Array<Record<string, unknown>>) ?? [];
      for (const change of changes) {
        const value = (change.value as Record<string, unknown>) ?? {};
        const leadgenId = value.leadgen_id ?? value.leadgenId;
        const fieldData = value.field_data as Array<{ name: string; values: string[] }> | undefined;
        if (fieldData) {
          const flat: Record<string, string> = {};
          for (const f of fieldData) flat[f.name] = f.values?.[0] ?? '';
          leads.push({
            externalId: leadgenId ? String(leadgenId) : undefined,
            name: flat.full_name ?? flat.name,
            phone: flat.phone_number ?? flat.phone,
            email: flat.email,
            source: 'meta_lead_ads',
            attributes: flat,
            raw: change,
          });
        } else if (leadgenId) {
          // STUB: enqueue a Graph API fetch of field_data using the page token.
          // Recorded with the id so a follow-up fetch can complete it.
          leads.push({
            externalId: String(leadgenId),
            source: 'meta_lead_ads',
            attributes: { pendingGraphFetch: true, leadgenId },
            raw: change,
          });
        }
      }
    }
    return leads;
  }

  async testConnection(ctx: ProviderContext): Promise<TestResult> {
    if (!ctx.credentials.appSecret) return { ok: false, detail: 'Missing appSecret' };
    if (!ctx.credentials.pageAccessToken) {
      return { ok: false, detail: 'Missing pageAccessToken (needed to fetch lead field data)' };
    }
    return { ok: true, detail: 'Credentials stored. Subscribe the page to the leadgen webhook field.' };
  }
}
