import { Injectable } from '@nestjs/common';
import { IntegrationProvider as ProviderEnum, WebhookProvider } from '@prisma/client';
import {
  IntegrationProviderImpl,
  NormalizedLead,
  ProviderContext,
  TestResult,
} from './integration-provider.interface';
import { hmac, mapLead, safeEqual } from './field-map.util';

/**
 * Shopify webhooks (customers/create, orders/create). Authenticity is verified
 * with the X-Shopify-Hmac-Sha256 header: base64 HMAC-SHA256 of the raw body using
 * the app's webhook signing secret.
 */
@Injectable()
export class ShopifyProvider implements IntegrationProviderImpl {
  readonly provider: ProviderEnum = 'SHOPIFY';
  readonly kind = 'INBOUND_LEAD' as const;
  readonly webhookProvider: WebhookProvider = 'SHOPIFY';

  verifySignature(raw: Buffer, headers: Record<string, string | undefined>, secret: string): boolean {
    const sig = headers['x-shopify-hmac-sha256'];
    if (!sig || !secret) return false;
    return safeEqual(sig, hmac(raw, secret, 'base64'));
  }

  parseWebhook(body: unknown, config: Record<string, unknown>): NormalizedLead[] {
    const rec = (body ?? {}) as Record<string, unknown>;
    // orders/create nests the buyer under `customer`; customers/create is flat.
    const customer = (rec.customer as Record<string, unknown>) ?? rec;
    const mapped = mapLead(customer, config);
    const id = customer.id ?? rec.id;
    if (!mapped.phone && !mapped.email) return [];
    return [
      {
        externalId: id !== undefined ? String(id) : undefined,
        name: mapped.name,
        phone: mapped.phone,
        email: mapped.email,
        source: 'shopify',
        attributes: { ordersCount: customer.orders_count, totalSpent: customer.total_spent },
        raw: body,
      },
    ];
  }

  async testConnection(ctx: ProviderContext): Promise<TestResult> {
    // A real check would GET /admin/api/<v>/shop.json with the Admin API token.
    if (!ctx.credentials.webhookSecret) {
      return { ok: false, detail: 'Missing webhookSecret' };
    }
    return { ok: true, detail: 'Webhook secret stored; verify by sending a test webhook from Shopify.' };
  }
}
