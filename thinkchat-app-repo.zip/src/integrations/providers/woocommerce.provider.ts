import { Injectable } from '@nestjs/common';
import { IntegrationProvider as ProviderEnum, WebhookProvider } from '@prisma/client';
import {
  IntegrationProviderImpl,
  NormalizedLead,
  ProviderContext,
  TestResult,
} from './integration-provider.interface';
import { hmac, mapLead, safeEqual } from './field-map.util';

/**
 * WooCommerce webhooks. Authenticity: X-WC-Webhook-Signature is the base64
 * HMAC-SHA256 of the raw body using the secret configured on the webhook.
 */
@Injectable()
export class WooCommerceProvider implements IntegrationProviderImpl {
  readonly provider: ProviderEnum = 'WOOCOMMERCE';
  readonly kind = 'INBOUND_LEAD' as const;
  readonly webhookProvider: WebhookProvider = 'CUSTOM';

  verifySignature(raw: Buffer, headers: Record<string, string | undefined>, secret: string): boolean {
    const sig = headers['x-wc-webhook-signature'];
    if (!sig || !secret) return false;
    return safeEqual(sig, hmac(raw, secret, 'base64'));
  }

  parseWebhook(body: unknown, config: Record<string, unknown>): NormalizedLead[] {
    const rec = (body ?? {}) as Record<string, unknown>;
    const billing = (rec.billing as Record<string, unknown>) ?? {};
    // Merge billing (orders) with top-level (customers) so the field map can reach either.
    const merged: Record<string, unknown> = {
      ...rec,
      ...billing,
      name:
        billing.first_name || billing.last_name
          ? `${billing.first_name ?? ''} ${billing.last_name ?? ''}`.trim()
          : rec.first_name || rec.last_name
            ? `${rec.first_name ?? ''} ${rec.last_name ?? ''}`.trim()
            : undefined,
    };
    const mapped = mapLead(merged, config);
    if (!mapped.phone && !mapped.email) return [];
    const id = rec.customer_id ?? rec.id;
    return [
      {
        externalId: id !== undefined ? String(id) : undefined,
        name: mapped.name,
        phone: mapped.phone,
        email: mapped.email,
        source: 'woocommerce',
        raw: body,
      },
    ];
  }

  async testConnection(ctx: ProviderContext): Promise<TestResult> {
    if (!ctx.credentials.webhookSecret) return { ok: false, detail: 'Missing webhookSecret' };
    return { ok: true, detail: 'Webhook secret stored; send a test delivery from WooCommerce to confirm.' };
  }
}
