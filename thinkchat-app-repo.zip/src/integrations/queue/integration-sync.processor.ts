import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Job } from 'bullmq';
import { IntegrationProvider as ProviderEnum, Prisma } from '@prisma/client';
import { PrismaService } from 'src/common/prisma/prisma.service';
import {
  JOB,
  PushContactJob,
  QUEUE,
  SyncIntegrationJob,
} from 'src/whatsapp/queue/queue.constants';
import { IntegrationProviderFactory } from '../providers/integration-provider.factory';
import { NormalizedLead } from '../providers/integration-provider.interface';
import { IntegrationsService } from '../integrations.service';

/**
 * Processes integration jobs off the queue:
 *   - SYNC_INTEGRATION: an inbound webhook -> parse -> upsert Contact + create Lead
 *     -> emit 'integration.lead.received' (which flows/campaigns can later trigger on).
 *   - PUSH_CONTACT: ship a contact out to an outbound CRM provider.
 *
 * Runs outside request context, so it passes organizationId explicitly on every
 * write (the tenant middleware is a no-op here).
 */
@Processor(QUEUE.INTEGRATION_SYNC, { concurrency: 5 })
export class IntegrationSyncProcessor extends WorkerHost {
  private readonly logger = new Logger(IntegrationSyncProcessor.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly factory: IntegrationProviderFactory,
    private readonly integrations: IntegrationsService,
    private readonly events: EventEmitter2,
  ) {
    super();
  }

  async process(job: Job<SyncIntegrationJob | PushContactJob>): Promise<void> {
    if (job.name === JOB.SYNC_INTEGRATION) return this.handleInbound(job.data as SyncIntegrationJob);
    if (job.name === JOB.PUSH_CONTACT) return this.handleOutbound(job.data as PushContactJob);
  }

  private async handleInbound({ webhookEventId }: SyncIntegrationJob): Promise<void> {
    const event = await this.prisma.webhookEvent.findUnique({ where: { id: webhookEventId } });
    if (!event || event.status === 'PROCESSED') return;
    if (!event.organizationId || !event.eventType) {
      await this.fail(webhookEventId, 'Missing org or provider on event');
      return;
    }

    const provider = event.eventType as ProviderEnum;
    const impl = this.factory.get(provider);
    const config =
      (await this.integrations.getContext(event.organizationId, provider))?.config ?? {};

    let leads: NormalizedLead[] = [];
    try {
      leads = impl.parseWebhook(event.payload, config);
    } catch (e) {
      await this.fail(webhookEventId, `parse failed: ${(e as Error).message}`);
      return;
    }

    let created = 0;
    for (const lead of leads) {
      if (!lead.phone && !lead.email) continue; // can't form a contact without either
      const contact = await this.upsertContact(event.organizationId, lead);
      if (!contact) continue;
      await this.prisma.lead.create({
        data: {
          organizationId: event.organizationId,
          contactId: contact.id,
          source: lead.source,
          status: 'NEW',
        },
      });
      created++;
      this.events.emit('integration.lead.received', {
        organizationId: event.organizationId,
        provider,
        contactId: contact.id,
        source: lead.source,
      });
    }

    await this.prisma.webhookEvent.update({
      where: { id: webhookEventId },
      data: { status: 'PROCESSED', processedAt: new Date() },
    });
    await this.prisma.integration.updateMany({
      where: { organizationId: event.organizationId, provider },
      data: { lastSyncedAt: new Date() },
    });
    this.logger.log(`Synced ${created} lead(s) from ${provider} for ${event.organizationId}`);
  }

  /** Phone is the contact key (org+phone unique). Email-only leads fall back to a lookup. */
  private async upsertContact(organizationId: string, lead: NormalizedLead) {
    if (lead.phone) {
      return this.prisma.contact.upsert({
        where: { organizationId_phone: { organizationId, phone: lead.phone } },
        create: {
          organizationId,
          phone: lead.phone,
          name: lead.name,
          email: lead.email,
          countryCode: lead.countryCode,
          attributes: (lead.attributes ?? undefined) as Prisma.InputJsonValue | undefined,
        },
        update: {
          name: lead.name ?? undefined,
          email: lead.email ?? undefined,
          lastContactedAt: new Date(),
        },
      });
    }
    // No phone: match an existing contact by email, else skip (WhatsApp needs a number).
    const existing = lead.email
      ? await this.prisma.contact.findFirst({ where: { organizationId, email: lead.email } })
      : null;
    if (!existing) {
      this.logger.warn(`Skipping ${lead.source} lead with no phone and no known email`);
    }
    return existing;
  }

  private async handleOutbound({ organizationId, provider, contactId }: PushContactJob): Promise<void> {
    const ctx = await this.integrations.getContext(organizationId, provider as ProviderEnum);
    if (!ctx) return;
    const impl = this.factory.get(provider as ProviderEnum);
    if (!impl.pushContact) return;
    const contact = await this.prisma.contact.findFirst({ where: { id: contactId, organizationId } });
    if (!contact) return;
    const result = await impl.pushContact(
      {
        name: contact.name ?? undefined,
        phone: contact.phone,
        email: contact.email ?? undefined,
        source: 'platform',
      },
      ctx,
    );
    this.logger.log(`Push to ${provider}: ${result.ok ? 'ok' : 'failed'} ${result.detail ?? ''}`);
  }

  private async fail(id: string, error: string): Promise<void> {
    this.logger.error(error);
    await this.prisma.webhookEvent.update({
      where: { id },
      data: { status: 'FAILED', error, attempts: { increment: 1 } },
    });
  }
}
