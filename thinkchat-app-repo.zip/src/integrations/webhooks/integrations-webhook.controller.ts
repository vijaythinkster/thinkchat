import { InjectQueue } from '@nestjs/bullmq';
import {
  BadRequestException,
  Controller,
  ForbiddenException,
  Get,
  Headers,
  HttpCode,
  Logger,
  Param,
  Post,
  Query,
  Req,
  UnauthorizedException,
} from '@nestjs/common';
import { Queue } from 'bullmq';
import { createHash } from 'crypto';
import type { Request } from 'express';
import { IntegrationProvider as ProviderEnum, Prisma } from '@prisma/client';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { Public } from 'src/auth/decorators/public.decorator';
import { JOB, QUEUE, SyncIntegrationJob } from 'src/whatsapp/queue/queue.constants';
import { IntegrationsService } from './integrations.service';
import { IntegrationProviderFactory } from './providers/integration-provider.factory';
import { toWebhookProvider } from './providers/integration-provider.interface';

/**
 * Public endpoint third-party platforms post to. Same discipline as the WhatsApp
 * webhook: verify authenticity -> dedupe + persist -> return 200 in milliseconds,
 * then enqueue. The integration-sync worker does all the actual lead processing.
 *
 * URL shape: /webhooks/integrations/:provider/:organizationId
 * (the org is in the path because these callers are unauthenticated and we must
 * know which tenant to attribute the event to).
 */
@Public()
@Controller('webhooks/integrations')
export class IntegrationsWebhookController {
  private readonly logger = new Logger(IntegrationsWebhookController.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly integrations: IntegrationsService,
    private readonly factory: IntegrationProviderFactory,
    @InjectQueue(QUEUE.INTEGRATION_SYNC) private readonly queue: Queue<SyncIntegrationJob>,
  ) {}

  private parse(raw: string): ProviderEnum {
    const p = raw.toUpperCase() as ProviderEnum;
    if (!Object.values(ProviderEnum).includes(p)) throw new BadRequestException('Unknown provider');
    return p;
  }

  /** Verification handshake (Meta leadgen uses hub.challenge; others optional). */
  @Get(':provider/:organizationId')
  async verify(
    @Param('provider') rawProvider: string,
    @Param('organizationId') organizationId: string,
    @Query('hub.mode') mode: string,
    @Query('hub.verify_token') token: string,
    @Query('hub.challenge') challenge: string,
  ): Promise<string> {
    const provider = this.parse(rawProvider);
    const ctx = await this.integrations.getContext(organizationId, provider);
    const expected = ctx?.credentials.verifyToken;
    if (mode === 'subscribe' && expected && token === expected) return challenge;
    throw new ForbiddenException('Verification failed');
  }

  @Post(':provider/:organizationId')
  @HttpCode(200)
  async receive(
    @Param('provider') rawProvider: string,
    @Param('organizationId') organizationId: string,
    @Req() req: Request & { rawBody?: Buffer },
    @Headers() headers: Record<string, string | undefined>,
  ): Promise<{ status: string }> {
    const provider = this.parse(rawProvider);
    const impl = this.factory.get(provider);
    const ctx = await this.integrations.getContext(organizationId, provider);
    if (!ctx) throw new UnauthorizedException('Integration not connected');

    const raw = req.rawBody ?? Buffer.from(JSON.stringify(req.body));
    const secret =
      ctx.credentials.webhookSecret ?? ctx.credentials.appSecret ?? ctx.credentials.token ?? '';

    if (!impl.verifySignature(raw, headers, secret)) {
      this.logger.warn(`Rejected ${provider} webhook for ${organizationId}: bad signature/token`);
      throw new UnauthorizedException('Invalid signature');
    }

    // Dedupe within the CUSTOM bucket by prefixing the provider onto the body hash.
    const externalId = `${provider}:${createHash('sha256').update(raw).digest('hex')}`;
    try {
      const event = await this.prisma.webhookEvent.create({
        data: {
          organizationId,
          provider: toWebhookProvider(provider),
          eventType: provider,
          externalId,
          payload: req.body as Prisma.InputJsonValue,
          status: 'RECEIVED',
        },
      });
      await this.queue.add(
        JOB.SYNC_INTEGRATION,
        { webhookEventId: event.id },
        { attempts: 5, backoff: { type: 'exponential', delay: 1000 }, removeOnComplete: 1000 },
      );
      return { status: 'queued' };
    } catch (e) {
      // Unique violation => already received this exact delivery; ack idempotently.
      if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === 'P2002') {
        return { status: 'duplicate' };
      }
      throw e;
    }
  }
}
