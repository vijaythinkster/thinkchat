import { Logger } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { JwtService } from '@nestjs/jwt';
import {
  ConnectedSocket, MessageBody, OnGatewayConnection, OnGatewayDisconnect,
  SubscribeMessage, WebSocketGateway, WebSocketServer,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { PrismaService } from 'src/common/prisma/prisma.service';

/**
 * Realtime inbox transport. Clients authenticate with their JWT on the
 * handshake and are placed in a per-tenant room (`org:<id>`) so events never
 * leak across organizations. Domain events emitted by the WhatsApp module
 * (message received / status / sent) are fanned out to the relevant room.
 */
@WebSocketGateway({
  namespace: '/inbox',
  cors: { origin: process.env.WEB_ORIGIN ?? true, credentials: true },
})
export class InboxGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer() server!: Server;
  private readonly logger = new Logger(InboxGateway.name);

  constructor(
    private readonly jwt: JwtService,
    private readonly prisma: PrismaService,
  ) {}

  async handleConnection(client: Socket): Promise<void> {
    try {
      const raw =
        (client.handshake.auth?.token as string) ??
        (client.handshake.headers.authorization ?? '').replace('Bearer ', '');
      const payload = await this.jwt.verifyAsync<{ sub: string; organizationId: string }>(raw);
      client.data.organizationId = payload.organizationId;
      client.data.userId = payload.sub;
      await client.join(`org:${payload.organizationId}`);
      this.logger.debug(`Socket ${client.id} joined org:${payload.organizationId}`);
    } catch {
      client.disconnect(true);
    }
  }

  handleDisconnect(client: Socket): void {
    // Presence/agent-status cleanup hooks in here (Phase 5 presence).
    this.logger.debug(`Socket ${client.id} disconnected`);
  }

  /** Subscribe to a single conversation for typing indicators / read sync. */
  @SubscribeMessage('conversation:open')
  async onOpen(@ConnectedSocket() client: Socket, @MessageBody() data: { conversationId: string }) {
    await client.join(`conv:${data.conversationId}`);
    return { ok: true };
  }

  @SubscribeMessage('typing')
  onTyping(@ConnectedSocket() client: Socket, @MessageBody() data: { conversationId: string }) {
    client.to(`conv:${data.conversationId}`).emit('typing', {
      conversationId: data.conversationId,
      userId: client.data.userId,
    });
  }

  @OnEvent('whatsapp.message.received')
  async onReceived(p: { organizationId: string; conversationId: string; messageId: string }) {
    const message = await this.prisma.message.findUnique({ where: { id: p.messageId } });
    this.server.to(`org:${p.organizationId}`).emit('message:new', message);
  }

  @OnEvent('whatsapp.message.sent')
  async onSent(p: { organizationId: string; messageId: string; waMessageId?: string }) {
    const message = await this.prisma.message.findUnique({ where: { id: p.messageId } });
    this.server.to(`org:${p.organizationId}`).emit('message:new', message);
  }

  @OnEvent('whatsapp.message.status')
  onStatus(p: { organizationId: string; waMessageId: string; status: string }) {
    this.server.to(`org:${p.organizationId}`).emit('message:status', p);
  }
}
