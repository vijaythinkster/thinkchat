import { IsArray, IsEnum, IsNotEmpty, IsOptional, IsString } from 'class-validator';
import { TemplateMetaCategory } from '@prisma/client';

export class CreateTemplateDto {
  @IsString() @IsNotEmpty() whatsAppNumberId!: string;
  @IsString() @IsNotEmpty() name!: string; // lowercase, snake_case
  @IsString() @IsNotEmpty() language!: string; // e.g. en_US
  @IsEnum(TemplateMetaCategory) category!: TemplateMetaCategory;
  @IsArray() components!: any[]; // header/body/footer/buttons per Meta spec
  @IsOptional() @IsString() templateCategoryId?: string;
}
