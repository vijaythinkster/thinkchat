import { IsNotEmpty, IsString } from 'class-validator';

/**
 * Payload returned by Meta's Embedded Signup (Facebook Login for Business).
 * The frontend captures `code` from FB.login and `wabaId`/`phoneNumberId` from
 * the WA_EMBEDDED_SIGNUP `message` event, then posts them here.
 */
export class CompleteSignupDto {
  @IsString() @IsNotEmpty() code!: string;
  @IsString() @IsNotEmpty() wabaId!: string;
  @IsString() @IsNotEmpty() phoneNumberId!: string;
}
