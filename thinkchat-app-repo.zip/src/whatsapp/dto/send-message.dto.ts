import { Type } from 'class-transformer';
import {
  IsBoolean, IsEnum, IsIn, IsNotEmpty, IsObject, IsOptional, IsString, ValidateNested,
} from 'class-validator';

export type OutboundType = 'text' | 'image' | 'video' | 'audio' | 'document' | 'template' | 'interactive';

class TemplateLanguageDto { @IsString() code!: string }

class TemplateDto {
  @IsString() @IsNotEmpty() name!: string;
  @ValidateNested() @Type(() => TemplateLanguageDto) language!: TemplateLanguageDto;
  @IsOptional() components?: any[];
}

class MediaDto {
  @IsOptional() @IsString() id?: string;   // uploaded media id
  @IsOptional() @IsString() link?: string; // or public link
  @IsOptional() @IsString() caption?: string;
  @IsOptional() @IsString() filename?: string;
}

export class SendMessageDto {
  @IsString() @IsNotEmpty() conversationId!: string;

  @IsIn(['text', 'image', 'video', 'audio', 'document', 'template', 'interactive'])
  type!: OutboundType;

  @IsOptional() @IsString() text?: string;
  @IsOptional() @IsBoolean() previewUrl?: boolean;

  @IsOptional() @ValidateNested() @Type(() => MediaDto) media?: MediaDto;

  @IsOptional() @ValidateNested() @Type(() => TemplateDto) template?: TemplateDto;

  @IsOptional() @IsObject() interactive?: Record<string, any>;

  // Idempotency key from the client to dedupe double-submits.
  @IsOptional() @IsString() clientRef?: string;
}
