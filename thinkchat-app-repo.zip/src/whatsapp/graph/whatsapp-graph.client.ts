import { HttpService } from '@nestjs/axios';
import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { AxiosError, AxiosRequestConfig } from 'axios';
import { firstValueFrom } from 'rxjs';
import * as FormData from 'form-data';
import { GraphOutboundPayload, GraphSendResponse } from '../whatsapp.types';

export class WhatsAppGraphError extends Error {
  readonly retryable: boolean;
  constructor(
    message: string,
    readonly code?: number | string,
    readonly subcode?: number,
    readonly fbtraceId?: string,
    readonly httpStatus?: number,
  ) {
    super(message);
    this.name = 'WhatsAppGraphError';
    // 5xx, throttling (#4, #80007, #130429) and timeouts are worth retrying;
    // 4xx business errors (re-engagement, bad recipient, template paused) are not.
    this.retryable =
      (httpStatus ?? 0) >= 500 ||
      [4, 80007, 130429, 131056].includes(Number(code));
  }
}

interface PhoneNumberInfo {
  id: string;
  display_phone_number: string;
  verified_name: string;
  quality_rating: string;
  code_verification_status: string;
  platform_type?: string;
}

@Injectable()
export class WhatsAppGraphClient {
  private readonly logger = new Logger(WhatsAppGraphClient.name);

  constructor(
    private readonly http: HttpService,
    private readonly config: ConfigService,
  ) {}

  private get baseUrl(): string {
    const base = this.config.get<string>('whatsapp.graphBaseUrl');
    const version = this.config.get<string>('whatsapp.graphVersion');
    return `${base}/${version}`;
  }

  private async request<T>(cfg: AxiosRequestConfig, accessToken?: string): Promise<T> {
    const headers = {
      ...(cfg.headers ?? {}),
      ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
    };
    try {
      const res = await firstValueFrom(this.http.request<T>({ ...cfg, headers }));
      return res.data;
    } catch (err) {
      throw this.normalizeError(err);
    }
  }

  private normalizeError(err: unknown): WhatsAppGraphError {
    const ax = err as AxiosError<{ error?: any }>;
    const fb = ax.response?.data?.error;
    if (fb) {
      this.logger.warn(`Graph error ${fb.code}/${fb.error_subcode}: ${fb.message}`);
      return new WhatsAppGraphError(fb.message, fb.code, fb.error_subcode, fb.fbtrace_id, ax.response?.status);
    }
    return new WhatsAppGraphError(ax.message ?? 'Unknown Graph API error', undefined, undefined, undefined, ax.response?.status);
  }

  // ---------------- Messaging ----------------
  sendMessage(phoneNumberId: string, accessToken: string, payload: GraphOutboundPayload) {
    return this.request<GraphSendResponse>(
      { method: 'POST', url: `${this.baseUrl}/${phoneNumberId}/messages`, data: payload },
      accessToken,
    );
  }

  markAsRead(phoneNumberId: string, accessToken: string, messageId: string) {
    return this.request(
      {
        method: 'POST',
        url: `${this.baseUrl}/${phoneNumberId}/messages`,
        data: { messaging_product: 'whatsapp', status: 'read', message_id: messageId },
      },
      accessToken,
    );
  }

  // ---------------- Media ----------------
  uploadMedia(
    phoneNumberId: string,
    accessToken: string,
    file: { buffer: Buffer; filename: string; mimeType: string },
  ) {
    const form = new FormData();
    form.append('messaging_product', 'whatsapp');
    form.append('file', file.buffer, { filename: file.filename, contentType: file.mimeType });
    return this.request<{ id: string }>(
      { method: 'POST', url: `${this.baseUrl}/${phoneNumberId}/media`, data: form, headers: form.getHeaders() },
      accessToken,
    );
  }

  getMediaUrl(mediaId: string, accessToken: string) {
    return this.request<{ url: string; mime_type: string; file_size: number; id: string }>(
      { method: 'GET', url: `${this.baseUrl}/${mediaId}` },
      accessToken,
    );
  }

  async downloadMedia(mediaUrl: string, accessToken: string): Promise<Buffer> {
    // Media binary lives on lookaside.fbsbx.com and still requires the bearer token.
    const res = await firstValueFrom(
      this.http.get(mediaUrl, {
        responseType: 'arraybuffer',
        headers: { Authorization: `Bearer ${accessToken}` },
      }),
    );
    return Buffer.from(res.data as ArrayBuffer);
  }

  // ---------------- Templates ----------------
  listTemplates(wabaId: string, accessToken: string, after?: string) {
    const params: Record<string, any> = {
      limit: 200,
      fields: 'name,status,category,language,components,id,rejected_reason',
    };
    if (after) params.after = after;
    return this.request<{ data: any[]; paging?: { cursors?: { after?: string }; next?: string } }>(
      { method: 'GET', url: `${this.baseUrl}/${wabaId}/message_templates`, params },
      accessToken,
    );
  }

  createTemplate(wabaId: string, accessToken: string, body: Record<string, any>) {
    return this.request<{ id: string; status: string; category: string }>(
      { method: 'POST', url: `${this.baseUrl}/${wabaId}/message_templates`, data: body },
      accessToken,
    );
  }

  // ---------------- Onboarding ----------------
  exchangeCodeForToken(code: string) {
    return this.request<{ access_token: string; token_type: string; expires_in?: number }>({
      method: 'GET',
      url: `${this.baseUrl}/oauth/access_token`,
      params: {
        client_id: this.config.get('whatsapp.appId'),
        client_secret: this.config.get('whatsapp.appSecret'),
        code,
      },
    });
  }

  subscribeApp(wabaId: string, accessToken: string) {
    return this.request<{ success: boolean }>(
      { method: 'POST', url: `${this.baseUrl}/${wabaId}/subscribed_apps` },
      accessToken,
    );
  }

  registerPhoneNumber(phoneNumberId: string, accessToken: string, pin: string) {
    return this.request<{ success: boolean }>(
      {
        method: 'POST',
        url: `${this.baseUrl}/${phoneNumberId}/register`,
        data: { messaging_product: 'whatsapp', pin },
      },
      accessToken,
    );
  }

  getPhoneNumber(phoneNumberId: string, accessToken: string) {
    return this.request<PhoneNumberInfo>(
      {
        method: 'GET',
        url: `${this.baseUrl}/${phoneNumberId}`,
        params: { fields: 'id,display_phone_number,verified_name,quality_rating,code_verification_status,platform_type' },
      },
      accessToken,
    );
  }

  getPhoneNumbers(wabaId: string, accessToken: string) {
    return this.request<{ data: PhoneNumberInfo[] }>(
      {
        method: 'GET',
        url: `${this.baseUrl}/${wabaId}/phone_numbers`,
        params: { fields: 'id,display_phone_number,verified_name,quality_rating,code_verification_status' },
      },
      accessToken,
    );
  }
}
