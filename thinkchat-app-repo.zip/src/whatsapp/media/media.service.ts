import { Injectable } from '@nestjs/common';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { StorageService } from 'src/common/storage/storage.service';
import { WhatsAppGraphClient } from '../graph/whatsapp-graph.client';
import { NumbersService } from '../numbers/numbers.service';

@Injectable()
export class MediaService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly graph: WhatsAppGraphClient,
    private readonly numbers: NumbersService,
    private readonly storage: StorageService,
  ) {}

  /** Upload a local file to Meta, returning the media id used in outbound sends. */
  async upload(
    organizationId: string,
    whatsAppNumberId: string,
    file: { buffer: Buffer; filename: string; mimeType: string },
  ): Promise<{ mediaId: string }> {
    const number = await this.numbers.getOrThrow(organizationId, whatsAppNumberId);
    const token = this.numbers.accessToken(number);
    const { id } = await this.graph.uploadMedia(number.phoneNumberId, token, file);
    return { mediaId: id };
  }

  /**
   * Download inbound media (referenced by media id), persist to S3, and return a
   * durable URL. Media urls from Meta expire in ~5 minutes, so we mirror on receipt.
   */
  async downloadAndStore(
    organizationId: string,
    whatsAppNumberId: string,
    mediaId: string,
  ): Promise<{ url: string; mimeType: string }> {
    const number = await this.numbers.getOrThrow(organizationId, whatsAppNumberId);
    const token = this.numbers.accessToken(number);
    const meta = await this.graph.getMediaUrl(mediaId, token);
    const buffer = await this.graph.downloadMedia(meta.url, token);
    const stored = await this.storage.putObject(
      organizationId,
      `whatsapp/${whatsAppNumberId}/${mediaId}`,
      buffer,
      meta.mime_type,
    );
    return { url: stored.url, mimeType: meta.mime_type };
  }
}
