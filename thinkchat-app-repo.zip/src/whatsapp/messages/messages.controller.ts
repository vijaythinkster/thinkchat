import { Body, Controller, Param, Post } from '@nestjs/common';
import { MessagesService } from './messages.service';
import { SendMessageDto } from '../dto/send-message.dto';

/**
 * Tenant context (organizationId) is resolved by the global auth/tenant guard
 * and read from the request. Shown here as a decorator for brevity.
 */
import { OrgId } from 'src/common/tenant/org-id.decorator';

@Controller('messages')
export class MessagesController {
  constructor(private readonly messages: MessagesService) {}

  @Post()
  send(@OrgId() organizationId: string, @Body() dto: SendMessageDto) {
    return this.messages.send(organizationId, dto);
  }

  @Post(':id/read')
  markRead(@OrgId() organizationId: string, @Param('id') messageId: string) {
    // Enqueued similarly; mark-as-read calls Meta and updates the inbound row.
    return this.messages.markRead(organizationId, messageId);
  }
}
