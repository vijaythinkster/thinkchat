import { InjectQueue } from '@nestjs/bullmq';
import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { Message, MessageType } from '@prisma/client';
import { Queue } from 'bullmq';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { SendMessageDto } from '../dto/send-message.dto';
import { JOB, QUEUE, SendMessageJob } from '../queue/queue.constants';
import { GraphOutboundPayload } from '../whatsapp.types';
import { WhatsAppGraphClient } from '../graph/whatsapp-graph.client';
import { NumbersService } from '../numbers/numbers.service';

@Injectable()
export class MessagesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly graph: WhatsAppGraphClient,
    private readonly numbers: NumbersService,
    @InjectQueue(QUEUE.MESSAGE_SEND) private readonly sendQueue: Queue<SendMessageJob>,
  ) {}

  /**
   * Validate, persist an OUTBOUND message in QUEUED state, then enqueue the send.
   * Sends never hit Meta inline — the worker owns delivery + retry.
   */
  async send(organizationId: string, dto: SendMessageDto): Promise<Message> {
    const conversation = await this.prisma.conversation.findFirst({
      where: { id: dto.conversationId, organizationId, deletedAt: null },
      include: { contact: true },
    });
    if (!conversation) throw new NotFoundException('Conversation not found');

    // Free-form (session) messages are only allowed inside the 24h customer
    // service window. Outside it, only approved templates may be sent.
    const withinWindow =
      !!conversation.windowExpiresAt && conversation.windowExpiresAt > new Date();
    if (dto.type !== 'template' && !withinWindow) {
      throw new BadRequestException(
        'Outside the 24h service window — only template messages can be sent',
      );
    }

    // Idempotency: a repeated clientRef on the same conversation returns the
    // existing message instead of sending twice.
    if (dto.clientRef) {
      const existing = await this.prisma.message.findFirst({
        where: { organizationId, conversationId: dto.conversationId, payload: { path: ['clientRef'], equals: dto.clientRef } },
      });
      if (existing) return existing;
    }

    const payload = this.buildPayload(conversation.contact.phone, dto);

    const message = await this.prisma.message.create({
      data: {
        organizationId,
        conversationId: conversation.id,
        whatsAppNumberId: conversation.whatsAppNumberId,
        direction: 'OUTBOUND',
        type: this.toMessageType(dto.type),
        status: 'QUEUED',
        body: dto.type === 'text' ? dto.text ?? null : dto.media?.caption ?? null,
        payload: { graph: payload, clientRef: dto.clientRef ?? null } as object,
      },
    });

    await this.sendQueue.add(
      JOB.SEND_MESSAGE,
      { organizationId, messageId: message.id },
      {
        attempts: 5,
        backoff: { type: 'exponential', delay: 2000 },
        removeOnComplete: 1000,
        removeOnFail: 5000,
      },
    );

    return message;
  }

  /** Send a read receipt to Meta and flag the inbound message as read locally. */
  async markRead(organizationId: string, messageId: string): Promise<Message> {
    const message = await this.prisma.message.findFirst({
      where: { id: messageId, organizationId, direction: 'INBOUND' },
    });
    if (!message?.waMessageId) throw new NotFoundException('Inbound message not found');
    if (!message.whatsAppNumberId) throw new BadRequestException('Message has no channel');

    const number = await this.numbers.getOrThrow(organizationId, message.whatsAppNumberId);
    await this.graph.markAsRead(number.phoneNumberId, this.numbers.accessToken(number), message.waMessageId);

    return this.prisma.message.update({
      where: { id: message.id },
      data: { readAt: new Date() },
    });
  }

  private toMessageType(t: SendMessageDto['type']): MessageType {
    const map: Record<SendMessageDto['type'], MessageType> = {
      text: 'TEXT', image: 'IMAGE', video: 'VIDEO', audio: 'AUDIO',
      document: 'DOCUMENT', template: 'TEMPLATE', interactive: 'INTERACTIVE',
    };
    return map[t];
  }

  /** Translate our DTO into the exact Graph API send payload. */
  private buildPayload(to: string, dto: SendMessageDto): GraphOutboundPayload {
    const base = { messaging_product: 'whatsapp' as const, to };
    switch (dto.type) {
      case 'text':
        if (!dto.text) throw new BadRequestException('text is required');
        return { ...base, type: 'text', text: { body: dto.text, preview_url: dto.previewUrl ?? false } };
      case 'image':
      case 'video':
      case 'audio':
      case 'document': {
        if (!dto.media?.id && !dto.media?.link) {
          throw new BadRequestException('media.id or media.link is required');
        }
        const media: Record<string, any> = {};
        if (dto.media.id) media.id = dto.media.id;
        if (dto.media.link) media.link = dto.media.link;
        if (dto.media.caption) media.caption = dto.media.caption;
        if (dto.type === 'document' && dto.media.filename) media.filename = dto.media.filename;
        return { ...base, type: dto.type, [dto.type]: media };
      }
      case 'template':
        if (!dto.template) throw new BadRequestException('template is required');
        return {
          ...base,
          type: 'template',
          template: {
            name: dto.template.name,
            language: { code: dto.template.language.code },
            components: dto.template.components,
          },
        };
      case 'interactive':
        if (!dto.interactive) throw new BadRequestException('interactive is required');
        return { ...base, type: 'interactive', interactive: dto.interactive };
      default:
        throw new BadRequestException('Unsupported message type');
    }
  }
}
