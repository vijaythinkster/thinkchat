import { Injectable, NotFoundException } from '@nestjs/common';
import { WhatsAppNumber } from '@prisma/client';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { EncryptionService } from 'src/common/security/encryption.service';

@Injectable()
export class NumbersService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly encryption: EncryptionService,
  ) {}

  list(organizationId: string) {
    return this.prisma.whatsAppNumber.findMany({
      where: { organizationId, deletedAt: null },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getOrThrow(organizationId: string, id: string): Promise<WhatsAppNumber> {
    const number = await this.prisma.whatsAppNumber.findFirst({
      where: { id, organizationId, deletedAt: null },
    });
    if (!number) throw new NotFoundException('WhatsApp number not found');
    return number;
  }

  /** Resolve the inbound number by Meta phone_number_id (used by webhook worker). */
  findByPhoneNumberId(phoneNumberId: string) {
    return this.prisma.whatsAppNumber.findUnique({ where: { phoneNumberId } });
  }

  /** Decrypt the stored WABA access token for Graph calls. */
  accessToken(number: Pick<WhatsAppNumber, 'accessToken'>): string {
    if (!number.accessToken) throw new NotFoundException('Number has no access token');
    return this.encryption.decrypt(number.accessToken);
  }

  async disconnect(organizationId: string, id: string) {
    await this.getOrThrow(organizationId, id);
    return this.prisma.whatsAppNumber.update({
      where: { id },
      data: { status: 'DISCONNECTED' },
    });
  }
}
