import { Body, Controller, Post } from '@nestjs/common';
import { OrgId } from 'src/common/tenant/org-id.decorator';
import { OnboardingService } from './onboarding.service';
import { CompleteSignupDto } from '../dto/embedded-signup.dto';

@Controller('whatsapp/onboarding')
export class OnboardingController {
  constructor(private readonly onboarding: OnboardingService) {}

  @Post('complete')
  complete(@OrgId() organizationId: string, @Body() dto: CompleteSignupDto) {
    return this.onboarding.completeSignup(organizationId, dto);
  }
}
