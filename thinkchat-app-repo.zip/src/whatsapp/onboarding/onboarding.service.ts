import { InjectQueue } from '@nestjs/bullmq';
import { BadRequestException, Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Queue } from 'bullmq';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { EncryptionService } from 'src/common/security/encryption.service';
import { WhatsAppGraphClient } from '../graph/whatsapp-graph.client';
import { CompleteSignupDto } from '../dto/embedded-signup.dto';
import { JOB, QUEUE, SyncTemplatesJob } from '../queue/queue.constants';

/**
 * Embedded Signup completion. The frontend runs Facebook Login for Business and
 * posts {code, wabaId, phoneNumberId}. We exchange the code for a business token,
 * subscribe our app to the WABA's webhooks, register the number for Cloud API,
 * then persist an encrypted, CONNECTED WhatsAppNumber.
 */
@Injectable()
export class OnboardingService {
  private readonly logger = new Logger(OnboardingService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly graph: WhatsAppGraphClient,
    private readonly encryption: EncryptionService,
    private readonly config: ConfigService,
    @InjectQueue(QUEUE.TEMPLATE_SYNC) private readonly templateQueue: Queue<SyncTemplatesJob>,
  ) {}

  async completeSignup(organizationId: string, dto: CompleteSignupDto) {
    // 1. Exchange the short-lived code for a long-lived business access token.
    const { access_token } = await this.graph.exchangeCodeForToken(dto.code);

    // 2. Subscribe our app to this WABA so Meta sends us its webhooks.
    await this.graph.subscribeApp(dto.wabaId, access_token);

    // 3. Register the phone number for Cloud API (two-step verification PIN).
    const pin = this.config.get<string>('whatsapp.defaultRegisterPin');
    if (!pin) throw new BadRequestException('Registration PIN not configured');
    await this.graph.registerPhoneNumber(dto.phoneNumberId, access_token, pin);

    // 4. Read back the number's metadata for display + quality monitoring.
    const info = await this.graph.getPhoneNumber(dto.phoneNumberId, access_token);

    // 5. Persist (token encrypted at rest).
    const number = await this.prisma.whatsAppNumber.upsert({
      where: { phoneNumberId: dto.phoneNumberId },
      create: {
        organizationId,
        wabaId: dto.wabaId,
        phoneNumberId: dto.phoneNumberId,
        displayPhone: info.display_phone_number,
        verifiedName: info.verified_name,
        qualityRating: info.quality_rating,
        status: 'CONNECTED',
        accessToken: this.encryption.encrypt(access_token),
      },
      update: {
        wabaId: dto.wabaId,
        displayPhone: info.display_phone_number,
        verifiedName: info.verified_name,
        qualityRating: info.quality_rating,
        status: 'CONNECTED',
        accessToken: this.encryption.encrypt(access_token),
      },
    });

    // 6. Backfill existing approved templates.
    await this.templateQueue.add(JOB.SYNC_TEMPLATES, { organizationId, whatsAppNumberId: number.id });

    this.logger.log(`Connected number ${number.displayPhone} for org ${organizationId}`);
    return number;
  }
}
