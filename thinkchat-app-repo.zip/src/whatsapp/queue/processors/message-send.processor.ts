import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Job } from 'bullmq';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { WhatsAppGraphClient, WhatsAppGraphError } from '../../graph/whatsapp-graph.client';
import { NumbersService } from '../../numbers/numbers.service';
import { JOB, QUEUE, SendMessageJob } from '../queue.constants';
import { GraphOutboundPayload } from '../../whatsapp.types';

/**
 * Owns outbound delivery to Meta. concurrency + limiter approximate the number's
 * Meta throughput tier; transient Graph errors throw to trigger BullMQ backoff,
 * permanent ones are recorded as FAILED and acked.
 */
@Processor(QUEUE.MESSAGE_SEND, { concurrency: 20, limiter: { max: 60, duration: 1000 } })
export class MessageSendProcessor extends WorkerHost {
  private readonly logger = new Logger(MessageSendProcessor.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly graph: WhatsAppGraphClient,
    private readonly numbers: NumbersService,
    private readonly events: EventEmitter2,
  ) {
    super();
  }

  async process(job: Job<SendMessageJob>): Promise<void> {
    if (job.name !== JOB.SEND_MESSAGE) return;
    const { organizationId, messageId } = job.data;

    const message = await this.prisma.message.findFirst({
      where: { id: messageId, organizationId },
    });
    if (!message || message.status !== 'QUEUED') return; // already sent or gone
    if (!message.whatsAppNumberId) throw new Error('Message missing channel');

    const number = await this.numbers.getOrThrow(organizationId, message.whatsAppNumberId);
    const token = this.numbers.accessToken(number);
    const payload = (message.payload as any)?.graph as GraphOutboundPayload;
    const campaignRecipientId = (message.payload as any)?.campaignRecipientId as string | undefined;

    try {
      const res = await this.graph.sendMessage(number.phoneNumberId, token, payload);
      const waMessageId = res.messages?.[0]?.id;
      await this.prisma.message.update({
        where: { id: message.id },
        data: { status: 'SENT', waMessageId, sentAt: new Date() },
      });
      // Stamp the recipient with the waMessageId so the webhook worker can later
      // advance it to DELIVERED / READ / FAILED via updateMany-by-waMessageId.
      if (campaignRecipientId && waMessageId) {
        await this.prisma.campaignRecipient.update({
          where: { id: campaignRecipientId },
          data: { status: 'SENT', sentAt: new Date(), waMessageId },
        });
      }
      this.events.emit('whatsapp.message.sent', { organizationId, messageId, waMessageId });
    } catch (err) {
      const e = err as WhatsAppGraphError;
      await this.prisma.message.update({
        where: { id: message.id },
        data: { status: 'FAILED', errorCode: String(e.code ?? ''), errorMessage: e.message },
      });
      if (campaignRecipientId && !e.retryable) {
        await this.prisma.campaignRecipient.update({
          where: { id: campaignRecipientId },
          data: { status: 'FAILED', failedReason: `${e.code ?? ''} ${e.message}`.trim() },
        });
      }
      if (e.retryable) throw e; // let BullMQ retry; status flips back via webhook on success
      this.logger.warn(`Permanent send failure for ${messageId}: ${e.code} ${e.message}`);
    }
  }
}
