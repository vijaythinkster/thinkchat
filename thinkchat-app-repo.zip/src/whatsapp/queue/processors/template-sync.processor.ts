import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Job } from 'bullmq';
import { JOB, QUEUE, SyncTemplatesJob } from '../queue.constants';
import { TemplatesService } from '../../templates/templates.service';

@Processor(QUEUE.TEMPLATE_SYNC, { concurrency: 5 })
export class TemplateSyncProcessor extends WorkerHost {
  constructor(private readonly templates: TemplatesService) {
    super();
  }

  async process(job: Job<SyncTemplatesJob>): Promise<void> {
    if (job.name !== JOB.SYNC_TEMPLATES) return;
    await this.templates.syncFromMeta(job.data.organizationId, job.data.whatsAppNumberId);
  }
}
