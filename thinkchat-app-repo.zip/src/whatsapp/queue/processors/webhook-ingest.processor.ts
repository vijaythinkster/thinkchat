import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Job } from 'bullmq';
import { JOB, ProcessWebhookJob, QUEUE } from '../queue.constants';
import { WebhookIngestService } from '../../webhooks/webhook-ingest.service';

@Processor(QUEUE.WEBHOOK_INGEST, { concurrency: 25 })
export class WebhookIngestProcessor extends WorkerHost {
  constructor(private readonly ingest: WebhookIngestService) {
    super();
  }

  async process(job: Job<ProcessWebhookJob>): Promise<void> {
    if (job.name !== JOB.PROCESS_WEBHOOK) return;
    await this.ingest.process(job.data.webhookEventId);
  }
}
