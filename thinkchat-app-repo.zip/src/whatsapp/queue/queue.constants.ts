export const QUEUE = {
  MESSAGE_SEND: 'message-send',
  WEBHOOK_INGEST: 'webhook-ingest',
  TEMPLATE_SYNC: 'template-sync',
  MEDIA_DOWNLOAD: 'media-download',
  BILLING_METER: 'billing-meter',
  CAMPAIGN_DISPATCH: 'campaign-dispatch',
  AI_INFERENCE: 'ai-inference',
  FLOW_EXEC: 'flow-exec',
  INTEGRATION_SYNC: 'integration-sync',
} as const;

export const JOB = {
  SEND_MESSAGE: 'send-message',
  PROCESS_WEBHOOK: 'process-webhook',
  SYNC_TEMPLATES: 'sync-templates',
  DOWNLOAD_MEDIA: 'download-media',
  METER_MESSAGE: 'meter-message',
  DISPATCH_CAMPAIGN: 'dispatch-campaign',
  RUN_INFERENCE: 'run-inference',
  SYNC_INTEGRATION: 'sync-integration',
  PUSH_CONTACT: 'push-contact',
} as const;

export interface SendMessageJob {
  organizationId: string;
  messageId: string;
}
export interface ProcessWebhookJob {
  webhookEventId: string;
}
export interface SyncTemplatesJob {
  organizationId: string;
  whatsAppNumberId: string;
}
export interface MeterMessageJob {
  organizationId: string;
  whatsAppNumberId: string;
  category: string | null;
  countryCode: string | null;
  waMessageId: string;
}
export interface DispatchCampaignJob {
  organizationId: string;
  campaignId: string;
  cursor?: string; // pagination cursor for large audiences
}
export interface RunInferenceJob {
  organizationId: string;
  conversationId: string;
  messageId: string;
  assistantId?: string; // resolved by the trigger; worker re-validates
}

/** Inbound integration webhook (lead capture, e-commerce event) to process. */
export interface SyncIntegrationJob {
  webhookEventId: string;
}
/** Outbound push of a contact/lead to a CRM integration (HubSpot, Salesforce, Asana). */
export interface PushContactJob {
  organizationId: string;
  provider: string; // IntegrationProvider enum value
  contactId: string;
}
