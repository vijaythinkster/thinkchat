import { Body, Controller, Get, Post } from '@nestjs/common';
import { OrgId } from 'src/common/tenant/org-id.decorator';
import { TemplatesService } from './templates.service';
import { CreateTemplateDto } from '../dto/create-template.dto';

@Controller('templates')
export class TemplatesController {
  constructor(private readonly templates: TemplatesService) {}

  @Get()
  list(@OrgId() organizationId: string) {
    return this.templates.list(organizationId);
  }

  @Post()
  create(@OrgId() organizationId: string, @Body() dto: CreateTemplateDto) {
    return this.templates.create(organizationId, dto);
  }
}
