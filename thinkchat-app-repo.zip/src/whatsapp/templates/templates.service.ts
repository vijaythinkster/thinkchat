import { Injectable, Logger } from '@nestjs/common';
import { TemplateMetaCategory, TemplateStatus } from '@prisma/client';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { WhatsAppGraphClient } from '../graph/whatsapp-graph.client';
import { NumbersService } from '../numbers/numbers.service';
import { CreateTemplateDto } from '../dto/create-template.dto';

@Injectable()
export class TemplatesService {
  private readonly logger = new Logger(TemplatesService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly graph: WhatsAppGraphClient,
    private readonly numbers: NumbersService,
  ) {}

  list(organizationId: string) {
    return this.prisma.template.findMany({
      where: { organizationId, deletedAt: null },
      orderBy: { updatedAt: 'desc' },
    });
  }

  /** Pull every template from the WABA and upsert local copies (paginated). */
  async syncFromMeta(organizationId: string, whatsAppNumberId: string): Promise<{ synced: number }> {
    const number = await this.numbers.getOrThrow(organizationId, whatsAppNumberId);
    const token = this.numbers.accessToken(number);

    let after: string | undefined;
    let synced = 0;
    do {
      const page = await this.graph.listTemplates(number.wabaId, token, after);
      for (const t of page.data ?? []) {
        await this.prisma.template.upsert({
          where: {
            organizationId_name_language: {
              organizationId, name: t.name, language: t.language,
            },
          },
          create: {
            organizationId,
            metaTemplateId: t.id,
            name: t.name,
            language: t.language,
            metaCategory: this.toCategory(t.category),
            status: this.toStatus(t.status),
            body: this.extractBody(t.components),
            components: t.components ?? [],
            rejectionReason: t.rejected_reason ?? null,
          },
          update: {
            metaTemplateId: t.id,
            metaCategory: this.toCategory(t.category),
            status: this.toStatus(t.status),
            body: this.extractBody(t.components),
            components: t.components ?? [],
            rejectionReason: t.rejected_reason ?? null,
          },
        });
        synced++;
      }
      after = page.paging?.cursors?.after && page.paging?.next ? page.paging.cursors.after : undefined;
    } while (after);

    this.logger.log(`Synced ${synced} templates for number ${whatsAppNumberId}`);
    return { synced };
  }

  /** Submit a new template to Meta for review and store it as PENDING. */
  async create(organizationId: string, dto: CreateTemplateDto) {
    const number = await this.numbers.getOrThrow(organizationId, dto.whatsAppNumberId);
    const token = this.numbers.accessToken(number);

    const res = await this.graph.createTemplate(number.wabaId, token, {
      name: dto.name,
      language: dto.language,
      category: dto.category,
      components: dto.components,
    });

    return this.prisma.template.upsert({
      where: { organizationId_name_language: { organizationId, name: dto.name, language: dto.language } },
      create: {
        organizationId,
        templateCategoryId: dto.templateCategoryId ?? null,
        metaTemplateId: res.id,
        name: dto.name,
        language: dto.language,
        metaCategory: dto.category,
        status: this.toStatus(res.status),
        body: this.extractBody(dto.components),
        components: dto.components,
      },
      update: { metaTemplateId: res.id, status: this.toStatus(res.status), components: dto.components },
    });
  }

  private toStatus(s: string): TemplateStatus {
    const map: Record<string, TemplateStatus> = {
      APPROVED: 'APPROVED', PENDING: 'PENDING', IN_APPEAL: 'PENDING', REJECTED: 'REJECTED',
      PAUSED: 'PAUSED', DISABLED: 'DISABLED', PENDING_DELETION: 'DISABLED',
    };
    return map[s] ?? 'PENDING';
  }

  private toCategory(c: string): TemplateMetaCategory {
    const map: Record<string, TemplateMetaCategory> = {
      MARKETING: 'MARKETING', UTILITY: 'UTILITY', AUTHENTICATION: 'AUTHENTICATION',
    };
    return map[c] ?? 'UTILITY';
  }

  private extractBody(components: any[] | undefined): string {
    return components?.find((c) => c.type === 'BODY')?.text ?? '';
  }
}
