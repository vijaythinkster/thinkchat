import { InjectQueue } from '@nestjs/bullmq';
import { Injectable, Logger } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { MessageStatus, MessageType, Prisma } from '@prisma/client';
import { Queue } from 'bullmq';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { JOB, MeterMessageJob, QUEUE } from '../queue/queue.constants';
import {
  InboundMessage, InboundStatus, WebhookEnvelope, WebhookValue,
} from '../whatsapp.types';

const WINDOW_MS = 24 * 60 * 60 * 1000;
const STATUS_RANK: Record<MessageStatus, number> = {
  QUEUED: 0, SENT: 1, DELIVERED: 2, READ: 3, FAILED: 1,
};

@Injectable()
export class WebhookIngestService {
  private readonly logger = new Logger(WebhookIngestService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly events: EventEmitter2,
    @InjectQueue(QUEUE.BILLING_METER) private readonly billingQueue: Queue<MeterMessageJob>,
  ) {}

  /** Entry point invoked by the webhook-ingest worker. Throws to trigger retry. */
  async process(webhookEventId: string): Promise<void> {
    const event = await this.prisma.webhookEvent.findUnique({ where: { id: webhookEventId } });
    if (!event || event.status === 'PROCESSED') return;

    await this.prisma.webhookEvent.update({
      where: { id: webhookEventId },
      data: { status: 'PROCESSING', attempts: { increment: 1 } },
    });

    try {
      const body = event.payload as unknown as WebhookEnvelope;
      for (const entry of body.entry ?? []) {
        for (const change of entry.changes ?? []) {
          if (change.field !== 'messages') continue;
          await this.handleValue(change.value);
        }
      }
      await this.prisma.webhookEvent.update({
        where: { id: webhookEventId },
        data: { status: 'PROCESSED', processedAt: new Date() },
      });
    } catch (err) {
      await this.prisma.webhookEvent.update({
        where: { id: webhookEventId },
        data: { status: 'FAILED', error: (err as Error).message },
      });
      throw err;
    }
  }

  private async handleValue(value: WebhookValue): Promise<void> {
    const phoneNumberId = value.metadata?.phone_number_id;
    const number = await this.prisma.whatsAppNumber.findUnique({ where: { phoneNumberId } });
    if (!number) {
      this.logger.warn(`No WhatsApp number for phone_number_id ${phoneNumberId}; skipping`);
      return;
    }
    const orgId = number.organizationId;

    for (const msg of value.messages ?? []) {
      await this.handleInbound(orgId, number.id, value, msg);
    }
    for (const status of value.statuses ?? []) {
      await this.handleStatus(orgId, number.id, status);
    }
  }

  private async handleInbound(
    organizationId: string,
    whatsAppNumberId: string,
    value: WebhookValue,
    msg: InboundMessage,
  ): Promise<void> {
    const profileName = value.contacts?.find((c) => c.wa_id === msg.from)?.profile?.name;

    const contact = await this.prisma.contact.upsert({
      where: { organizationId_phone: { organizationId, phone: msg.from } },
      create: { organizationId, phone: msg.from, waId: msg.from, name: profileName, lastContactedAt: new Date() },
      update: { waId: msg.from, lastContactedAt: new Date(), ...(profileName ? { name: profileName } : {}) },
    });

    const windowExpiresAt = new Date(Date.now() + WINDOW_MS);
    const existing = await this.prisma.conversation.findFirst({
      where: { organizationId, contactId: contact.id, whatsAppNumberId, deletedAt: null },
      orderBy: { lastMessageAt: 'desc' },
    });
    const conversation = existing
      ? await this.prisma.conversation.update({
          where: { id: existing.id },
          data: {
            status: existing.status === 'RESOLVED' ? 'OPEN' : existing.status,
            lastMessageAt: new Date(),
            unreadCount: { increment: 1 },
            windowExpiresAt,
          },
        })
      : await this.prisma.conversation.create({
          data: {
            organizationId, contactId: contact.id, whatsAppNumberId,
            status: 'OPEN', unreadCount: 1, lastMessageAt: new Date(), windowExpiresAt,
          },
        });

    const { type, body, mediaId, mediaMime } = this.extractContent(msg);

    try {
      const message = await this.prisma.message.create({
        data: {
          organizationId,
          conversationId: conversation.id,
          whatsAppNumberId,
          waMessageId: msg.id,
          direction: 'INBOUND',
          type,
          status: 'DELIVERED',
          body,
          mediaMimeType: mediaMime,
          payload: msg as unknown as Prisma.InputJsonValue,
          deliveredAt: new Date(),
        },
      });
      // Downstream consumers: inbox realtime, AI inference, flow triggers, media mirroring.
      this.events.emit('whatsapp.message.received', {
        organizationId, conversationId: conversation.id, messageId: message.id, mediaId,
      });
    } catch (err) {
      if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2002') {
        return; // duplicate inbound message (waMessageId unique) — already stored
      }
      throw err;
    }
  }

  private async handleStatus(
    organizationId: string,
    whatsAppNumberId: string,
    status: InboundStatus,
  ): Promise<void> {
    const next = this.mapStatus(status.status);
    const ts = new Date(Number(status.timestamp) * 1000);

    const message = await this.prisma.message.findUnique({ where: { waMessageId: status.id } });
    if (message) {
      // Forward-only: never downgrade (read can arrive before delivered).
      if (next === 'FAILED' || STATUS_RANK[next] > STATUS_RANK[message.status]) {
        await this.prisma.message.update({
          where: { id: message.id },
          data: {
            status: next,
            ...(next === 'SENT' ? { sentAt: ts } : {}),
            ...(next === 'DELIVERED' ? { deliveredAt: ts } : {}),
            ...(next === 'READ' ? { readAt: ts } : {}),
            ...(next === 'FAILED'
              ? { errorCode: String(status.errors?.[0]?.code ?? ''), errorMessage: status.errors?.[0]?.title }
              : {}),
          },
        });
      }
    }

    // Campaign recipients track the same lifecycle for analytics.
    await this.prisma.campaignRecipient.updateMany({
      where: { organizationId, waMessageId: status.id },
      data: {
        status: next === 'FAILED' ? 'FAILED' : (status.status.toUpperCase() as any),
        ...(next === 'SENT' ? { sentAt: ts } : {}),
        ...(next === 'DELIVERED' ? { deliveredAt: ts } : {}),
        ...(next === 'READ' ? { readAt: ts } : {}),
        ...(next === 'FAILED' ? { failedReason: status.errors?.[0]?.title } : {}),
      },
    });

    // Meta bills per delivered message — meter on the delivered transition.
    if (next === 'DELIVERED' && status.pricing?.billable !== false) {
      await this.billingQueue.add(
        JOB.METER_MESSAGE,
        {
          organizationId,
          whatsAppNumberId,
          category: status.pricing?.category ?? null,
          countryCode: null, // resolved from the recipient phone in the billing worker
          waMessageId: status.id,
        },
        // Deterministic jobId dedupes the same delivered message → metered once.
        { jobId: `meter-${status.id}`, removeOnComplete: 5000, removeOnFail: 1000 },
      );
    }

    this.events.emit('whatsapp.message.status', { organizationId, waMessageId: status.id, status: next });
  }

  private mapStatus(s: InboundStatus['status']): MessageStatus {
    return { sent: 'SENT', delivered: 'DELIVERED', read: 'READ', failed: 'FAILED' }[s] as MessageStatus;
  }

  private extractContent(msg: InboundMessage): {
    type: MessageType; body: string | null; mediaId?: string; mediaMime?: string;
  } {
    switch (msg.type) {
      case 'text': return { type: 'TEXT', body: msg.text?.body ?? null };
      case 'image': return { type: 'IMAGE', body: msg.image?.caption ?? null, mediaId: msg.image?.id, mediaMime: msg.image?.mime_type };
      case 'video': return { type: 'VIDEO', body: msg.video?.caption ?? null, mediaId: msg.video?.id, mediaMime: msg.video?.mime_type };
      case 'audio': return { type: 'AUDIO', body: null, mediaId: msg.audio?.id, mediaMime: msg.audio?.mime_type };
      case 'document': return { type: 'DOCUMENT', body: msg.document?.filename ?? msg.document?.caption ?? null, mediaId: msg.document?.id, mediaMime: msg.document?.mime_type };
      case 'sticker': return { type: 'STICKER', body: null, mediaId: msg.sticker?.id, mediaMime: msg.sticker?.mime_type };
      case 'location': return { type: 'LOCATION', body: msg.location?.name ?? `${msg.location?.latitude},${msg.location?.longitude}` };
      case 'interactive': {
        const r = msg.interactive?.button_reply ?? msg.interactive?.list_reply;
        return { type: 'INTERACTIVE', body: r ? `${r.title} (${r.id})` : null };
      }
      case 'button': return { type: 'INTERACTIVE', body: msg.button?.text ?? null };
      default: return { type: 'SYSTEM', body: null };
    }
  }
}
