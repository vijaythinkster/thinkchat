import { InjectQueue } from '@nestjs/bullmq';
import {
  Controller, ForbiddenException, Get, Headers, HttpCode, Logger, Post, Query, Req,
  UnauthorizedException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Queue } from 'bullmq';
import { createHash } from 'crypto';
import type { Request } from 'express';
import { Prisma } from '@prisma/client';
import { PrismaService } from 'src/common/prisma/prisma.service';
import { JOB, ProcessWebhookJob, QUEUE } from '../queue/queue.constants';
import { verifyMetaSignature } from './signature.util';
import { Public } from 'src/auth/decorators/public.decorator';

/**
 * Public, unauthenticated endpoint hit directly by Meta. It must:
 *   1. echo hub.challenge on GET verification,
 *   2. verify the X-Hub-Signature-256 HMAC on POST,
 *   3. dedupe + persist + return 200 in milliseconds, then enqueue.
 * No business logic runs inline — that happens in the webhook-ingest worker.
 *
 * NOTE: bootstrap must enable raw body: NestFactory.create(AppModule, { rawBody: true }).
 */
@Public()
@Controller('webhooks/whatsapp')
export class WhatsAppWebhooksController {
  private readonly logger = new Logger(WhatsAppWebhooksController.name);

  constructor(
    private readonly config: ConfigService,
    private readonly prisma: PrismaService,
    @InjectQueue(QUEUE.WEBHOOK_INGEST) private readonly queue: Queue<ProcessWebhookJob>,
  ) {}

  @Get()
  verify(
    @Query('hub.mode') mode: string,
    @Query('hub.verify_token') token: string,
    @Query('hub.challenge') challenge: string,
  ): string {
    const expected = this.config.get<string>('whatsapp.webhookVerifyToken');
    if (mode === 'subscribe' && token === expected) return challenge;
    throw new ForbiddenException('Verification failed');
  }

  @Post()
  @HttpCode(200)
  async receive(
    @Req() req: Request & { rawBody?: Buffer },
    @Headers('x-hub-signature-256') signature: string,
  ): Promise<{ status: string }> {
    const raw = req.rawBody ?? Buffer.from(JSON.stringify(req.body));
    const appSecret = this.config.get<string>('whatsapp.appSecret') ?? '';

    if (!verifyMetaSignature(raw, signature, appSecret)) {
      this.logger.warn('Rejected webhook with invalid signature');
      throw new UnauthorizedException('Invalid signature');
    }

    // Idempotency: identical redelivered bodies hash equal and are deduped.
    // Distinct events (sent -> delivered -> read) hash differently and pass.
    const externalId = createHash('sha256').update(raw).digest('hex');

    try {
      const event = await this.prisma.webhookEvent.create({
        data: {
          provider: 'WHATSAPP',
          externalId,
          payload: req.body as Prisma.InputJsonValue,
          signature,
          status: 'RECEIVED',
        },
      });
      await this.queue.add(
        JOB.PROCESS_WEBHOOK,
        { webhookEventId: event.id },
        { attempts: 8, backoff: { type: 'exponential', delay: 1000 }, removeOnComplete: 5000 },
      );
      return { status: 'queued' };
    } catch (err) {
      if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2002') {
        return { status: 'duplicate' }; // already received; still 200
      }
      throw err;
    }
  }
}
