import { registerAs } from '@nestjs/config';

/**
 * Graph API version is a pinned config constant (default v21.0, the current
 * stable version). Bump via env when validating a newer version end-to-end.
 */
export const whatsappConfig = registerAs('whatsapp', () => ({
  graphBaseUrl: process.env.WHATSAPP_GRAPH_BASE_URL ?? 'https://graph.facebook.com',
  graphVersion: process.env.WHATSAPP_GRAPH_VERSION ?? 'v21.0',
  appId: process.env.META_APP_ID ?? '',
  appSecret: process.env.META_APP_SECRET ?? '',
  webhookVerifyToken: process.env.WHATSAPP_WEBHOOK_VERIFY_TOKEN ?? '',
  // 6-digit PIN used to register the phone number for Cloud API (two-step verify).
  defaultRegisterPin: process.env.WHATSAPP_REGISTER_PIN ?? '',
  // Outbound throughput guard; Meta tiers numbers (e.g. 80 msg/s). Tune per number.
  sendRatePerSecond: Number(process.env.WHATSAPP_SEND_RATE ?? 60),
}));

export type WhatsAppConfig = ReturnType<typeof whatsappConfig>;
