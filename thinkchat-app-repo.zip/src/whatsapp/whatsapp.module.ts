import { HttpModule } from '@nestjs/axios';
import { BullModule } from '@nestjs/bullmq';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { whatsappConfig } from './whatsapp.config';
import { QUEUE } from './queue/queue.constants';

import { WhatsAppGraphClient } from './graph/whatsapp-graph.client';
import { NumbersService } from './numbers/numbers.service';
import { MediaService } from './media/media.service';
import { MessagesService } from './messages/messages.service';
import { MessagesController } from './messages/messages.controller';
import { TemplatesService } from './templates/templates.service';
import { TemplatesController } from './templates/templates.controller';
import { OnboardingService } from './onboarding/onboarding.service';
import { OnboardingController } from './onboarding/onboarding.controller';
import { WhatsAppWebhooksController } from './webhooks/webhooks.controller';
import { WebhookIngestService } from './webhooks/webhook-ingest.service';
import { MessageSendProcessor } from './queue/processors/message-send.processor';
import { WebhookIngestProcessor } from './queue/processors/webhook-ingest.processor';
import { TemplateSyncProcessor } from './queue/processors/template-sync.processor';

@Module({
  imports: [
    HttpModule.register({ timeout: 15000 }),
    ConfigModule.forFeature(whatsappConfig),
    BullModule.registerQueue(
      { name: QUEUE.MESSAGE_SEND },
      { name: QUEUE.WEBHOOK_INGEST },
      { name: QUEUE.TEMPLATE_SYNC },
      { name: QUEUE.MEDIA_DOWNLOAD },
      { name: QUEUE.BILLING_METER },
    ),
  ],
  controllers: [
    WhatsAppWebhooksController,
    MessagesController,
    TemplatesController,
    OnboardingController,
  ],
  providers: [
    WhatsAppGraphClient,
    NumbersService,
    MediaService,
    MessagesService,
    TemplatesService,
    OnboardingService,
    WebhookIngestService,
    MessageSendProcessor,
    WebhookIngestProcessor,
    TemplateSyncProcessor,
  ],
  exports: [WhatsAppGraphClient, NumbersService, MessagesService],
})
export class WhatsAppModule {}
