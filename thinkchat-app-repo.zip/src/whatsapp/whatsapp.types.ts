// ---- Outbound (Graph API send) payloads ----
export interface GraphTextMessage {
  messaging_product: 'whatsapp';
  recipient_type?: 'individual';
  to: string;
  type: 'text';
  text: { body: string; preview_url?: boolean };
}
export interface GraphMediaMessage {
  messaging_product: 'whatsapp';
  to: string;
  type: 'image' | 'video' | 'audio' | 'document' | 'sticker';
  [key: string]: any; // e.g. image: { id | link, caption }
}
export interface GraphTemplateMessage {
  messaging_product: 'whatsapp';
  to: string;
  type: 'template';
  template: {
    name: string;
    language: { code: string };
    components?: any[];
  };
}
export type GraphOutboundPayload =
  | GraphTextMessage
  | GraphMediaMessage
  | GraphTemplateMessage
  | Record<string, any>;

export interface GraphSendResponse {
  messaging_product: 'whatsapp';
  contacts: Array<{ input: string; wa_id: string }>;
  messages: Array<{ id: string; message_status?: string }>;
}

// ---- Inbound webhook payloads ----
export interface WebhookEnvelope {
  object: string;
  entry: WebhookEntry[];
}
export interface WebhookEntry {
  id: string; // WABA id
  changes: WebhookChange[];
}
export interface WebhookChange {
  field: string; // 'messages'
  value: WebhookValue;
}
export interface WebhookValue {
  messaging_product: 'whatsapp';
  metadata: { display_phone_number: string; phone_number_id: string };
  contacts?: Array<{ profile: { name: string }; wa_id: string }>;
  messages?: InboundMessage[];
  statuses?: InboundStatus[];
}
export interface InboundMessage {
  id: string;
  from: string;
  timestamp: string;
  type: string;
  text?: { body: string };
  image?: InboundMedia;
  video?: InboundMedia;
  audio?: InboundMedia;
  document?: InboundMedia & { filename?: string };
  sticker?: InboundMedia;
  location?: { latitude: number; longitude: number; name?: string; address?: string };
  interactive?: { type: string; button_reply?: { id: string; title: string }; list_reply?: { id: string; title: string } };
  button?: { text: string; payload: string };
  context?: { from: string; id: string };
}
export interface InboundMedia { id: string; mime_type: string; sha256?: string; caption?: string }
export interface InboundStatus {
  id: string;
  status: 'sent' | 'delivered' | 'read' | 'failed';
  timestamp: string;
  recipient_id: string;
  conversation?: { id: string; origin?: { type: string } };
  pricing?: { category: string; pricing_model: string; billable?: boolean };
  errors?: Array<{ code: number; title: string; message?: string }>;
}
