import { NestFactory } from '@nestjs/core';
import { Logger } from '@nestjs/common';
import { AppModule } from './app.module';

/**
 * Worker entrypoint for the ECS "worker" service. Boots the Nest DI container so
 * the BullMQ processors register and start consuming queues, but does NOT start an
 * HTTP server. Deploy as the worker container command: ["node","dist/worker.js"].
 *
 * NOTE: the API (main.ts) currently also instantiates these processors. To run
 * workers ONLY here, gate processor providers behind an env flag (e.g. ROLE=worker)
 * in each module — a small change flagged in the README.
 */
async function bootstrap() {
  const app = await NestFactory.createApplicationContext(AppModule, { bufferLogs: false });
  app.enableShutdownHooks();
  new Logger('Worker').log('Worker context started — consuming queues');
}
bootstrap().catch((err) => {
  // eslint-disable-next-line no-console
  console.error('Worker failed to start', err);
  process.exit(1);
});
