# Inbox frontend — setup

Next.js 15 (App Router) + TypeScript + Tailwind + shadcn/ui.

## Install
```
pnpm add socket.io-client clsx tailwind-merge lucide-react
npx shadcn@latest init
npx shadcn@latest add button badge avatar scroll-area separator
```

## Env (.env.local)
```
NEXT_PUBLIC_API_URL=http://localhost:4000      # REST base
NEXT_PUBLIC_WS_URL=http://localhost:4000        # Socket.IO base
API_URL=http://localhost:4000                   # server-component fetch
```

## tsconfig paths
The imports use the `@/*` alias:
```
{ "compilerOptions": { "paths": { "@/*": ["./src/*"] } } }
```

## Notes
- Auth token: `lib/auth.ts` reads `access_token` for the socket handshake; wire
  this to your real auth provider (httpOnly cookie + a client-readable mirror,
  or a short-lived token endpoint).
- The socket connects to the `/inbox` namespace and authenticates with the JWT;
  the server places the client in the `org:<id>` room (tenant isolation).
- Sends are optimistic (QUEUED bubble) and reconcile when the backend returns
  the persisted row; the worker's SENT/DELIVERED/READ updates arrive over the
  socket as `message:status`.
