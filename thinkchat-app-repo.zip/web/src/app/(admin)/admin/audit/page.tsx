import { AuditLogViewer } from '@/features/admin/audit-log-viewer';
export default function Page() { return <AuditLogViewer />; }
