import { CouponsManager } from '@/features/admin/coupons-manager';
export default function Page() { return <CouponsManager />; }
