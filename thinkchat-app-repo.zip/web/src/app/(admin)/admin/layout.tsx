'use client';

import { RequireSuperAdmin } from '@/features/admin/require-super-admin';
import { AdminShell } from '@/features/admin/admin-shell';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <RequireSuperAdmin>
      <AdminShell>{children}</AdminShell>
    </RequireSuperAdmin>
  );
}
