import { OrganizationDetail } from '@/features/admin/organization-detail';

export default function Page({ params }: { params: { id: string } }) {
  return <OrganizationDetail orgId={params.id} />;
}
