import { OrganizationsTable } from '@/features/admin/organizations-table';
export default function Page() { return <OrganizationsTable />; }
