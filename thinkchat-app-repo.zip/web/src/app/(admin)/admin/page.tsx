import { OverviewDashboard } from '@/features/admin/overview-dashboard';
export default function Page() { return <OverviewDashboard />; }
