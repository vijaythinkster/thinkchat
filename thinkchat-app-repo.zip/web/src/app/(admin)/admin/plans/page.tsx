import { PlansManager } from '@/features/admin/plans-manager';
export default function Page() { return <PlansManager />; }
