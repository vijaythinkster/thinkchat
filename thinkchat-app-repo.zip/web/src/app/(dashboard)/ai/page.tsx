'use client';

import { useEffect, useState } from 'react';
import { Bot, Plus } from 'lucide-react';
import type { Assistant } from '@/types/ai';
import { aiApi } from '@/lib/ai-api';
import { AssistantSettings } from '@/features/ai/assistant-settings';
import { KnowledgeManager } from '@/features/ai/knowledge-manager';
import { Playground } from '@/features/ai/playground';

type Tab = 'settings' | 'knowledge' | 'test';

export default function AiPage() {
  const [assistants, setAssistants] = useState<Assistant[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>('settings');
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  const load = () => {
    setLoading(true);
    aiApi
      .list()
      .then((list) => {
        setAssistants(list);
        setSelectedId((cur) => cur ?? list[0]?.id ?? null);
      })
      .catch((e) => setErr(e?.message ?? 'Failed to load assistants'))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const createAssistant = async () => {
    const name = window.prompt('Name your AI assistant');
    if (!name) return;
    try {
      const created = await aiApi.create({
        name,
        type: 'SUPPORT',
        provider: 'OPENAI',
        model: 'gpt-4o-mini',
        systemPrompt: 'You are a helpful assistant for our business. Answer customer questions clearly and politely.',
        temperature: 0.7,
      });
      setAssistants((prev) => [created, ...prev]);
      setSelectedId(created.id);
      setTab('settings');
    } catch (e) {
      setErr((e as Error)?.message ?? 'Could not create assistant');
    }
  };

  return (
    <div className="flex h-full">
      <aside className="flex w-64 flex-shrink-0 flex-col border-r">
        <div className="flex items-center justify-between p-4">
          <h1 className="text-lg font-medium">AI assistants</h1>
          <button
            onClick={createAssistant}
            title="New assistant"
            className="flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:bg-muted hover:text-foreground"
          >
            <Plus className="h-5 w-5" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-2">
          {loading && <p className="px-2 text-sm text-muted-foreground">Loading…</p>}
          {!loading && assistants.length === 0 && (
            <p className="px-2 text-sm text-muted-foreground">
              No assistants yet. Click + to create your first one.
            </p>
          )}
          {assistants.map((a) => (
            <button
              key={a.id}
              onClick={() => setSelectedId(a.id)}
              className={
                'flex w-full items-center gap-2 rounded-md px-3 py-2 text-left text-sm ' +
                (a.id === selectedId ? 'bg-muted font-medium' : 'hover:bg-muted/60')
              }
            >
              <Bot className="h-4 w-4 text-muted-foreground" />
              <span className="truncate">{a.name}</span>
            </button>
          ))}
        </div>
      </aside>

      <section className="min-w-0 flex-1 overflow-y-auto">
        {err && <p className="p-6 text-sm text-rose-600">{err}</p>}
        {!selectedId ? (
          <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
            Select or create an assistant
          </div>
        ) : (
          <div className="p-6">
            <div className="mb-4 flex gap-2 border-b">
              {(['settings', 'knowledge', 'test'] as Tab[]).map((t) => (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  className={
                    'px-3 py-2 text-sm capitalize ' +
                    (tab === t
                      ? 'border-b-2 border-sky-600 font-medium text-sky-700'
                      : 'text-muted-foreground hover:text-foreground')
                  }
                >
                  {t}
                </button>
              ))}
            </div>
            {tab === 'settings' && <AssistantSettings assistantId={selectedId} />}
            {tab === 'knowledge' && <KnowledgeManager assistantId={selectedId} />}
            {tab === 'test' && <Playground assistantId={selectedId} />}
          </div>
        )}
      </section>
    </div>
  );
}
