import { UsageDashboard } from '@/features/billing/usage-dashboard';
import { InvoicesList } from '@/features/billing/invoices-list';

export default function BillingPage() {
  return (
    <div className="h-full overflow-y-auto p-6 space-y-8">
      <section>
        <h1 className="mb-4 text-lg font-medium">Usage &amp; billing</h1>
        <UsageDashboard currency="INR" />
      </section>
      <section>
        <h2 className="mb-4 text-base font-medium">Invoices</h2>
        <InvoicesList />
      </section>
    </div>
  );
}
