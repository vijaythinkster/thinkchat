import { CampaignList } from '@/features/campaigns/campaign-list';

export default function CampaignsPage() {
  return (
    <div className="h-full overflow-y-auto p-6">
      <h1 className="mb-4 text-lg font-medium">Campaigns</h1>
      <CampaignList />
    </div>
  );
}
