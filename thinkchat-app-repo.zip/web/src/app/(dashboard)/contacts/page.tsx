import { ContactsTable } from '@/features/crm/contacts-table';

export default function ContactsPage() {
  return (
    <div className="h-full overflow-y-auto p-6">
      <h1 className="mb-4 text-lg font-medium">Contacts</h1>
      <ContactsTable />
    </div>
  );
}
