'use client';

import { useEffect, useState } from 'react';
import { MessageSquare, Send, IndianRupee, TrendingUp, Crown } from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';
import { billingApi } from '@/lib/billing-api';
import type { PeriodUsage, Subscription } from '@/types/billing';

function inr(n: number) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n || 0);
}

function StatCard({
  label, value, sub, Icon,
}: { label: string; value: string; sub?: string; Icon: typeof Send }) {
  return (
    <div className="rounded-2xl border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between">
        <span className="text-sm text-muted-foreground">{label}</span>
        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <Icon className="h-[18px] w-[18px]" />
        </span>
      </div>
      <p className="mt-3 text-3xl font-semibold tracking-tight">{value}</p>
      {sub && <p className="mt-1 text-xs text-muted-foreground">{sub}</p>}
    </div>
  );
}

export default function DashboardPage() {
  const { user } = useAuth();
  const [usage, setUsage] = useState<PeriodUsage | null>(null);
  const [sub, setSub] = useState<Subscription | null>(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    Promise.allSettled([billingApi.usage(), billingApi.subscription()]).then(([u, s]) => {
      if (u.status === 'fulfilled') setUsage(u.value);
      if (s.status === 'fulfilled') setSub(s.value);
      setLoaded(true);
    });
  }, []);

  const t = usage?.totals;
  const hasData = !!t && t.messages > 0;
  const maxCat = Math.max(1, ...(usage?.byCategory ?? []).map((c) => c.messages));

  return (
    <div className="h-full overflow-y-auto">
      {/* Header */}
      <header className="flex flex-wrap items-center justify-between gap-3 px-8 py-6">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">
            Welcome back, {user?.firstName || 'there'} 👋
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">Here's how your WhatsApp activity is doing.</p>
        </div>
        <span className="rounded-full bg-primary/10 px-3 py-1.5 text-xs font-medium text-primary">
          {usage ? `Billing period · ${new Date(usage.periodStart).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}–${new Date(usage.periodEnd).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}` : 'Current period'}
        </span>
      </header>

      <div className="space-y-6 px-8 pb-10">
        {/* Stat cards */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Messages" value={(t?.messages ?? 0).toLocaleString('en-IN')} sub="delivered + billable" Icon={MessageSquare} />
          <StatCard label="Meta cost" value={inr(t?.metaCost ?? 0)} sub="what Meta charges you" Icon={IndianRupee} />
          <StatCard label="You bill" value={inr(t?.billedCost ?? 0)} sub="customer total" Icon={Send} />
          <StatCard label="Margin" value={inr(t?.margin ?? 0)} sub="billed − Meta cost" Icon={TrendingUp} />
        </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          {/* Analytics */}
          <div className="rounded-2xl border bg-card p-6 shadow-sm lg:col-span-2">
            <div className="mb-5 flex items-center justify-between">
              <h2 className="text-base font-semibold">Message analytics</h2>
              <span className="text-xs text-muted-foreground">by category</span>
            </div>
            {!loaded ? (
              <p className="py-12 text-center text-sm text-muted-foreground">Loading…</p>
            ) : !hasData ? (
              <div className="flex flex-col items-center justify-center gap-2 py-14 text-center">
                <MessageSquare className="h-8 w-8 text-muted-foreground/50" />
                <p className="text-sm font-medium">No messages yet</p>
                <p className="max-w-sm text-xs text-muted-foreground">
                  Connect a WhatsApp number and run your first campaign — your analytics will appear here.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {usage!.byCategory.map((c) => (
                  <div key={c.category}>
                    <div className="mb-1 flex justify-between text-xs">
                      <span className="capitalize text-muted-foreground">{c.category.toLowerCase()}</span>
                      <span className="font-medium">{c.messages.toLocaleString('en-IN')}</span>
                    </div>
                    <div className="h-2.5 overflow-hidden rounded-full bg-muted">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-brand-emerald to-brand-lime"
                        style={{ width: `${(c.messages / maxCat) * 100}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Plan */}
          <div className="rounded-2xl border bg-card p-6 shadow-sm">
            <div className="mb-4 flex items-center gap-2">
              <Crown className="h-[18px] w-[18px] text-primary" />
              <h2 className="text-base font-semibold">Your plan</h2>
            </div>
            {!loaded ? (
              <p className="text-sm text-muted-foreground">Loading…</p>
            ) : sub ? (
              <div className="space-y-3">
                <div>
                  <p className="text-2xl font-semibold">{sub.plan?.name ?? 'Active plan'}</p>
                  <p className="mt-1 text-xs text-muted-foreground capitalize">
                    {sub.plan?.tier ? `${sub.plan.tier} · ` : ''}status: {sub.status ?? 'active'}
                  </p>
                </div>
                <a href="/billing" className="inline-block w-full rounded-xl bg-primary px-4 py-2.5 text-center text-sm font-medium text-primary-foreground hover:opacity-90">
                  View billing details
                </a>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">You're not on a paid plan yet.</p>
                <a href="/billing" className="inline-block w-full rounded-xl bg-primary px-4 py-2.5 text-center text-sm font-medium text-primary-foreground hover:opacity-90">
                  Explore plans
                </a>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
