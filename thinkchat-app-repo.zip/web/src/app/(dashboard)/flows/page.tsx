import { FlowList } from '@/features/flows/flow-list';

export default function FlowsPage() {
  return (
    <div className="h-full overflow-y-auto p-6">
      <h1 className="mb-4 text-lg font-medium">Automation flows</h1>
      <FlowList />
    </div>
  );
}
