import { cookies } from 'next/headers';
import { InboxShell } from '@/features/inbox/inbox-shell';
import type { Conversation, ListResponse } from '@/types/inbox';

/**
 * Server component: fetch the first page of open conversations with the user's
 * cookie for fast first paint, then hand off to the client shell which opens the
 * WebSocket and takes over live updates.
 */
async function getInitial(): Promise<Conversation[]> {
  try {
    const token = (await cookies()).get('access_token')?.value ?? '';
    const res = await fetch(`${process.env.API_URL ?? 'http://localhost:4000'}/conversations?status=OPEN`, {
      headers: { Authorization: `Bearer ${token}` },
      cache: 'no-store',
    });
    if (!res.ok) return [];
    return ((await res.json()) as ListResponse).items;
  } catch {
    return [];
  }
}

export default async function InboxPage() {
  const initial = await getInitial();
  return <InboxShell initial={initial} />;
}
