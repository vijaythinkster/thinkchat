'use client';

import { useAuth } from '@/hooks/use-auth';
import { RequireAuth } from '@/features/auth/require-auth';
import { IntegrationsGrid } from '@/features/integrations/integrations-grid';

export default function IntegrationsPage() {
  return (
    <RequireAuth>
      <Inner />
    </RequireAuth>
  );
}

function Inner() {
  const { user, can } = useAuth();
  if (!user) return null;
  if (!can('integrations.manage')) {
    return <div className="p-6 text-sm text-gray-500">You don’t have access to integrations.</div>;
  }
  return (
    <div className="mx-auto max-w-5xl p-6">
      <h1 className="text-xl font-semibold text-gray-900">Integrations</h1>
      <p className="mt-1 text-sm text-gray-500">
        Connect lead sources, e-commerce stores, CRMs, and automation tools.
      </p>
      <div className="mt-6">
        <IntegrationsGrid organizationId={user.organizationId} />
      </div>
    </div>
  );
}
