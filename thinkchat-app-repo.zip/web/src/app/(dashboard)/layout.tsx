'use client';

import { RequireAuth } from '@/features/auth/require-auth';
import { AppSidebar } from '@/components/app-sidebar';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <RequireAuth>
      <div className="flex h-screen overflow-hidden bg-background">
        <AppSidebar />
        <div className="min-w-0 flex-1 overflow-hidden">{children}</div>
      </div>
    </RequireAuth>
  );
}
