import { PipelineBoard } from '@/features/crm/pipeline-board';

export default function PipelinePage() {
  return (
    <div className="h-full overflow-y-auto p-6">
      <h1 className="mb-4 text-lg font-medium">Sales pipeline</h1>
      <PipelineBoard />
    </div>
  );
}
