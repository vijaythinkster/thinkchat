'use client';

import { useAuth } from '@/hooks/use-auth';

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between border-b py-3 text-sm">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}

export default function SettingsPage() {
  const { user, permissions, logout } = useAuth();

  return (
    <div className="h-full overflow-y-auto p-6">
      <h1 className="mb-4 text-lg font-medium">Settings</h1>

      <div className="max-w-xl rounded-lg border p-5">
        <h2 className="mb-2 text-base font-medium">Account</h2>
        <Row label="Name" value={[user?.firstName, user?.lastName].filter(Boolean).join(' ') || '—'} />
        <Row label="Email" value={user?.email ?? '—'} />
        <Row label="Organization" value={user?.organizationId ?? '—'} />
        <Row label="Permissions" value={String(permissions.length)} />

        <button
          onClick={() => logout()}
          className="mt-5 rounded-md bg-rose-600 px-4 py-2 text-sm font-medium text-white hover:bg-rose-700"
        >
          Log out
        </button>
      </div>

      <p className="mt-4 max-w-xl text-xs text-muted-foreground">
        More settings (team members, roles, WhatsApp numbers, billing plan) will appear here as those areas are wired up.
      </p>
    </div>
  );
}
