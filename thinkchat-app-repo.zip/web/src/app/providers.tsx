'use client';

import { AuthProvider } from '@/hooks/use-auth';

/**
 * Wrap the app with this in the root layout:
 *   import { Providers } from './providers';
 *   <body><Providers>{children}</Providers></body>
 * Then wrap the (dashboard) layout's children with <RequireAuth> to gate routes.
 */
export function Providers({ children }: { children: React.ReactNode }) {
  return <AuthProvider>{children}</AuthProvider>;
}
