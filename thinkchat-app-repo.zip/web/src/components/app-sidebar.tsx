'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  LayoutDashboard, Inbox, Users, Megaphone, Workflow, Briefcase, Bot, Plug,
  CreditCard, Settings, Shield, LogOut,
} from 'lucide-react';
import { useAuth } from '@/hooks/use-auth';

const MAIN = [
  { href: '/dashboard', label: 'Dashboard', Icon: LayoutDashboard },
  { href: '/inbox', label: 'Inbox', Icon: Inbox },
  { href: '/contacts', label: 'Contacts', Icon: Users },
  { href: '/campaigns', label: 'Campaigns', Icon: Megaphone },
  { href: '/flows', label: 'Flows', Icon: Workflow },
  { href: '/pipeline', label: 'Pipeline', Icon: Briefcase },
  { href: '/ai', label: 'AI assistant', Icon: Bot },
  { href: '/integrations', label: 'Integrations', Icon: Plug },
  { href: '/billing', label: 'Billing', Icon: CreditCard },
];

const BOTTOM = [
  { href: '/settings', label: 'Settings', Icon: Settings },
  { href: '/admin', label: 'Admin', Icon: Shield },
];

function Item({ href, label, Icon, active }: { href: string; label: string; Icon: typeof Inbox; active: boolean }) {
  return (
    <Link
      href={href}
      aria-current={active ? 'page' : undefined}
      className={
        'flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors ' +
        (active
          ? 'bg-gradient-to-r from-brand-emerald to-brand-lime text-white shadow-sm'
          : 'text-sidebar-foreground hover:bg-white/5 hover:text-white')
      }
    >
      <Icon className="h-[18px] w-[18px] flex-shrink-0" />
      <span className="truncate">{label}</span>
    </Link>
  );
}

export function AppSidebar() {
  const pathname = usePathname() || '';
  const { user, logout } = useAuth();
  const isActive = (href: string) => pathname === href || pathname.startsWith(href + '/');
  const initials = ((user?.firstName?.[0] ?? '') + (user?.lastName?.[0] ?? '')).toUpperCase()
    || (user?.email?.[0] ?? 'U').toUpperCase();

  return (
    <aside className="flex h-full w-64 flex-shrink-0 flex-col bg-sidebar text-sidebar-foreground">
      {/* Brand */}
      <div className="px-5 py-5">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/logo.svg" alt="ThinkChat" className="h-8 w-auto" />
      </div>

      {/* Nav */}
      <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-2">
        {MAIN.map((item) => (
          <Item key={item.href} {...item} active={isActive(item.href)} />
        ))}
        <div className="my-3 border-t border-white/10" />
        {BOTTOM.map((item) => (
          <Item key={item.href} {...item} active={isActive(item.href)} />
        ))}
      </nav>

      {/* User */}
      <div className="border-t border-white/10 p-3">
        <div className="flex items-center gap-3 rounded-xl bg-white/5 px-3 py-2.5">
          <span className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-brand-emerald to-brand-lime text-sm font-semibold text-white">
            {initials}
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium text-white">
              {[user?.firstName, user?.lastName].filter(Boolean).join(' ') || 'My account'}
            </p>
            <p className="truncate text-xs text-sidebar-muted">{user?.email}</p>
          </div>
          <button onClick={() => logout()} title="Log out" className="text-sidebar-muted hover:text-white">
            <LogOut className="h-[18px] w-[18px]" />
          </button>
        </div>
      </div>
    </aside>
  );
}
