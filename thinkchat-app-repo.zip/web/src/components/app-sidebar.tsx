'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Inbox, Users, Megaphone, Workflow, Briefcase, Bot, Plug, CreditCard, Settings, Shield,
} from 'lucide-react';

const MAIN = [
  { href: '/inbox', label: 'Inbox', Icon: Inbox },
  { href: '/contacts', label: 'Contacts', Icon: Users },
  { href: '/campaigns', label: 'Campaigns', Icon: Megaphone },
  { href: '/flows', label: 'Flows', Icon: Workflow },
  { href: '/pipeline', label: 'Pipeline', Icon: Briefcase },
  { href: '/ai', label: 'AI assistants', Icon: Bot },
  { href: '/integrations', label: 'Integrations', Icon: Plug },
  { href: '/billing', label: 'Billing', Icon: CreditCard },
];

const BOTTOM = [
  { href: '/settings', label: 'Settings', Icon: Settings },
  { href: '/admin', label: 'Admin', Icon: Shield },
];

function NavLink({ href, label, Icon, active }: { href: string; label: string; Icon: typeof Inbox; active: boolean }) {
  return (
    <Link
      href={href}
      title={label}
      aria-label={label}
      aria-current={active ? 'page' : undefined}
      className={
        'flex h-9 w-9 items-center justify-center rounded-md transition-colors ' +
        (active
          ? 'bg-sky-100 text-sky-700 dark:bg-sky-950 dark:text-sky-200'
          : 'text-muted-foreground hover:bg-muted hover:text-foreground')
      }
    >
      <Icon className="h-5 w-5" />
    </Link>
  );
}

export function AppSidebar() {
  const pathname = usePathname() || '';
  const isActive = (href: string) => pathname === href || pathname.startsWith(href + '/');

  return (
    <nav className="flex h-full w-[56px] flex-shrink-0 flex-col items-center gap-1.5 border-r bg-muted/40 py-3">
      {MAIN.map((item) => (
        <NavLink key={item.href} {...item} active={isActive(item.href)} />
      ))}
      <div className="mt-auto flex flex-col items-center gap-1.5">
        {BOTTOM.map((item) => (
          <NavLink key={item.href} {...item} active={isActive(item.href)} />
        ))}
      </div>
    </nav>
  );
}
