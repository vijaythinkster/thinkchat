import * as React from 'react';
import { cn } from '@/lib/utils';

type Variant = 'default' | 'secondary' | 'outline';
type Tone = 'green' | 'amber' | 'red' | 'gray';

const variants: Record<Variant, string> = {
  default: 'bg-gray-900 text-white',
  secondary: 'bg-gray-100 text-gray-700',
  outline: 'border border-gray-300 text-gray-700',
};
const tones: Record<Tone, string> = {
  green: 'bg-green-100 text-green-700',
  amber: 'bg-amber-100 text-amber-700',
  red: 'bg-red-100 text-red-700',
  gray: 'bg-gray-100 text-gray-600',
};

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: Variant;
  tone?: Tone;
}

export function Badge({ className, variant = 'secondary', tone, ...props }: BadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium',
        tone ? tones[tone] : variants[variant],
        className,
      )}
      {...props}
    />
  );
}
