'use client';

import { useEffect, useState } from 'react';
import { adminApi } from '@/lib/admin-api';
import type { AuditRow } from '@/types/admin';

export function AuditLogViewer() {
  const [rows, setRows] = useState<AuditRow[]>([]);
  const [action, setAction] = useState('');

  useEffect(() => {
    const t = setTimeout(() => { adminApi.auditLogs({ action }).then((r) => setRows(r.items)); }, 250);
    return () => clearTimeout(t);
  }, [action]);

  return (
    <div>
      <h1 className="mb-4 text-xl font-semibold text-neutral-900">Audit log</h1>
      <input value={action} onChange={(e) => setAction(e.target.value)} placeholder="Filter by action (e.g. platform.org.suspend)"
        className="mb-4 w-80 rounded-md border border-neutral-300 px-3 py-2 text-sm" />
      <div className="overflow-hidden rounded-xl border border-neutral-200 bg-white">
        <table className="w-full text-sm">
          <thead className="bg-neutral-50 text-left text-xs uppercase tracking-wide text-neutral-500">
            <tr><th className="px-4 py-3">When</th><th className="px-4 py-3">Action</th><th className="px-4 py-3">Actor</th><th className="px-4 py-3">Org</th><th className="px-4 py-3">Entity</th></tr>
          </thead>
          <tbody className="divide-y divide-neutral-100">
            {rows.map((r) => (
              <tr key={r.id} className="hover:bg-neutral-50">
                <td className="px-4 py-3 text-neutral-500">{new Date(r.createdAt).toLocaleString()}</td>
                <td className="px-4 py-3 font-medium">{r.action}</td>
                <td className="px-4 py-3">{r.user?.email ?? '—'}</td>
                <td className="px-4 py-3">{r.organization?.name ?? '—'}</td>
                <td className="px-4 py-3 text-neutral-500">{r.entityType ? `${r.entityType}:${r.entityId ?? ''}` : '—'}</td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={5} className="px-4 py-8 text-center text-neutral-400">No entries.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
