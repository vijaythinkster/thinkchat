'use client';

import { useEffect, useState } from 'react';
import { adminApi } from '@/lib/admin-api';
import type { CouponRow } from '@/types/admin';

export function CouponsManager() {
  const [coupons, setCoupons] = useState<CouponRow[]>([]);
  const [form, setForm] = useState({ code: '', percentOff: '' });

  const load = () => adminApi.listCoupons().then(setCoupons);
  useEffect(() => { load(); }, []);

  const create = async () => {
    if (!form.code) return;
    await adminApi.createCoupon({ code: form.code, percentOff: form.percentOff ? Number(form.percentOff) : undefined });
    setForm({ code: '', percentOff: '' });
    load();
  };
  const toggle = async (c: CouponRow) => { await adminApi.updateCoupon(c.id, { isActive: !c.isActive }); load(); };

  return (
    <div>
      <h1 className="mb-4 text-xl font-semibold text-neutral-900">Coupons</h1>
      <div className="mb-4 flex gap-3 rounded-xl border border-neutral-200 bg-white p-4">
        <input placeholder="CODE" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value.toUpperCase() })} className="rounded-md border border-neutral-300 px-3 py-2 text-sm" />
        <input placeholder="% off" value={form.percentOff} onChange={(e) => setForm({ ...form, percentOff: e.target.value })} className="w-24 rounded-md border border-neutral-300 px-3 py-2 text-sm" />
        <button onClick={create} className="rounded-md bg-neutral-900 px-3 py-2 text-sm text-white">Add coupon</button>
      </div>
      <div className="overflow-hidden rounded-xl border border-neutral-200 bg-white">
        <table className="w-full text-sm">
          <thead className="bg-neutral-50 text-left text-xs uppercase tracking-wide text-neutral-500">
            <tr><th className="px-4 py-3">Code</th><th className="px-4 py-3">Discount</th><th className="px-4 py-3">Redeemed</th><th className="px-4 py-3">Active</th><th className="px-4 py-3 text-right">Actions</th></tr>
          </thead>
          <tbody className="divide-y divide-neutral-100">
            {coupons.map((c) => (
              <tr key={c.id} className="hover:bg-neutral-50">
                <td className="px-4 py-3 font-medium">{c.code}</td>
                <td className="px-4 py-3">{c.percentOff ? `${c.percentOff}%` : c.amountOff ? `${c.currency} ${c.amountOff}` : '—'}</td>
                <td className="px-4 py-3">{c.redeemedCount}{c.maxRedemptions ? ` / ${c.maxRedemptions}` : ''}</td>
                <td className="px-4 py-3">{c.isActive ? 'Yes' : 'No'}</td>
                <td className="px-4 py-3 text-right">
                  <button onClick={() => toggle(c)} className="rounded-md border border-neutral-300 px-2.5 py-1 text-xs hover:bg-neutral-100">{c.isActive ? 'Disable' : 'Enable'}</button>
                </td>
              </tr>
            ))}
            {coupons.length === 0 && <tr><td colSpan={5} className="px-4 py-8 text-center text-neutral-400">No coupons.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
