'use client';

import { useEffect, useState } from 'react';
import { adminApi } from '@/lib/admin-api';
import type { AdminUser, OrgDetail } from '@/types/admin';

const money = (n: number, c = 'INR') =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: c, maximumFractionDigits: 0 }).format(n);

export function OrganizationDetail({ orgId }: { orgId: string }) {
  const [data, setData] = useState<OrgDetail | null>(null);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [msg, setMsg] = useState<string | null>(null);

  const load = () => {
    adminApi.getOrg(orgId).then(setData).catch((e) => setMsg(String(e)));
    adminApi.listUsers({ organizationId: orgId }).then((r) => setUsers(r.items));
  };
  useEffect(load, [orgId]);

  const impersonate = async (u: AdminUser) => {
    if (!window.confirm(`Issue a 30-minute impersonation token for ${u.email}?`)) return;
    const r = await adminApi.impersonate(orgId, u.id);
    try { await navigator.clipboard.writeText(r.accessToken); } catch { /* clipboard may be blocked */ }
    setMsg(`Impersonation token for ${u.email} copied (valid ${Math.round(r.expiresIn / 60)} min). Use as a Bearer token.`);
  };
  const toggleActive = async (u: AdminUser) => {
    await adminApi.setUserActive(u.id, !u.isActive);
    load();
  };

  if (msg && !data) return <div className="text-sm text-red-600">{msg}</div>;
  if (!data) return <div className="text-sm text-neutral-500">Loading…</div>;
  const o = data.organization;
  const u = data.usageThisMonth;

  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center gap-3">
          <h1 className="text-xl font-semibold text-neutral-900">{o.name}</h1>
          {o.suspendedAt && <span className="rounded-full bg-amber-50 px-2 py-0.5 text-xs font-medium text-amber-700 ring-1 ring-inset ring-amber-200">Suspended</span>}
        </div>
        <div className="text-sm text-neutral-500">/{o.slug} · created {new Date(o.createdAt).toLocaleDateString()}</div>
        {o.suspendedReason && <div className="mt-1 text-sm text-amber-700">Reason: {o.suspendedReason}</div>}
      </div>

      {msg && <div className="rounded-md bg-neutral-900 px-3 py-2 text-xs text-white">{msg}</div>}

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {Object.entries(data.counts).map(([k, v]) => (
          <div key={k} className="rounded-xl border border-neutral-200 bg-white p-4">
            <div className="text-xs uppercase tracking-wide text-neutral-500">{k}</div>
            <div className="mt-1 text-xl font-semibold">{v}</div>
          </div>
        ))}
      </div>

      <div className="rounded-xl border border-neutral-200 bg-white p-5">
        <div className="mb-2 text-sm font-semibold">Messaging this month</div>
        <div className="flex gap-8 text-sm">
          <div><span className="text-neutral-500">Meta cost</span><div className="font-medium">{money(u.metaCost)}</div></div>
          <div><span className="text-neutral-500">Billed</span><div className="font-medium">{money(u.billed)}</div></div>
          <div><span className="text-neutral-500">Margin</span><div className="font-medium">{money(u.margin)}</div></div>
          <div><span className="text-neutral-500">Messages</span><div className="font-medium">{u.messages}</div></div>
        </div>
      </div>

      <div className="rounded-xl border border-neutral-200 bg-white">
        <div className="border-b border-neutral-100 px-5 py-3 text-sm font-semibold">Users</div>
        <table className="w-full text-sm">
          <tbody className="divide-y divide-neutral-100">
            {users.map((usr) => (
              <tr key={usr.id} className="hover:bg-neutral-50">
                <td className="px-5 py-3">
                  <div className="font-medium">{usr.email}</div>
                  <div className="text-xs text-neutral-500">{[usr.firstName, usr.lastName].filter(Boolean).join(' ')}{usr.isSuperAdmin ? ' · super-admin' : ''}</div>
                </td>
                <td className="px-5 py-3">{usr.isActive ? <span className="text-green-700">Active</span> : <span className="text-neutral-400">Disabled</span>}</td>
                <td className="px-5 py-3 text-right">
                  <button onClick={() => impersonate(usr)} className="mr-2 rounded-md border border-neutral-300 px-2.5 py-1 text-xs hover:bg-neutral-100">Impersonate</button>
                  <button onClick={() => toggleActive(usr)} className="rounded-md border border-neutral-300 px-2.5 py-1 text-xs hover:bg-neutral-100">{usr.isActive ? 'Disable' : 'Enable'}</button>
                </td>
              </tr>
            ))}
            {users.length === 0 && <tr><td className="px-5 py-6 text-center text-neutral-400">No users.</td></tr>}
          </tbody>
        </table>
      </div>

      <div className="rounded-xl border border-neutral-200 bg-white">
        <div className="border-b border-neutral-100 px-5 py-3 text-sm font-semibold">Recent invoices</div>
        <table className="w-full text-sm">
          <tbody className="divide-y divide-neutral-100">
            {data.recentInvoices.map((inv) => (
              <tr key={inv.id}>
                <td className="px-5 py-3 font-medium">{inv.number}</td>
                <td className="px-5 py-3">{inv.status}</td>
                <td className="px-5 py-3 text-right">{money(Number(inv.total), inv.currency)}</td>
              </tr>
            ))}
            {data.recentInvoices.length === 0 && <tr><td className="px-5 py-6 text-center text-neutral-400">No invoices.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
