'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { adminApi } from '@/lib/admin-api';
import type { OrgListItem } from '@/types/admin';

const STATUSES = ['active', 'suspended', 'deleted'] as const;

export function OrganizationsTable() {
  const [items, setItems] = useState<OrgListItem[]>([]);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState<string>('active');
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);

  const load = () => {
    setLoading(true);
    adminApi.listOrgs({ search, status }).then((r) => setItems(r.items)).finally(() => setLoading(false));
  };

  useEffect(() => {
    const t = setTimeout(load, 250);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, status]);

  const suspend = async (o: OrgListItem) => {
    const reason = window.prompt(`Suspend "${o.name}"? Optional reason:`) ?? undefined;
    if (reason === undefined && !window.confirm(`Suspend "${o.name}"?`)) return;
    setBusy(o.id);
    try { await adminApi.suspendOrg(o.id, reason); load(); } finally { setBusy(null); }
  };
  const reactivate = async (o: OrgListItem) => {
    setBusy(o.id);
    try { await adminApi.reactivateOrg(o.id); load(); } finally { setBusy(null); }
  };

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-xl font-semibold text-neutral-900">Organizations</h1>
      </div>
      <div className="mb-4 flex gap-3">
        <input
          value={search} onChange={(e) => setSearch(e.target.value)}
          placeholder="Search name or slug…"
          className="w-64 rounded-md border border-neutral-300 px-3 py-2 text-sm"
        />
        <select value={status} onChange={(e) => setStatus(e.target.value)}
          className="rounded-md border border-neutral-300 px-3 py-2 text-sm capitalize">
          {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>

      <div className="overflow-hidden rounded-xl border border-neutral-200 bg-white">
        <table className="w-full text-sm">
          <thead className="bg-neutral-50 text-left text-xs uppercase tracking-wide text-neutral-500">
            <tr>
              <th className="px-4 py-3">Organization</th>
              <th className="px-4 py-3">Plan</th>
              <th className="px-4 py-3">Users</th>
              <th className="px-4 py-3">Numbers</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-100">
            {loading && <tr><td colSpan={6} className="px-4 py-8 text-center text-neutral-400">Loading…</td></tr>}
            {!loading && items.length === 0 && <tr><td colSpan={6} className="px-4 py-8 text-center text-neutral-400">No organizations.</td></tr>}
            {items.map((o) => (
              <tr key={o.id} className="hover:bg-neutral-50">
                <td className="px-4 py-3">
                  <Link href={`/admin/organizations/${o.id}`} className="font-medium text-neutral-900 hover:underline">{o.name}</Link>
                  <div className="text-xs text-neutral-500">/{o.slug}</div>
                </td>
                <td className="px-4 py-3">{o.plan ? `${o.plan.name}` : <span className="text-neutral-400">—</span>}</td>
                <td className="px-4 py-3">{o.counts.users}</td>
                <td className="px-4 py-3">{o.counts.whatsAppNumbers}</td>
                <td className="px-4 py-3">
                  {o.deletedAt ? <Badge tone="red">Deleted</Badge>
                    : o.suspendedAt ? <Badge tone="amber">Suspended</Badge>
                      : <Badge tone="green">Active</Badge>}
                </td>
                <td className="px-4 py-3 text-right">
                  {!o.deletedAt && (o.suspendedAt
                    ? <button disabled={busy === o.id} onClick={() => reactivate(o)} className="rounded-md border border-neutral-300 px-2.5 py-1 text-xs hover:bg-neutral-100">Reactivate</button>
                    : <button disabled={busy === o.id} onClick={() => suspend(o)} className="rounded-md border border-amber-300 px-2.5 py-1 text-xs text-amber-700 hover:bg-amber-50">Suspend</button>)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Badge({ tone, children }: { tone: 'green' | 'amber' | 'red'; children: React.ReactNode }) {
  const map = {
    green: 'bg-green-50 text-green-700 ring-green-200',
    amber: 'bg-amber-50 text-amber-700 ring-amber-200',
    red: 'bg-red-50 text-red-700 ring-red-200',
  } as const;
  return <span className={`inline-flex rounded-full px-2 py-0.5 text-xs font-medium ring-1 ring-inset ${map[tone]}`}>{children}</span>;
}
