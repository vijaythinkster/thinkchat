'use client';

import { useEffect, useState } from 'react';
import { adminApi } from '@/lib/admin-api';
import type { PlatformOverview } from '@/types/admin';

const money = (n: number, c = 'INR') =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: c, maximumFractionDigits: 0 }).format(n);

function Stat({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div className="rounded-xl border border-neutral-200 bg-white p-5">
      <div className="text-xs font-medium uppercase tracking-wide text-neutral-500">{label}</div>
      <div className="mt-2 text-2xl font-semibold text-neutral-900">{value}</div>
      {sub && <div className="mt-1 text-xs text-neutral-500">{sub}</div>}
    </div>
  );
}

export function OverviewDashboard() {
  const [data, setData] = useState<PlatformOverview | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => { adminApi.overview().then(setData).catch((e) => setErr(String(e))); }, []);

  if (err) return <div className="text-sm text-red-600">{err}</div>;
  if (!data) return <div className="text-sm text-neutral-500">Loading…</div>;

  const m = data.messagingThisMonth;
  return (
    <div>
      <h1 className="mb-6 text-xl font-semibold text-neutral-900">Overview</h1>
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Stat label="MRR" value={money(data.mrr)} sub="active subscriptions" />
        <Stat label="Revenue (MTD)" value={money(data.revenueThisMonth)} sub="paid invoices this month" />
        <Stat label="Organizations" value={String(data.organizations.active)} sub={`${data.organizations.suspended} suspended`} />
        <Stat label="Connected numbers" value={String(data.connectedNumbers)} />
        <Stat label="Users" value={String(data.users)} />
        <Stat label="Messages (30d)" value={new Intl.NumberFormat('en-IN').format(data.messagesLast30d)} />
        <Stat label="Messaging margin (MTD)" value={money(m.margin)} sub={`${m.marginPct}% of ${money(m.billed)} billed`} />
        <Stat label="Meta cost (MTD)" value={money(m.metaCost)} sub={`${new Intl.NumberFormat('en-IN').format(m.messages)} msgs`} />
      </div>
      <p className="mt-6 text-xs text-neutral-500">
        Margin = what you billed customers minus Meta&apos;s per-message cost — your transparent-pricing wedge, watched at the platform level.
      </p>
    </div>
  );
}
