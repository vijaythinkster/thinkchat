'use client';

import { useEffect, useState } from 'react';
import { adminApi } from '@/lib/admin-api';
import type { PlanRow } from '@/types/admin';

export function PlansManager() {
  const [plans, setPlans] = useState<PlanRow[]>([]);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({ tier: 'STARTER', name: '', priceMonthly: '', priceYearly: '', currency: 'INR' });

  const load = () => adminApi.listPlans().then(setPlans);
  useEffect(() => { load(); }, []);

  const create = async () => {
    await adminApi.createPlan({
      ...form,
      limits: { agents: 5, numbers: 1, messages: 5000, contacts: 5000 },
      features: {},
    });
    setCreating(false);
    setForm({ tier: 'STARTER', name: '', priceMonthly: '', priceYearly: '', currency: 'INR' });
    load();
  };
  const toggle = async (p: PlanRow) => { await adminApi.updatePlan(p.id, { isActive: !p.isActive }); load(); };

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-xl font-semibold text-neutral-900">Plans</h1>
        <button onClick={() => setCreating((v) => !v)} className="rounded-md bg-neutral-900 px-3 py-2 text-sm text-white">{creating ? 'Cancel' : 'New plan'}</button>
      </div>

      {creating && (
        <div className="mb-4 grid grid-cols-2 gap-3 rounded-xl border border-neutral-200 bg-white p-4 lg:grid-cols-5">
          <select value={form.tier} onChange={(e) => setForm({ ...form, tier: e.target.value })} className="rounded-md border border-neutral-300 px-3 py-2 text-sm">
            {['FREE', 'STARTER', 'GROWTH', 'AGENCY', 'ENTERPRISE'].map((t) => <option key={t}>{t}</option>)}
          </select>
          <input placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="rounded-md border border-neutral-300 px-3 py-2 text-sm" />
          <input placeholder="Monthly" value={form.priceMonthly} onChange={(e) => setForm({ ...form, priceMonthly: e.target.value })} className="rounded-md border border-neutral-300 px-3 py-2 text-sm" />
          <input placeholder="Yearly" value={form.priceYearly} onChange={(e) => setForm({ ...form, priceYearly: e.target.value })} className="rounded-md border border-neutral-300 px-3 py-2 text-sm" />
          <button onClick={create} className="rounded-md bg-neutral-900 px-3 py-2 text-sm text-white">Create</button>
        </div>
      )}

      <div className="overflow-hidden rounded-xl border border-neutral-200 bg-white">
        <table className="w-full text-sm">
          <thead className="bg-neutral-50 text-left text-xs uppercase tracking-wide text-neutral-500">
            <tr><th className="px-4 py-3">Tier</th><th className="px-4 py-3">Name</th><th className="px-4 py-3">Monthly</th><th className="px-4 py-3">Subscribers</th><th className="px-4 py-3">Active</th><th className="px-4 py-3 text-right">Actions</th></tr>
          </thead>
          <tbody className="divide-y divide-neutral-100">
            {plans.map((p) => (
              <tr key={p.id} className="hover:bg-neutral-50">
                <td className="px-4 py-3 font-medium">{p.tier}</td>
                <td className="px-4 py-3">{p.name}</td>
                <td className="px-4 py-3">{p.currency} {p.priceMonthly}</td>
                <td className="px-4 py-3">{p._count?.subscriptions ?? 0}</td>
                <td className="px-4 py-3">{p.isActive ? 'Yes' : 'No'}</td>
                <td className="px-4 py-3 text-right">
                  <button onClick={() => toggle(p)} className="rounded-md border border-neutral-300 px-2.5 py-1 text-xs hover:bg-neutral-100">{p.isActive ? 'Deactivate' : 'Activate'}</button>
                </td>
              </tr>
            ))}
            {plans.length === 0 && <tr><td colSpan={6} className="px-4 py-8 text-center text-neutral-400">No plans yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
