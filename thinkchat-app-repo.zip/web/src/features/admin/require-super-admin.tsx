'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { adminApi } from '@/lib/admin-api';

/**
 * Client gate for the platform console. Probes a platform-only endpoint; the
 * backend PlatformAdminGuard returns 403 for non-admins, so a failed probe
 * bounces the user back to the app. (Optimization: add `isSuperAdmin` to the
 * session so this can decide synchronously without a network round-trip.)
 */
export function RequireSuperAdmin({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [state, setState] = useState<'checking' | 'ok' | 'denied'>('checking');

  useEffect(() => {
    let alive = true;
    adminApi.overview()
      .then(() => alive && setState('ok'))
      .catch(() => { if (alive) { setState('denied'); router.replace('/inbox'); } });
    return () => { alive = false; };
  }, [router]);

  if (state === 'checking') {
    return <div className="flex h-screen items-center justify-center text-sm text-neutral-500">Checking access…</div>;
  }
  if (state === 'denied') return null;
  return <>{children}</>;
}
