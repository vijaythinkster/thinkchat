'use client';

import { useEffect, useState } from 'react';
import { aiApi } from '@/lib/ai-api';
import { Assistant, AIProviderId, PROVIDER_MODELS } from '@/types/ai';

export function AssistantSettings({ assistantId }: { assistantId: string }) {
  const [a, setA] = useState<Assistant | null>(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => { aiApi.get(assistantId).then(setA); }, [assistantId]);
  if (!a) return <p className="text-sm text-slate-500">Loading…</p>;

  const set = <K extends keyof Assistant>(k: K, v: Assistant[K]) => setA({ ...a, [k]: v });

  const save = async () => {
    await aiApi.update(a.id, {
      name: a.name, provider: a.provider, model: a.model, systemPrompt: a.systemPrompt,
      temperature: a.temperature, isActive: a.isActive,
    });
    setSaved(true); setTimeout(() => setSaved(false), 1500);
  };

  return (
    <div className="max-w-2xl space-y-5 rounded-xl border border-slate-200 bg-white p-6">
      <div className="flex items-center justify-between">
        <input value={a.name} onChange={(e) => set('name', e.target.value)}
          className="text-lg font-semibold text-slate-900 outline-none" />
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={a.isActive} onChange={(e) => set('isActive', e.target.checked)} />
          Active
        </label>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Select label="Provider" value={a.provider}
          options={['OPENAI', 'ANTHROPIC', 'GEMINI']}
          onChange={(v) => { const p = v as AIProviderId; set('provider', p); set('model', PROVIDER_MODELS[p][0]); }} />
        <Select label="Model" value={a.model} options={PROVIDER_MODELS[a.provider]}
          onChange={(v) => set('model', v)} />
      </div>

      <label className="block">
        <span className="text-sm font-medium text-slate-700">System prompt</span>
        <textarea value={a.systemPrompt} onChange={(e) => set('systemPrompt', e.target.value)} rows={6}
          className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-mono" />
      </label>

      <label className="block">
        <span className="text-sm font-medium text-slate-700">Creativity (temperature): {a.temperature.toFixed(2)}</span>
        <input type="range" min={0} max={1} step={0.05} value={a.temperature}
          onChange={(e) => set('temperature', Number(e.target.value))} className="mt-2 w-full" />
      </label>

      <div className="flex items-center gap-3">
        <button onClick={save} className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white">Save</button>
        {saved ? <span className="text-sm text-emerald-600">Saved ✓</span> : null}
      </div>
    </div>
  );
}

function Select({ label, value, options, onChange }: {
  label: string; value: string; options: string[]; onChange: (v: string) => void;
}) {
  return (
    <label className="block">
      <span className="text-sm font-medium text-slate-700">{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
        {options.map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
    </label>
  );
}
