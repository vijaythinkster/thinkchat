'use client';

import { useEffect, useState } from 'react';
import { aiApi } from '@/lib/ai-api';
import type { KnowledgeEntry } from '@/types/ai';

export function KnowledgeManager({ assistantId }: { assistantId: string }) {
  const [items, setItems] = useState<KnowledgeEntry[]>([]);
  const [name, setName] = useState('');
  const [content, setContent] = useState('');

  const load = () => aiApi.knowledge(assistantId).then(setItems).catch(() => setItems([]));
  useEffect(() => { load(); }, [assistantId]);

  const add = async () => {
    if (!name.trim() || !content.trim()) return;
    await aiApi.addKnowledge(assistantId, { name: name.trim(), sourceType: 'TEXT', content: content.trim() });
    setName(''); setContent(''); load();
  };

  return (
    <div className="max-w-2xl space-y-4">
      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <p className="mb-3 text-sm font-semibold text-slate-700">Add knowledge</p>
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Title (e.g. Refund policy)"
          className="mb-2 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
        <textarea value={content} onChange={(e) => setContent(e.target.value)} rows={4}
          placeholder="Paste the text the assistant should know…"
          className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
        <button onClick={add} className="mt-2 rounded-lg bg-indigo-600 px-3 py-1.5 text-sm font-semibold text-white">
          Add
        </button>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white">
        {items.map((k) => (
          <div key={k.id} className="flex items-center justify-between border-b border-slate-100 px-4 py-3 last:border-0">
            <div>
              <p className="text-sm font-medium text-slate-800">{k.name}</p>
              <p className="text-xs text-slate-400">{k.sourceType} · {(k.content ?? '').slice(0, 60)}…</p>
            </div>
            <button onClick={() => aiApi.removeKnowledge(assistantId, k.id).then(load)}
              className="text-xs font-medium text-rose-600">Remove</button>
          </div>
        ))}
        {items.length === 0 ? <p className="px-4 py-6 text-center text-sm text-slate-400">No knowledge yet</p> : null}
      </div>
    </div>
  );
}
