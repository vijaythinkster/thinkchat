'use client';

import { useState } from 'react';
import { aiApi } from '@/lib/ai-api';
import type { TestResult } from '@/types/ai';

/** Quick test harness in the settings UI: send a message, see the assistant's reply + token use. */
export function Playground({ assistantId }: { assistantId: string }) {
  const [message, setMessage] = useState('');
  const [result, setResult] = useState<TestResult | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const run = async () => {
    if (!message.trim()) return;
    setBusy(true); setError(null); setResult(null);
    try { setResult(await aiApi.test(assistantId, message.trim())); }
    catch (e) { setError(e instanceof Error ? e.message : 'Failed'); }
    finally { setBusy(false); }
  };

  return (
    <div className="max-w-2xl space-y-3 rounded-xl border border-slate-200 bg-white p-5">
      <p className="text-sm font-semibold text-slate-700">Test the assistant</p>
      <textarea value={message} onChange={(e) => setMessage(e.target.value)} rows={3}
        placeholder="Type a customer message…"
        className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
      <button onClick={run} disabled={busy}
        className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50">
        {busy ? 'Thinking…' : 'Send test'}
      </button>

      {error ? <p className="text-sm text-rose-600">{error}</p> : null}
      {result ? (
        <div className="rounded-lg bg-slate-50 p-4">
          <p className="whitespace-pre-wrap text-sm text-slate-800">{result.reply}</p>
          <p className="mt-2 text-xs text-slate-400">{result.tokensIn} in · {result.tokensOut} out tokens</p>
        </div>
      ) : null}
    </div>
  );
}
