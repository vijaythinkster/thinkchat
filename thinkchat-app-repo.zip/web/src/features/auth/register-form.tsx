'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useAuth } from '@/hooks/use-auth';

export function RegisterForm() {
  const { register } = useAuth();
  const [form, setForm] = useState({ organizationName: '', email: '', password: '', firstName: '' });
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null); setBusy(true);
    try {
      await register({
        organizationName: form.organizationName, email: form.email,
        password: form.password, firstName: form.firstName || undefined,
      });
    } catch (err) {
      setError(err instanceof Error && err.message.includes('409') ? 'That email is already in use.' : 'Could not create account.');
    } finally { setBusy(false); }
  };

  return (
    <div className="mx-auto mt-20 w-full max-w-sm">
      <h1 className="text-2xl font-semibold text-slate-900">Create your workspace</h1>
      <p className="mt-1 text-sm text-slate-500">Start your WhatsApp platform account.</p>
      <form onSubmit={submit} className="mt-6 space-y-4">
        <Field label="Business name" value={form.organizationName} onChange={set('organizationName')} />
        <Field label="Your name" value={form.firstName} onChange={set('firstName')} required={false} />
        <Field label="Email" type="email" value={form.email} onChange={set('email')} />
        <Field label="Password" type="password" value={form.password} onChange={set('password')} hint="At least 8 characters" />
        {error ? <p className="text-sm text-rose-600">{error}</p> : null}
        <button type="submit" disabled={busy}
          className="w-full rounded-lg bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-50">
          {busy ? 'Creating…' : 'Create account'}
        </button>
      </form>
      <p className="mt-4 text-sm text-slate-500">
        Already have an account? <Link href="/login" className="font-medium text-indigo-600">Sign in</Link>
      </p>
    </div>
  );
}

function Field({ label, type = 'text', value, onChange, required = true, hint }: {
  label: string; type?: string; value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void; required?: boolean; hint?: string;
}) {
  return (
    <label className="block">
      <span className="text-sm font-medium text-slate-700">{label}</span>
      <input type={type} value={value} required={required} onChange={onChange}
        className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" />
      {hint ? <span className="mt-0.5 block text-xs text-slate-400">{hint}</span> : null}
    </label>
  );
}
