'use client';

import { useEffect, useState } from 'react';
import { billingApi } from '@/lib/billing-api';
import type { Invoice } from '@/types/billing';

const TONE: Record<string, string> = {
  PAID: 'bg-emerald-100 text-emerald-700',
  OPEN: 'bg-amber-100 text-amber-700',
  DRAFT: 'bg-slate-100 text-slate-500',
  VOID: 'bg-slate-100 text-slate-400',
  UNCOLLECTIBLE: 'bg-rose-100 text-rose-700',
};

export function InvoicesList() {
  const [items, setItems] = useState<Invoice[]>([]);
  const [busy, setBusy] = useState<string | null>(null);

  useEffect(() => { billingApi.invoices().then(setItems).catch(() => setItems([])); }, []);

  const pay = async (inv: Invoice) => {
    setBusy(inv.id);
    try {
      const s = await billingApi.checkout(inv.id);
      if (s.checkoutUrl) window.location.href = s.checkoutUrl;
    } finally { setBusy(null); }
  };

  return (
    <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
      <table className="w-full text-sm">
        <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
          <tr>
            <th className="px-4 py-3">Invoice</th>
            <th className="px-4 py-3">Total</th>
            <th className="px-4 py-3">Status</th>
            <th className="px-4 py-3">Due</th>
            <th className="px-4 py-3" />
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {items.map((inv) => (
            <tr key={inv.id}>
              <td className="px-4 py-3 font-medium text-slate-900">{inv.number}</td>
              <td className="px-4 py-3 text-slate-700">
                {new Intl.NumberFormat('en', { style: 'currency', currency: inv.currency }).format(Number(inv.total))}
              </td>
              <td className="px-4 py-3">
                <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${TONE[inv.status]}`}>{inv.status}</span>
              </td>
              <td className="px-4 py-3 text-slate-500">{inv.dueAt ? new Date(inv.dueAt).toLocaleDateString() : '—'}</td>
              <td className="px-4 py-3 text-right">
                {inv.status === 'OPEN' ? (
                  <button onClick={() => pay(inv)} disabled={busy === inv.id}
                    className="rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white disabled:opacity-50">
                    {busy === inv.id ? '…' : 'Pay'}
                  </button>
                ) : null}
              </td>
            </tr>
          ))}
          {items.length === 0 ? (
            <tr><td colSpan={5} className="px-4 py-8 text-center text-slate-400">No invoices yet</td></tr>
          ) : null}
        </tbody>
      </table>
    </div>
  );
}
