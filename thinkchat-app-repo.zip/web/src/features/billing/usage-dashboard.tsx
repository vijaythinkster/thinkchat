'use client';

import { useEffect, useState } from 'react';
import { billingApi } from '@/lib/billing-api';
import type { PeriodUsage } from '@/types/billing';

const fmt = (n: number, c = 'USD') =>
  new Intl.NumberFormat('en', { style: 'currency', currency: c, maximumFractionDigits: 2 }).format(n);

function Card({ label, value, sub, tone = 'slate' }: {
  label: string; value: string; sub?: string; tone?: 'slate' | 'emerald' | 'indigo';
}) {
  const ring = tone === 'emerald' ? 'ring-emerald-200' : tone === 'indigo' ? 'ring-indigo-200' : 'ring-slate-200';
  return (
    <div className={`rounded-xl bg-white p-4 ring-1 ${ring}`}>
      <p className="text-xs font-medium uppercase tracking-wide text-slate-500">{label}</p>
      <p className="mt-1 text-2xl font-semibold text-slate-900">{value}</p>
      {sub ? <p className="mt-0.5 text-xs text-slate-500">{sub}</p> : null}
    </div>
  );
}

/**
 * Billing transparency: shows what Meta charged vs what the customer is billed,
 * the margin between them, and where the volume goes (category + country).
 */
export function UsageDashboard({ currency = 'USD' }: { currency?: string }) {
  const [u, setU] = useState<PeriodUsage | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    billingApi.usage().then(setU).catch((e) => setErr(String(e)));
  }, []);

  if (err) return <p className="text-sm text-rose-600">Couldn’t load usage: {err}</p>;
  if (!u) return <p className="text-sm text-slate-500">Loading usage…</p>;

  const maxCat = Math.max(1, ...u.byCategory.map((c) => c.messages));

  return (
    <div className="space-y-6">
      <header>
        <h2 className="text-lg font-semibold text-slate-900">This billing period</h2>
        <p className="text-sm text-slate-500">
          {new Date(u.periodStart).toLocaleDateString()} – {new Date(u.periodEnd).toLocaleDateString()}
        </p>
      </header>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Card label="Messages" value={u.totals.messages.toLocaleString()} sub="delivered + billable" />
        <Card label="Meta cost" value={fmt(u.totals.metaCost, currency)} sub="what Meta charges" />
        <Card label="You bill" value={fmt(u.totals.billedCost, currency)} sub="customer total" tone="indigo" />
        <Card label="Margin" value={fmt(u.totals.margin, currency)} sub="billed − Meta" tone="emerald" />
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <p className="mb-4 text-sm font-semibold text-slate-700">Volume by category</p>
        <div className="space-y-3">
          {u.byCategory.map((c) => (
            <div key={c.category}>
              <div className="mb-1 flex justify-between text-xs text-slate-600">
                <span className="capitalize">{c.category}</span>
                <span>{c.messages.toLocaleString()} · {fmt(c.billedCost, currency)}</span>
              </div>
              <div className="h-2 rounded-full bg-slate-100">
                <div className="h-2 rounded-full bg-indigo-500"
                  style={{ width: `${Math.round((c.messages / maxCat) * 100)}%` }} />
              </div>
            </div>
          ))}
          {u.byCategory.length === 0 ? <p className="text-sm text-slate-400">No usage yet this period.</p> : null}
        </div>
      </div>

      {u.byCountry.length > 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="mb-3 text-sm font-semibold text-slate-700">Top countries</p>
          <table className="w-full text-sm">
            <tbody className="divide-y divide-slate-100">
              {u.byCountry.slice(0, 6).map((c) => (
                <tr key={c.countryCode}>
                  <td className="py-2 font-medium text-slate-700">{c.countryCode}</td>
                  <td className="py-2 text-right text-slate-600">{c.messages.toLocaleString()} msgs</td>
                  <td className="py-2 text-right text-slate-600">{fmt(c.billedCost, currency)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}
    </div>
  );
}
