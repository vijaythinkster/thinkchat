'use client';

import { useEffect, useState } from 'react';
import {
  Bar, BarChart, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts';
import { campaignsApi } from '@/lib/campaigns-api';
import type { Campaign, CampaignAnalytics } from '@/types/campaigns';

const STATUS_TONE: Record<string, string> = {
  RUNNING: 'bg-emerald-100 text-emerald-700',
  SCHEDULED: 'bg-amber-100 text-amber-700',
  COMPLETED: 'bg-slate-100 text-slate-600',
  PAUSED: 'bg-orange-100 text-orange-700',
  CANCELED: 'bg-rose-100 text-rose-700',
  DRAFT: 'bg-slate-100 text-slate-500',
  FAILED: 'bg-rose-100 text-rose-700',
};

function Metric({ label, value, sub }: { label: string; value: string | number; sub?: string }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4">
      <p className="text-xs font-medium uppercase tracking-wide text-slate-500">{label}</p>
      <p className="mt-1 text-2xl font-semibold text-slate-900">{value}</p>
      {sub ? <p className="mt-0.5 text-xs text-slate-500">{sub}</p> : null}
    </div>
  );
}

/** Marquee campaign report: headline metrics + a delivery funnel + reliability. */
export function CampaignAnalytics({ campaign }: { campaign: Campaign }) {
  const [data, setData] = useState<CampaignAnalytics | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    const load = () =>
      campaignsApi.analytics(campaign.id)
        .then((d) => active && setData(d))
        .catch((e) => active && setError(String(e)));
    load();
    // Live campaigns move; poll while running.
    const t = campaign.status === 'RUNNING' ? setInterval(load, 5000) : null;
    return () => { active = false; if (t) clearInterval(t); };
  }, [campaign.id, campaign.status]);

  if (error) return <p className="text-sm text-rose-600">Couldn’t load analytics: {error}</p>;
  if (!data) return <p className="text-sm text-slate-500">Loading analytics…</p>;

  const { totals, rates } = data;
  const funnel = [
    { stage: 'Sent', value: totals.sent, fill: '#6366f1' },
    { stage: 'Delivered', value: totals.delivered, fill: '#3b82f6' },
    { stage: 'Read', value: totals.read, fill: '#06b6d4' },
    { stage: 'Replied', value: totals.replied, fill: '#10b981' },
  ];

  return (
    <div className="space-y-6">
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-slate-900">{campaign.name}</h2>
          <p className="text-sm text-slate-500">{campaign.template?.name ?? 'Template'} · {totals.audience} recipients</p>
        </div>
        <span className={`rounded-full px-3 py-1 text-xs font-medium ${STATUS_TONE[campaign.status]}`}>
          {campaign.status}
        </span>
      </header>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <Metric label="Delivered" value={totals.delivered} sub={`${rates.deliveryRate}% of sent`} />
        <Metric label="Read" value={totals.read} sub={`${rates.readRate}% of delivered`} />
        <Metric label="Replied" value={totals.replied} sub={`${rates.replyRate}% reply rate`} />
        <Metric label="Failed" value={totals.failed} sub={`${rates.failureRate}% failure rate`} />
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <p className="mb-3 text-sm font-semibold text-slate-700">Delivery funnel</p>
        <div className="h-56">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={funnel} layout="vertical" margin={{ left: 24, right: 24 }}>
              <XAxis type="number" hide />
              <YAxis type="category" dataKey="stage" axisLine={false} tickLine={false}
                width={80} tick={{ fontSize: 13, fill: '#475569' }} />
              <Tooltip cursor={{ fill: '#f1f5f9' }} />
              <Bar dataKey="value" radius={[0, 6, 6, 0]} barSize={28}>
                {funnel.map((d) => <Cell key={d.stage} fill={d.fill} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {totals.pending > 0 ? (
        <p className="text-xs text-slate-500">{totals.pending} still queued for sending…</p>
      ) : null}
    </div>
  );
}
