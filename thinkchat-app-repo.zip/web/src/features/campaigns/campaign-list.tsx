'use client';

import { useEffect, useState } from 'react';
import { campaignsApi } from '@/lib/campaigns-api';
import type { Campaign } from '@/types/campaigns';

const TONE: Record<string, string> = {
  RUNNING: 'bg-emerald-100 text-emerald-700',
  SCHEDULED: 'bg-amber-100 text-amber-700',
  COMPLETED: 'bg-slate-100 text-slate-600',
  PAUSED: 'bg-orange-100 text-orange-700',
  CANCELED: 'bg-rose-100 text-rose-700',
  DRAFT: 'bg-slate-100 text-slate-500',
  FAILED: 'bg-rose-100 text-rose-700',
};

export function CampaignList({ onSelect }: { onSelect?: (c: Campaign) => void }) {
  const [items, setItems] = useState<Campaign[]>([]);

  useEffect(() => {
    campaignsApi.list().then(setItems).catch(() => setItems([]));
  }, []);

  return (
    <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
      <table className="w-full text-sm">
        <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
          <tr>
            <th className="px-4 py-3">Campaign</th>
            <th className="px-4 py-3">Template</th>
            <th className="px-4 py-3">Status</th>
            <th className="px-4 py-3">Scheduled</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {items.map((c) => (
            <tr key={c.id} className="cursor-pointer hover:bg-slate-50" onClick={() => onSelect?.(c)}>
              <td className="px-4 py-3 font-medium text-slate-900">{c.name}</td>
              <td className="px-4 py-3 text-slate-600">{c.template?.name ?? '—'}</td>
              <td className="px-4 py-3">
                <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${TONE[c.status]}`}>
                  {c.status}
                </span>
              </td>
              <td className="px-4 py-3 text-slate-500">
                {c.scheduledAt ? new Date(c.scheduledAt).toLocaleString() : '—'}
              </td>
            </tr>
          ))}
          {items.length === 0 ? (
            <tr><td colSpan={4} className="px-4 py-8 text-center text-slate-400">No campaigns yet</td></tr>
          ) : null}
        </tbody>
      </table>
    </div>
  );
}
