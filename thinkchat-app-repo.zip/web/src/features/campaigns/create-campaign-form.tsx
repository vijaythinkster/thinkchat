'use client';

import { useState } from 'react';
import { campaignsApi } from '@/lib/campaigns-api';
import type { CreateCampaignInput, SegmentCondition } from '@/types/campaigns';

/** Compact create flow: name → template/number → audience rules → live audience count. */
export function CreateCampaignForm({
  templates, numbers, onCreated,
}: {
  templates: { id: string; name: string }[];
  numbers: { id: string; label: string }[];
  onCreated?: (id: string) => void;
}) {
  const [name, setName] = useState('');
  const [templateId, setTemplateId] = useState(templates[0]?.id ?? '');
  const [whatsAppNumberId, setNumberId] = useState(numbers[0]?.id ?? '');
  const [conditions, setConditions] = useState<SegmentCondition[]>([{ field: 'optedIn', op: 'equals', value: true }]);
  const [audience, setAudience] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);

  const segment = { match: 'all' as const, conditions };

  const preview = async () => {
    const { count } = await campaignsApi.previewAudience(segment);
    setAudience(count);
  };

  const submit = async () => {
    setBusy(true);
    try {
      const input: CreateCampaignInput = { name, templateId, whatsAppNumberId, segment };
      const c = await campaignsApi.create(input);
      onCreated?.(c.id);
    } finally {
      setBusy(false);
    }
  };

  const setCond = (i: number, patch: Partial<SegmentCondition>) =>
    setConditions((cs) => cs.map((c, idx) => (idx === i ? { ...c, ...patch } : c)));

  return (
    <div className="max-w-xl space-y-5 rounded-xl border border-slate-200 bg-white p-6">
      <div>
        <label className="text-sm font-medium text-slate-700">Campaign name</label>
        <input value={name} onChange={(e) => setName(e.target.value)}
          className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
          placeholder="Diwali offer — Pune list" />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-sm font-medium text-slate-700">Template</label>
          <select value={templateId} onChange={(e) => setTemplateId(e.target.value)}
            className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
            {templates.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
          </select>
        </div>
        <div>
          <label className="text-sm font-medium text-slate-700">Send from</label>
          <select value={whatsAppNumberId} onChange={(e) => setNumberId(e.target.value)}
            className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm">
            {numbers.map((n) => <option key={n.id} value={n.id}>{n.label}</option>)}
          </select>
        </div>
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium text-slate-700">Audience rules</label>
        {conditions.map((c, i) => (
          <div key={i} className="flex gap-2">
            <input value={c.field} onChange={(e) => setCond(i, { field: e.target.value })}
              className="w-1/3 rounded-lg border border-slate-300 px-2 py-1.5 text-sm" placeholder="field" />
            <input value={c.op} onChange={(e) => setCond(i, { op: e.target.value })}
              className="w-1/4 rounded-lg border border-slate-300 px-2 py-1.5 text-sm" placeholder="op" />
            <input value={String(c.value ?? '')} onChange={(e) => setCond(i, { value: e.target.value })}
              className="flex-1 rounded-lg border border-slate-300 px-2 py-1.5 text-sm" placeholder="value" />
          </div>
        ))}
        <button onClick={() => setConditions((cs) => [...cs, { field: '', op: 'equals', value: '' }])}
          className="text-xs font-medium text-indigo-600">+ add rule</button>
      </div>

      <div className="flex items-center justify-between border-t border-slate-100 pt-4">
        <button onClick={preview} className="text-sm font-medium text-slate-700 underline">
          Preview audience
        </button>
        {audience !== null ? <span className="text-sm text-slate-600">{audience} contacts</span> : null}
      </div>

      <button onClick={submit} disabled={busy || !name || !templateId}
        className="w-full rounded-lg bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-50">
        {busy ? 'Creating…' : 'Create campaign (draft)'}
      </button>
    </div>
  );
}
