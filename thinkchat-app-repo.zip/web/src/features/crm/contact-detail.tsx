'use client';

import { useEffect, useState } from 'react';
import { crmApi } from '@/lib/crm-api';
import type { ContactDetail as Detail } from '@/types/crm';

export function ContactDetail({ contactId }: { contactId: string }) {
  const [d, setD] = useState<Detail | null>(null);
  const [note, setNote] = useState('');

  const load = () => crmApi.getContact(contactId).then(setD).catch(() => setD(null));
  useEffect(() => { load(); }, [contactId]);

  const addNote = async () => {
    if (!note.trim()) return;
    await crmApi.addNote({ body: note.trim(), contactId });
    setNote('');
    load();
  };

  if (!d) return <p className="text-sm text-slate-500">Loading…</p>;
  const { contact, notes, deals, tasks, conversations } = d;
  const attrs = Object.entries(contact.attributes ?? {});

  return (
    <div className="grid gap-6 md:grid-cols-3">
      <aside className="space-y-4 md:col-span-1">
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <h2 className="text-lg font-semibold text-slate-900">{contact.name ?? contact.phone}</h2>
          <p className="text-sm text-slate-500">{contact.phone}</p>
          {contact.email ? <p className="text-sm text-slate-500">{contact.email}</p> : null}
          <div className="mt-3 flex flex-wrap gap-1">
            {(contact.contactLabels ?? []).map((cl) => (
              <span key={cl.label.id} className="rounded-full px-2 py-0.5 text-xs font-medium text-white"
                style={{ backgroundColor: cl.label.color }}>{cl.label.name}</span>
            ))}
          </div>
        </div>
        {attrs.length ? (
          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Custom fields</p>
            <dl className="space-y-1 text-sm">
              {attrs.map(([k, v]) => (
                <div key={k} className="flex justify-between">
                  <dt className="text-slate-500">{k}</dt>
                  <dd className="font-medium text-slate-800">{String(v)}</dd>
                </div>
              ))}
            </dl>
          </div>
        ) : null}
      </aside>

      <section className="space-y-5 md:col-span-2">
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="mb-2 text-sm font-semibold text-slate-700">Add note</p>
          <textarea value={note} onChange={(e) => setNote(e.target.value)} rows={2}
            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
            placeholder="Log a call, a follow-up, anything…" />
          <button onClick={addNote}
            className="mt-2 rounded-lg bg-indigo-600 px-3 py-1.5 text-sm font-semibold text-white">Save note</button>
        </div>

        <Timeline notes={notes} deals={deals} tasks={tasks} conversations={conversations} />
      </section>
    </div>
  );
}

function Timeline({ notes, deals, tasks, conversations }: Pick<Detail, 'notes' | 'deals' | 'tasks' | 'conversations'>) {
  return (
    <div className="space-y-4">
      {deals.length ? (
        <Block title="Deals">
          {deals.map((d) => (
            <Row key={d.id} left={d.title} right={`${d.stage?.name ?? ''} · ${d.status}`} />
          ))}
        </Block>
      ) : null}
      {tasks.length ? (
        <Block title="Tasks">
          {tasks.map((t) => (
            <Row key={t.id} left={t.title} right={t.dueAt ? new Date(t.dueAt).toLocaleDateString() : t.status} />
          ))}
        </Block>
      ) : null}
      <Block title="Notes">
        {notes.length === 0 ? <p className="text-sm text-slate-400">No notes yet.</p> : null}
        {notes.map((n) => (
          <div key={n.id} className="border-l-2 border-slate-200 pl-3">
            <p className="text-sm text-slate-700">{n.body}</p>
            <p className="text-xs text-slate-400">
              {n.author?.name ?? 'System'} · {new Date(n.createdAt).toLocaleString()}
            </p>
          </div>
        ))}
      </Block>
      {conversations.length ? (
        <Block title="Conversations">
          {conversations.map((c) => (
            <Row key={c.id} left={`Chat ${c.status}`}
              right={c.lastMessageAt ? new Date(c.lastMessageAt).toLocaleDateString() : ''} />
          ))}
        </Block>
      ) : null}
    </div>
  );
}

function Block({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-5">
      <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-slate-500">{title}</p>
      <div className="space-y-2">{children}</div>
    </div>
  );
}
function Row({ left, right }: { left: string; right: string }) {
  return (
    <div className="flex justify-between text-sm">
      <span className="text-slate-700">{left}</span>
      <span className="text-slate-400">{right}</span>
    </div>
  );
}
