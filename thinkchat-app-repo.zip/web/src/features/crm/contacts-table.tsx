'use client';

import { useCallback, useEffect, useState } from 'react';
import { crmApi } from '@/lib/crm-api';
import type { Contact } from '@/types/crm';

export function ContactsTable({ onOpen }: { onOpen?: (id: string) => void }) {
  const [items, setItems] = useState<Contact[]>([]);
  const [q, setQ] = useState('');
  const [cursor, setCursor] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async (reset: boolean) => {
    setLoading(true);
    try {
      const res = await crmApi.listContacts({ q: q || undefined, cursor: reset ? undefined : cursor || undefined });
      setItems((prev) => (reset ? res.items : [...prev, ...res.items]));
      setCursor(res.nextCursor);
    } finally {
      setLoading(false);
    }
  }, [q, cursor]);

  useEffect(() => { load(true); /* on search change */ }, [q]); // eslint-disable-line

  return (
    <div className="space-y-3">
      <input value={q} onChange={(e) => setQ(e.target.value)}
        placeholder="Search name, phone, or email…"
        className="w-full max-w-sm rounded-lg border border-slate-300 px-3 py-2 text-sm" />

      <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-4 py-3">Name</th>
              <th className="px-4 py-3">Phone</th>
              <th className="px-4 py-3">Labels</th>
              <th className="px-4 py-3">Opted in</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {items.map((c) => (
              <tr key={c.id} className="cursor-pointer hover:bg-slate-50" onClick={() => onOpen?.(c.id)}>
                <td className="px-4 py-3 font-medium text-slate-900">{c.name ?? '—'}</td>
                <td className="px-4 py-3 text-slate-600">{c.phone}</td>
                <td className="px-4 py-3">
                  <div className="flex flex-wrap gap-1">
                    {(c.contactLabels ?? []).map((cl) => (
                      <span key={cl.label.id}
                        className="rounded-full px-2 py-0.5 text-xs font-medium text-white"
                        style={{ backgroundColor: cl.label.color }}>
                        {cl.label.name}
                      </span>
                    ))}
                  </div>
                </td>
                <td className="px-4 py-3">
                  <span className={`rounded-full px-2 py-0.5 text-xs ${c.optedIn ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                    {c.optedIn ? 'Yes' : 'No'}
                  </span>
                </td>
              </tr>
            ))}
            {items.length === 0 && !loading ? (
              <tr><td colSpan={4} className="px-4 py-8 text-center text-slate-400">No contacts</td></tr>
            ) : null}
          </tbody>
        </table>
      </div>

      {cursor ? (
        <button onClick={() => load(false)} disabled={loading}
          className="rounded-lg border border-slate-300 px-3 py-1.5 text-sm font-medium text-slate-700">
          {loading ? 'Loading…' : 'Load more'}
        </button>
      ) : null}
    </div>
  );
}
