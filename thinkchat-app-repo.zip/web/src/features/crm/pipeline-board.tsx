'use client';

import { useEffect, useState } from 'react';
import { crmApi } from '@/lib/crm-api';
import type { Board, Deal } from '@/types/crm';

const money = (v: string | number, c = 'USD') =>
  new Intl.NumberFormat('en', { style: 'currency', currency: c, maximumFractionDigits: 0 }).format(Number(v));

/** Kanban board with native HTML5 drag-and-drop; dropping a card calls moveDeal. */
export function PipelineBoard() {
  const [board, setBoard] = useState<Board | null>(null);
  const [dragId, setDragId] = useState<string | null>(null);

  const load = () => crmApi.board().then(setBoard).catch(() => setBoard(null));
  useEffect(() => { load(); }, []);

  const onDrop = async (stageId: string) => {
    if (!dragId) return;
    const id = dragId;
    setDragId(null);
    // optimistic: move card locally
    setBoard((b) => {
      if (!b) return b;
      let moved: Deal | undefined;
      const stripped = b.columns.map((col) => {
        const keep = col.deals.filter((d) => { if (d.id === id) { moved = d; return false; } return true; });
        return { ...col, deals: keep };
      });
      return {
        ...b,
        columns: stripped.map((col) =>
          col.stage.id === stageId && moved ? { ...col, deals: [{ ...moved, stageId }, ...col.deals] } : col),
      };
    });
    try { await crmApi.moveDeal(id, stageId); } catch { load(); }
  };

  if (!board?.pipeline) return <p className="text-sm text-slate-500">Loading pipeline…</p>;

  return (
    <div className="flex gap-4 overflow-x-auto pb-4">
      {board.columns.map((col) => (
        <div key={col.stage.id}
          onDragOver={(e) => e.preventDefault()}
          onDrop={() => onDrop(col.stage.id)}
          className="w-72 shrink-0 rounded-xl bg-slate-50 p-3">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-700">{col.stage.name}</h3>
            <span className="text-xs text-slate-400">{col.deals.length} · {money(col.totalValue)}</span>
          </div>
          <div className="space-y-2">
            {col.deals.map((d) => (
              <div key={d.id} draggable
                onDragStart={() => setDragId(d.id)}
                className="cursor-grab rounded-lg border border-slate-200 bg-white p-3 shadow-sm active:cursor-grabbing">
                <p className="text-sm font-medium text-slate-900">{d.title}</p>
                <p className="mt-0.5 text-xs text-slate-500">{d.contact?.name ?? d.contact?.phone ?? 'No contact'}</p>
                <p className="mt-1 text-xs font-semibold text-indigo-600">{money(d.value, d.currency)}</p>
              </div>
            ))}
            {col.deals.length === 0 ? <p className="py-4 text-center text-xs text-slate-300">Drop deals here</p> : null}
          </div>
        </div>
      ))}
    </div>
  );
}
