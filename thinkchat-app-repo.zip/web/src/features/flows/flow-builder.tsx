'use client';

import { useCallback, useEffect, useState } from 'react';
import ReactFlow, {
  addEdge, Background, Controls, type Connection, type Edge, type Node,
  useEdgesState, useNodesState,
} from 'reactflow';
import 'reactflow/dist/style.css';
import { flowsApi } from '@/lib/flows-api';
import { FlowNodeType, NODE_LABELS } from '@/types/flows';

const PALETTE: FlowNodeType[] = ['MESSAGE', 'QUESTION', 'CONDITION', 'AI', 'DELAY', 'TAG', 'CRM_UPDATE', 'HUMAN_AGENT', 'API_CALL'];
const cid = () => 'n_' + Math.random().toString(36).slice(2, 10);

/**
 * Visual flow builder on react-flow. The palette adds nodes; drag to connect;
 * the side panel edits the selected node's config. Save serializes nodes/edges
 * into the FlowNode/FlowConnection shape the engine reads.
 */
export function FlowBuilder({ flowId }: { flowId: string }) {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [selected, setSelected] = useState<Node | null>(null);
  const [status, setStatus] = useState<string>('');

  useEffect(() => {
    flowsApi.get(flowId).then((flow) => {
      setNodes((flow.nodes ?? []).map((n) => ({
        id: n.id, position: n.position, data: { ...n.config, _type: n.type, label: NODE_LABELS[n.type] },
        style: nodeStyle(n.type),
      })));
      setEdges((flow.connections ?? []).map((c, i) => ({
        id: c.id ?? `e_${i}`, source: c.sourceNodeId, target: c.targetNodeId,
        label: (c.condition as any)?.branch, animated: true,
      })));
    });
  }, [flowId, setNodes, setEdges]);

  const onConnect = useCallback((c: Connection) => setEdges((eds) => addEdge({ ...c, animated: true }, eds)), [setEdges]);

  const addNode = (type: FlowNodeType) => {
    const id = cid();
    setNodes((nds) => [...nds, {
      id, position: { x: 120 + Math.random() * 240, y: 80 + nds.length * 90 },
      data: { _type: type, label: NODE_LABELS[type], text: '' }, style: nodeStyle(type),
    }]);
  };

  const updateSelected = (patch: Record<string, unknown>) => {
    if (!selected) return;
    setNodes((nds) => nds.map((n) => (n.id === selected.id ? { ...n, data: { ...n.data, ...patch } } : n)));
    setSelected((s) => (s ? { ...s, data: { ...s.data, ...patch } } : s));
  };

  const save = async (publish: boolean) => {
    setStatus('Saving…');
    const fnodes = nodes.map((n) => {
      const { _type, label, ...config } = n.data as any;
      return { id: n.id, type: _type as FlowNodeType, label: NODE_LABELS[_type as FlowNodeType], config, position: n.position };
    });
    const conns = (edges as Edge[]).map((e) => ({
      sourceNodeId: e.source, targetNodeId: e.target,
      condition: e.label ? { branch: String(e.label) } : null,
    }));
    await flowsApi.saveCanvas(flowId, fnodes, conns);
    if (publish) await flowsApi.publish(flowId);
    setStatus(publish ? 'Published ✓' : 'Saved ✓');
    setTimeout(() => setStatus(''), 1500);
  };

  return (
    <div className="flex h-[calc(100vh-8rem)] gap-3">
      <aside className="w-44 shrink-0 space-y-2">
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Add step</p>
        {PALETTE.map((t) => (
          <button key={t} onClick={() => addNode(t)}
            className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-left text-sm hover:bg-slate-50">
            {NODE_LABELS[t]}
          </button>
        ))}
        <div className="pt-3">
          <button onClick={() => save(false)} className="mb-2 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm font-medium">Save draft</button>
          <button onClick={() => save(true)} className="w-full rounded-lg bg-indigo-600 px-3 py-2 text-sm font-semibold text-white">Publish</button>
          {status ? <p className="mt-2 text-xs text-emerald-600">{status}</p> : null}
        </div>
      </aside>

      <div className="flex-1 rounded-xl border border-slate-200 bg-white">
        <ReactFlow
          nodes={nodes} edges={edges}
          onNodesChange={onNodesChange} onEdgesChange={onEdgesChange} onConnect={onConnect}
          onNodeClick={(_, n) => setSelected(n)} fitView>
          <Background />
          <Controls />
        </ReactFlow>
      </div>

      {selected ? (
        <aside className="w-72 shrink-0 space-y-3 rounded-xl border border-slate-200 bg-white p-4">
          <p className="text-sm font-semibold text-slate-800">{(selected.data as any).label}</p>
          {['MESSAGE', 'QUESTION', 'AI'].includes((selected.data as any)._type) ? (
            <label className="block">
              <span className="text-xs font-medium text-slate-600">Message text (use {'{{name}}'})</span>
              <textarea rows={4} value={String((selected.data as any).text ?? '')}
                onChange={(e) => updateSelected({ text: e.target.value })}
                className="mt-1 w-full rounded-lg border border-slate-300 px-2 py-1.5 text-sm" />
            </label>
          ) : null}
          {(selected.data as any)._type === 'DELAY' ? (
            <div className="flex gap-2">
              <input type="number" value={Number((selected.data as any).value ?? 1)}
                onChange={(e) => updateSelected({ value: Number(e.target.value) })}
                className="w-20 rounded-lg border border-slate-300 px-2 py-1.5 text-sm" />
              <select value={String((selected.data as any).unit ?? 'minutes')}
                onChange={(e) => updateSelected({ unit: e.target.value })}
                className="flex-1 rounded-lg border border-slate-300 px-2 py-1.5 text-sm">
                <option value="minutes">minutes</option><option value="hours">hours</option><option value="days">days</option>
              </select>
            </div>
          ) : null}
          {(selected.data as any)._type === 'CONDITION' ? (
            <p className="text-xs text-slate-500">Label the two outgoing arrows <b>true</b> and <b>false</b> (click an edge to rename).</p>
          ) : null}
          <button onClick={() => { setNodes((nds) => nds.filter((n) => n.id !== selected.id)); setSelected(null); }}
            className="text-xs font-medium text-rose-600">Delete step</button>
        </aside>
      ) : null}
    </div>
  );
}

function nodeStyle(type: FlowNodeType): React.CSSProperties {
  const palette: Record<string, string> = {
    MESSAGE: '#6366f1', QUESTION: '#0ea5e9', CONDITION: '#f59e0b', AI: '#8b5cf6',
    DELAY: '#64748b', TAG: '#10b981', CRM_UPDATE: '#14b8a6', HUMAN_AGENT: '#ef4444', API_CALL: '#475569',
  };
  return { borderRadius: 10, border: `2px solid ${palette[type] ?? '#94a3b8'}`, padding: 8, fontSize: 12, background: '#fff' };
}
