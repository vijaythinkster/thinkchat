'use client';

import { useEffect, useState } from 'react';
import { flowsApi } from '@/lib/flows-api';
import type { Flow } from '@/types/flows';

const TONE: Record<string, string> = {
  PUBLISHED: 'bg-emerald-100 text-emerald-700',
  DRAFT: 'bg-slate-100 text-slate-500',
  ARCHIVED: 'bg-slate-100 text-slate-400',
};

export function FlowList({ onOpen }: { onOpen?: (id: string) => void }) {
  const [items, setItems] = useState<Flow[]>([]);
  useEffect(() => { flowsApi.list().then(setItems).catch(() => setItems([])); }, []);

  return (
    <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
      <table className="w-full text-sm">
        <thead className="bg-slate-50 text-left text-xs uppercase tracking-wide text-slate-500">
          <tr><th className="px-4 py-3">Flow</th><th className="px-4 py-3">Trigger</th><th className="px-4 py-3">Status</th></tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {items.map((f) => (
            <tr key={f.id} className="cursor-pointer hover:bg-slate-50" onClick={() => onOpen?.(f.id)}>
              <td className="px-4 py-3 font-medium text-slate-900">{f.name}</td>
              <td className="px-4 py-3 text-slate-600">{f.trigger?.type ?? '—'}</td>
              <td className="px-4 py-3">
                <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${TONE[f.status]}`}>{f.status}</span>
              </td>
            </tr>
          ))}
          {items.length === 0 ? <tr><td colSpan={3} className="px-4 py-8 text-center text-slate-400">No flows yet</td></tr> : null}
        </tbody>
      </table>
    </div>
  );
}
