'use client';
import { useEffect, useRef } from 'react';
import { Clock } from 'lucide-react';
import type { Conversation, Message } from '@/types/inbox';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MessageBubble } from './message-bubble';
import { Composer } from './composer';
import { cn, fullName, initials } from '@/lib/utils';

interface Props {
  conversation: Conversation;
  messages: Message[];
  onSend: (text: string) => void;
  onResolve: () => void;
}

function windowLabel(iso: string | null): { text: string; expired: boolean } {
  if (!iso) return { text: 'No active session', expired: true };
  const ms = new Date(iso).getTime() - Date.now();
  if (ms <= 0) return { text: 'Session window closed', expired: true };
  const h = Math.floor(ms / 3.6e6);
  const m = Math.floor((ms % 3.6e6) / 6e4);
  return { text: `Service window · ${h}h ${m}m left`, expired: false };
}

export function ChatThread({ conversation, messages, onSend, onResolve }: Props) {
  const endRef = useRef<HTMLDivElement>(null);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages.length]);

  const c = conversation.contact;
  const win = windowLabel(conversation.windowExpiresAt);

  return (
    <section className="flex h-full min-w-0 flex-1 flex-col">
      <header className="flex items-center gap-2 border-b px-3 py-2.5">
        <Avatar className="h-8 w-8"><AvatarFallback className="text-[11px]">{initials(c.name, c.phone)}</AvatarFallback></Avatar>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium">{c.name ?? c.phone}</p>
          <p className="text-[11px] text-muted-foreground">{c.phone}</p>
        </div>
        <Badge variant="secondary" className="text-[11px] capitalize">{conversation.status.toLowerCase()}</Badge>
        <span className="hidden text-[11px] text-muted-foreground md:inline">{fullName(conversation.assignedAgent?.user)}</span>
        <Button size="sm" variant="outline" className="h-7 text-xs" onClick={onResolve}>Resolve</Button>
      </header>

      <div className="flex-1 space-y-2.5 overflow-y-auto bg-muted/20 p-3">
        <div className="flex justify-center">
          <span className={cn(
            'inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px]',
            win.expired
              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-200'
              : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-200',
          )}>
            <Clock className="h-3 w-3" /> {win.text}
          </span>
        </div>
        {messages.map((m) => <MessageBubble key={m.id} message={m} />)}
        <div ref={endRef} />
      </div>

      <Composer windowExpired={win.expired} onSend={onSend} />
    </section>
  );
}
