'use client';
import { useState } from 'react';
import { Bolt, Paperclip, SendHorizontal, LayoutTemplate } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Props {
  disabled?: boolean;
  windowExpired?: boolean;
  onSend: (text: string) => void;
  onTyping?: () => void;
}

export function Composer({ disabled, windowExpired, onSend, onTyping }: Props) {
  const [text, setText] = useState('');

  const submit = () => {
    const value = text.trim();
    if (!value) return;
    onSend(value);
    setText('');
  };

  return (
    <div className="border-t p-2">
      {windowExpired && (
        <p className="px-2 pb-1 text-[11px] text-amber-600">
          Outside the 24h window — only approved templates can be sent.
        </p>
      )}
      <div className="flex items-end gap-2">
        <Button variant="ghost" size="icon" className="h-9 w-9 shrink-0" aria-label="Attach">
          <Paperclip className="h-[18px] w-[18px]" />
        </Button>
        <Button variant="ghost" size="icon" className="h-9 w-9 shrink-0" aria-label="Templates">
          <LayoutTemplate className="h-[18px] w-[18px]" />
        </Button>
        <Button variant="ghost" size="icon" className="h-9 w-9 shrink-0" aria-label="Saved replies">
          <Bolt className="h-[18px] w-[18px]" />
        </Button>
        <textarea
          value={text}
          disabled={disabled}
          onChange={(e) => { setText(e.target.value); onTyping?.(); }}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submit(); }
          }}
          rows={1}
          placeholder="Type a message, or / for saved replies"
          className="max-h-32 min-h-9 flex-1 resize-none rounded-2xl border bg-muted px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring"
        />
        <Button size="icon" className="h-9 w-9 shrink-0 rounded-full" onClick={submit} disabled={disabled || !text.trim()} aria-label="Send">
          <SendHorizontal className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
