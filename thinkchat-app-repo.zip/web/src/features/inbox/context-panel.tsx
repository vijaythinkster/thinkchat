'use client';
import { Code, ListChecks, StickyNote, UserPlus } from 'lucide-react';
import type { Conversation } from '@/types/inbox';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { initials } from '@/lib/utils';

export function ContextPanel({ conversation }: { conversation: Conversation }) {
  const c = conversation.contact;
  return (
    <aside className="flex h-full w-[200px] shrink-0 flex-col gap-4 border-l bg-muted/30 p-3.5">
      <div className="flex flex-col items-center gap-1 text-center">
        <Avatar className="h-12 w-12">
          <AvatarFallback className="text-base">{initials(c.name, c.phone)}</AvatarFallback>
        </Avatar>
        <p className="font-medium">{c.name ?? c.phone}</p>
        <p className="text-[11px] text-muted-foreground">{c.phone}</p>
        {c.email && <p className="text-[11px] text-sky-600">{c.email}</p>}
      </div>

      {conversation.conversationLabels?.length ? (
        <div>
          <p className="mb-1.5 text-[11px] text-muted-foreground">Labels</p>
          <div className="flex flex-wrap gap-1.5">
            {conversation.conversationLabels.map((cl) => (
              <Badge key={cl.label.id} variant="secondary" className="text-[11px]">{cl.label.name}</Badge>
            ))}
          </div>
        </div>
      ) : null}

      <div>
        <p className="mb-1.5 text-[11px] text-muted-foreground">CRM</p>
        <div className="space-y-1 text-xs">
          <div className="flex justify-between"><span className="text-muted-foreground">Stage</span><span>Qualified</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">Deal</span><span>—</span></div>
        </div>
      </div>

      <div className="mt-auto space-y-1.5">
        <Button variant="outline" size="sm" className="w-full justify-start gap-2 text-xs">
          <StickyNote className="h-4 w-4" /> Add note
        </Button>
        <Button variant="outline" size="sm" className="w-full justify-start gap-2 text-xs">
          <ListChecks className="h-4 w-4" /> Create task
        </Button>
        <Button variant="outline" size="sm" className="w-full justify-start gap-2 text-xs">
          <UserPlus className="h-4 w-4" /> Assign
        </Button>
      </div>
    </aside>
  );
}
