'use client';
import { Search, SquarePen } from 'lucide-react';
import type { Conversation, ConversationStatus } from '@/types/inbox';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { cn, initials } from '@/lib/utils';

type Filter = 'OPEN' | 'PENDING' | 'MINE';

interface Props {
  conversations: Conversation[];
  selectedId: string | null;
  filter: Filter;
  onFilter: (f: Filter) => void;
  onSelect: (id: string) => void;
}

const FILTERS: { key: Filter; label: string }[] = [
  { key: 'OPEN', label: 'Open' },
  { key: 'PENDING', label: 'Pending' },
  { key: 'MINE', label: 'Mine' },
];

function relativeTime(iso: string | null): string {
  if (!iso) return '';
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.round(diff / 60000);
  if (m < 1) return 'now';
  if (m < 60) return `${m}m`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h}h`;
  return `${Math.round(h / 24)}d`;
}

export function ConversationList({ conversations, selectedId, filter, onFilter, onSelect }: Props) {
  return (
    <aside className="flex h-full flex-col border-r">
      <div className="space-y-2.5 p-3">
        <div className="flex items-center justify-between">
          <h2 className="text-[15px] font-medium">Team inbox</h2>
          <SquarePen className="h-[18px] w-[18px] text-muted-foreground" aria-hidden />
        </div>
        <div className="flex items-center gap-2 rounded-md bg-muted px-2.5 py-1.5">
          <Search className="h-4 w-4 text-muted-foreground" aria-hidden />
          <span className="text-xs text-muted-foreground">Search conversations</span>
        </div>
        <div className="flex gap-1.5">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              onClick={() => onFilter(f.key)}
              className={cn(
                'rounded-full px-2.5 py-1 text-xs',
                filter === f.key ? 'bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-200' : 'bg-muted text-muted-foreground',
              )}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 space-y-0.5 overflow-y-auto px-2 pb-2">
        {conversations.map((c) => {
          const last = c.messages?.[0];
          return (
            <button
              key={c.id}
              onClick={() => onSelect(c.id)}
              className={cn(
                'flex w-full items-start gap-2.5 rounded-md border border-transparent p-2.5 text-left hover:bg-muted',
                selectedId === c.id && 'border-border bg-muted',
              )}
            >
              <Avatar className="h-9 w-9">
                <AvatarFallback className="text-xs">{initials(c.contact.name, c.contact.phone)}</AvatarFallback>
              </Avatar>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <span className="truncate text-sm font-medium">{c.contact.name ?? c.contact.phone}</span>
                  <span className="shrink-0 text-[11px] text-muted-foreground">{relativeTime(c.lastMessageAt)}</span>
                </div>
                <p className="truncate text-xs text-muted-foreground">{last?.body ?? 'No messages yet'}</p>
              </div>
              {c.unreadCount > 0 && (
                <span className="mt-1 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-emerald-500 px-1 text-[11px] font-medium text-white">
                  {c.unreadCount}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </aside>
  );
}
