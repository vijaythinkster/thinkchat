'use client';
import { useCallback, useEffect, useState } from 'react';
import { Briefcase, Inbox, Megaphone, Settings, Users, Workflow } from 'lucide-react';
import type { Conversation, ConversationStatus, Message } from '@/types/inbox';
import { inboxApi } from '@/lib/api-client';
import { useInboxSocket } from '@/hooks/use-inbox-socket';
import { ConversationList } from './conversation-list';
import { ChatThread } from './chat-thread';
import { ContextPanel } from './context-panel';

type Filter = 'OPEN' | 'PENDING' | 'MINE';
const RAIL = [Inbox, Users, Megaphone, Workflow, Briefcase];

export function InboxShell({ initial }: { initial: Conversation[] }) {
  const [conversations, setConversations] = useState<Conversation[]>(initial);
  const [filter, setFilter] = useState<Filter>('OPEN');
  const [selectedId, setSelectedId] = useState<string | null>(initial[0]?.id ?? null);
  const [messages, setMessages] = useState<Message[]>([]);

  const selected = conversations.find((c) => c.id === selectedId) ?? null;

  // Refetch the list whenever the filter changes (and on mount).
  useEffect(() => {
    const params = filter === 'MINE' ? { assigneeId: 'me' } : { status: filter as ConversationStatus };
    inboxApi.listConversations(params).then((r) => setConversations(r.items)).catch(() => {});
  }, [filter]);

  const loadThread = useCallback(async (id: string) => {
    const { messages: msgs } = await inboxApi.getThread(id);
    setMessages(msgs);
    setConversations((prev) => prev.map((c) => (c.id === id ? { ...c, unreadCount: 0 } : c)));
  }, []);

  useEffect(() => { if (selectedId) loadThread(selectedId); }, [selectedId, loadThread]);

  const { openConversation } = useInboxSocket({
    onNewMessage: (m) => {
      setConversations((prev) => {
        const idx = prev.findIndex((c) => c.id === m.conversationId);
        if (idx === -1) return prev; // brand-new conversation: a fuller impl refetches
        const updated: Conversation = {
          ...prev[idx],
          lastMessageAt: m.createdAt,
          messages: [m],
          unreadCount: m.conversationId === selectedId ? 0 : prev[idx].unreadCount + (m.direction === 'INBOUND' ? 1 : 0),
        };
        return [updated, ...prev.filter((_, i) => i !== idx)];
      });
      if (m.conversationId === selectedId) {
        setMessages((prev) => (prev.some((x) => x.id === m.id) ? prev : [...prev, m]));
      }
    },
    onStatus: ({ waMessageId, status }) => {
      setMessages((prev) => prev.map((m) => (m.waMessageId === waMessageId ? { ...m, status: status as Message['status'] } : m)));
    },
  });

  useEffect(() => { if (selectedId) openConversation(selectedId); }, [selectedId, openConversation]);

  const handleSend = async (text: string) => {
    if (!selectedId) return;
    const clientRef = crypto.randomUUID();
    const optimistic: Message = {
      id: `tmp-${clientRef}`, conversationId: selectedId, direction: 'OUTBOUND',
      type: 'TEXT', status: 'QUEUED', body: text, createdAt: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, optimistic]);
    try {
      const saved = await inboxApi.sendText(selectedId, text, clientRef);
      setMessages((prev) => prev.map((m) => (m.id === optimistic.id ? saved : m)));
    } catch {
      setMessages((prev) => prev.map((m) => (m.id === optimistic.id ? { ...m, status: 'FAILED' } : m)));
    }
  };

  const handleResolve = async () => {
    if (!selectedId) return;
    await inboxApi.resolve(selectedId, 'RESOLVED');
    setConversations((prev) => prev.map((c) => (c.id === selectedId ? { ...c, status: 'RESOLVED' } : c)));
  };

  return (
    <div className="grid h-screen grid-cols-[44px_300px_1fr_auto] overflow-hidden border bg-background">
      <nav className="flex flex-col items-center gap-1.5 border-r bg-muted/40 py-3">
        {RAIL.map((Icon, i) => (
          <button
            key={i}
            aria-label={`nav ${i}`}
            className={
              'flex h-8 w-8 items-center justify-center rounded-md ' +
              (i === 0 ? 'bg-sky-100 text-sky-700 dark:bg-sky-950 dark:text-sky-200' : 'text-muted-foreground hover:bg-muted')
            }
          >
            <Icon className="h-5 w-5" />
          </button>
        ))}
        <button aria-label="settings" className="mt-auto flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:bg-muted">
          <Settings className="h-5 w-5" />
        </button>
      </nav>

      <ConversationList
        conversations={conversations}
        selectedId={selectedId}
        filter={filter}
        onFilter={setFilter}
        onSelect={setSelectedId}
      />

      {selected ? (
        <ChatThread conversation={selected} messages={messages} onSend={handleSend} onResolve={handleResolve} />
      ) : (
        <div className="flex flex-1 items-center justify-center text-sm text-muted-foreground">
          Select a conversation
        </div>
      )}

      {selected && <ContextPanel conversation={selected} />}
    </div>
  );
}
