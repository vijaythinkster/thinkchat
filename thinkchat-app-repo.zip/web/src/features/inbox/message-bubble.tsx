import { Check, CheckCheck, Clock } from 'lucide-react';
import type { Message } from '@/types/inbox';
import { cn } from '@/lib/utils';

function StatusTick({ status }: { status: Message['status'] }) {
  switch (status) {
    case 'READ': return <CheckCheck className="h-3.5 w-3.5 text-sky-500" aria-label="read" />;
    case 'DELIVERED': return <CheckCheck className="h-3.5 w-3.5 text-muted-foreground" aria-label="delivered" />;
    case 'SENT': return <Check className="h-3.5 w-3.5 text-muted-foreground" aria-label="sent" />;
    case 'QUEUED': return <Clock className="h-3 w-3 text-muted-foreground" aria-label="queued" />;
    case 'FAILED': return <span className="text-[10px] text-red-500">failed</span>;
    default: return null;
  }
}

export function MessageBubble({ message }: { message: Message }) {
  const outbound = message.direction === 'OUTBOUND';
  const time = new Date(message.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return (
    <div className={cn('flex', outbound ? 'justify-end' : 'justify-start')}>
      <div className="max-w-[78%]">
        <div
          className={cn(
            'whitespace-pre-wrap break-words px-3 py-2 text-sm leading-relaxed',
            outbound
              ? 'rounded-2xl rounded-tr-sm bg-emerald-50 text-emerald-950 dark:bg-emerald-950/40 dark:text-emerald-50'
              : 'rounded-2xl rounded-tl-sm border bg-background',
          )}
        >
          {message.body ?? <span className="italic text-muted-foreground">[{message.type.toLowerCase()}]</span>}
        </div>
        <div
          className={cn(
            'mt-0.5 flex items-center gap-1 text-[10px] text-muted-foreground',
            outbound ? 'justify-end' : 'justify-start',
          )}
        >
          {message.type === 'TEMPLATE' && <span>template ·</span>}
          <span>{time}</span>
          {outbound && <StatusTick status={message.status} />}
        </div>
      </div>
    </div>
  );
}
