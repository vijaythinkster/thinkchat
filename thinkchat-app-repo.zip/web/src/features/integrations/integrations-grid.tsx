'use client';

import { useEffect, useState } from 'react';
import { integrationsApi, webhookUrl } from '@/lib/integrations-api';
import {
  IntegrationView,
  PROVIDER_META,
  type IntegrationProvider,
} from '@/types/integrations';

const KIND_LABEL: Record<string, string> = {
  INBOUND_LEAD: 'Lead capture',
  OUTBOUND_CRM: 'CRM sync',
  BRIDGE: 'Automation bridge',
};

const STATUS_STYLE: Record<string, string> = {
  CONNECTED: 'bg-green-100 text-green-700',
  ERROR: 'bg-red-100 text-red-700',
  DISCONNECTED: 'bg-gray-100 text-gray-500',
};

export function IntegrationsGrid({ organizationId }: { organizationId: string }) {
  const [items, setItems] = useState<IntegrationView[]>([]);
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState<IntegrationProvider | null>(null);

  const load = async () => {
    setLoading(true);
    try {
      setItems(await integrationsApi.list());
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    void load();
  }, []);

  if (loading) return <div className="p-6 text-sm text-gray-500">Loading integrations…</div>;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((it) => {
          const meta = PROVIDER_META[it.provider];
          return (
            <button
              key={it.provider}
              onClick={() => setActive(it.provider)}
              className="rounded-xl border border-gray-200 bg-white p-4 text-left transition hover:border-gray-300 hover:shadow-sm"
            >
              <div className="flex items-center justify-between">
                <span className="font-medium text-gray-900">{meta.label}</span>
                <span className={`rounded-full px-2 py-0.5 text-xs ${STATUS_STYLE[it.status]}`}>
                  {it.status.toLowerCase()}
                </span>
              </div>
              <p className="mt-1 text-sm text-gray-500">{meta.blurb}</p>
              <span className="mt-3 inline-block text-xs text-gray-400">{KIND_LABEL[it.kind]}</span>
            </button>
          );
        })}
      </div>

      {active && (
        <ConnectDrawer
          provider={active}
          organizationId={organizationId}
          view={items.find((i) => i.provider === active)!}
          onClose={() => setActive(null)}
          onChanged={load}
        />
      )}
    </div>
  );
}

function ConnectDrawer({
  provider,
  organizationId,
  view,
  onClose,
  onChanged,
}: {
  provider: IntegrationProvider;
  organizationId: string;
  view: IntegrationView;
  onClose: () => void;
  onChanged: () => void;
}) {
  const meta = PROVIDER_META[provider];
  const [creds, setCreds] = useState<Record<string, string>>({});
  const [fieldMap, setFieldMap] = useState('');
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const isInbound = view.kind !== 'OUTBOUND_CRM';

  const save = async () => {
    setBusy(true);
    setMsg(null);
    try {
      let config: Record<string, unknown> = {};
      if (fieldMap.trim()) {
        try {
          config = { fieldMap: JSON.parse(fieldMap) };
        } catch {
          setMsg('Field map must be valid JSON.');
          setBusy(false);
          return;
        }
      }
      const { test } = await integrationsApi.connect(provider, { credentials: creds, config });
      setMsg(test.ok ? `Connected. ${test.detail ?? ''}` : `Problem: ${test.detail ?? 'failed'}`);
      onChanged();
    } finally {
      setBusy(false);
    }
  };

  const disconnect = async () => {
    setBusy(true);
    try {
      await integrationsApi.disconnect(provider);
      onChanged();
      onClose();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-40 flex justify-end bg-black/30" onClick={onClose}>
      <div
        className="h-full w-full max-w-md overflow-y-auto bg-white p-6 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">{meta.label}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">✕</button>
        </div>
        <p className="mt-1 text-sm text-gray-500">{meta.blurb}</p>

        {isInbound && (
          <div className="mt-4 rounded-lg bg-gray-50 p-3">
            <div className="text-xs font-medium text-gray-500">Webhook URL — paste into {meta.label}</div>
            <code className="mt-1 block break-all text-xs text-gray-800">
              {webhookUrl(provider, organizationId)}
            </code>
          </div>
        )}

        <div className="mt-4 space-y-3">
          {meta.credentialFields.map((f) => (
            <div key={f}>
              <label className="text-xs font-medium text-gray-600">{f}</label>
              <input
                type="password"
                autoComplete="off"
                value={creds[f] ?? ''}
                onChange={(e) => setCreds((c) => ({ ...c, [f]: e.target.value }))}
                className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm"
                placeholder={`Enter ${f}`}
              />
            </div>
          ))}

          {meta.configHint && (
            <div>
              <label className="text-xs font-medium text-gray-600">Field map (JSON)</label>
              <textarea
                value={fieldMap}
                onChange={(e) => setFieldMap(e.target.value)}
                rows={3}
                className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 font-mono text-xs"
                placeholder='{"name":"full_name","phone":"phone_number","email":"email"}'
              />
              <p className="mt-1 text-xs text-gray-400">{meta.configHint}</p>
            </div>
          )}
        </div>

        {msg && <p className="mt-3 text-sm text-gray-700">{msg}</p>}

        <div className="mt-6 flex gap-2">
          <button
            onClick={save}
            disabled={busy}
            className="rounded-md bg-gray-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
          >
            {view.connected ? 'Update' : 'Connect'}
          </button>
          {view.connected && (
            <button
              onClick={disconnect}
              disabled={busy}
              className="rounded-md border border-gray-300 px-4 py-2 text-sm text-gray-700 disabled:opacity-50"
            >
              Disconnect
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
