'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { whatsappApi, type ConnectedNumber } from '@/lib/whatsapp-api';

/**
 * WhatsApp Embedded Signup ("Connect WhatsApp Business" button).
 *
 * Flow:
 *  1. Load Meta's Facebook JS SDK (only on this page).
 *  2. On click, FB.login() opens Meta's popup with our signup `config_id`.
 *  3. Two things come back, independently and racily:
 *       - `code`  from the FB.login callback (response.authResponse.code)
 *       - `waba_id` + `phone_number_id` from a `message` event of type WA_EMBEDDED_SIGNUP
 *     We stash both in refs and fire completion once BOTH are present.
 *  4. POST {code, wabaId, phoneNumberId} to the backend, which exchanges the code
 *     for a token, subscribes our app to the WABA, registers the number, and stores it.
 *
 * Verbose console logging is intentional — it is the diagnostic trail for the
 * notorious "session info never returns" failure mode.
 */

declare global {
  interface Window {
    FB?: any;
    fbAsyncInit?: () => void;
  }
}

const APP_ID = process.env.NEXT_PUBLIC_META_APP_ID ?? '';
const CONFIG_ID = process.env.NEXT_PUBLIC_META_CONFIG_ID ?? '';
const GRAPH_VERSION = process.env.NEXT_PUBLIC_META_GRAPH_VERSION ?? 'v21.0';

type Status = 'idle' | 'loading-sdk' | 'ready' | 'launching' | 'completing' | 'success' | 'error';

let sdkPromise: Promise<void> | null = null;

/** Loads + inits the FB SDK exactly once across the app. */
function loadFbSdk(): Promise<void> {
  if (typeof window === 'undefined') return Promise.resolve();
  if (window.FB) return Promise.resolve();
  if (sdkPromise) return sdkPromise;

  sdkPromise = new Promise<void>((resolve, reject) => {
    window.fbAsyncInit = function () {
      window.FB.init({
        appId: APP_ID,
        autoLogAppEvents: true,
        xfbml: false,
        version: GRAPH_VERSION,
      });
      console.log('[WA Signup] FB SDK initialised', { appId: APP_ID, version: GRAPH_VERSION });
      resolve();
    };

    const id = 'facebook-jssdk';
    if (document.getElementById(id)) return; // script tag already present
    const script = document.createElement('script');
    script.id = id;
    script.async = true;
    script.defer = true;
    script.crossOrigin = 'anonymous';
    script.src = 'https://connect.facebook.net/en_US/sdk.js';
    script.onerror = () => reject(new Error('Failed to load Facebook SDK'));
    document.body.appendChild(script);
  });

  return sdkPromise;
}

export function ConnectWhatsApp() {
  const [status, setStatus] = useState<Status>('idle');
  const [error, setError] = useState<string | null>(null);
  const [connected, setConnected] = useState<ConnectedNumber | null>(null);

  // Race-safe holders for the two independent pieces of the signup result.
  const codeRef = useRef<string | null>(null);
  const sessionRef = useRef<{ wabaId: string; phoneNumberId: string } | null>(null);
  const completedRef = useRef(false);

  const configured = Boolean(APP_ID && CONFIG_ID);

  // Load the SDK on mount.
  useEffect(() => {
    if (!configured) return;
    setStatus('loading-sdk');
    loadFbSdk()
      .then(() => setStatus('ready'))
      .catch((e) => {
        console.error('[WA Signup] SDK load failed', e);
        setError('Could not load the Meta login SDK. Check your connection and retry.');
        setStatus('error');
      });
  }, [configured]);

  const tryComplete = useCallback(async () => {
    if (completedRef.current) return;
    const code = codeRef.current;
    const session = sessionRef.current;
    if (!code || !session) return; // wait for the other half

    completedRef.current = true;
    setStatus('completing');
    console.log('[WA Signup] Completing onboarding', { ...session, codeLength: code.length });
    try {
      const number = await whatsappApi.completeOnboarding({
        code,
        wabaId: session.wabaId,
        phoneNumberId: session.phoneNumberId,
      });
      console.log('[WA Signup] Connected', number);
      setConnected(number);
      setStatus('success');
    } catch (e: any) {
      console.error('[WA Signup] Backend onboarding failed', e);
      setError(e?.message ?? 'Onboarding failed on the server. See console for details.');
      setStatus('error');
      completedRef.current = false; // allow retry
    }
  }, []);

  // Listen for the signup popup's session-info messages.
  useEffect(() => {
    if (!configured) return;

    const handler = (event: MessageEvent) => {
      if (
        event.origin !== 'https://www.facebook.com' &&
        event.origin !== 'https://web.facebook.com'
      ) {
        return;
      }
      let data: any;
      try {
        data = typeof event.data === 'string' ? JSON.parse(event.data) : event.data;
      } catch {
        return; // not JSON, not ours
      }
      if (!data || data.type !== 'WA_EMBEDDED_SIGNUP') return;

      console.log('[WA Signup] WA_EMBEDDED_SIGNUP event', data);

      if (data.event === 'FINISH' || data.event === 'FINISH_ONLY_WABA') {
        const wabaId = data.data?.waba_id;
        const phoneNumberId = data.data?.phone_number_id;
        if (wabaId && phoneNumberId) {
          sessionRef.current = { wabaId, phoneNumberId };
          void tryComplete();
        } else {
          console.warn('[WA Signup] FINISH event missing ids', data.data);
          setError(
            'Signup finished but Meta did not return the WhatsApp account IDs. ' +
              'This is usually a config_id / permissions issue — share the console log.',
          );
          setStatus('error');
        }
      } else if (data.event === 'CANCEL') {
        console.warn('[WA Signup] User cancelled at step:', data.data?.current_step);
        setError('Signup was cancelled before finishing.');
        setStatus('ready');
      } else if (data.event === 'ERROR') {
        console.error('[WA Signup] Popup error', data.data);
        setError(data.data?.error_message ?? 'Meta reported an error during signup.');
        setStatus('error');
      }
    };

    window.addEventListener('message', handler);
    return () => window.removeEventListener('message', handler);
  }, [configured, tryComplete]);

  const launch = useCallback(() => {
    if (!window.FB) {
      setError('Meta SDK not ready yet — give it a moment and retry.');
      return;
    }
    // Reset for a fresh attempt.
    codeRef.current = null;
    sessionRef.current = null;
    completedRef.current = false;
    setError(null);
    setStatus('launching');

    window.FB.login(
      (response: any) => {
        console.log('[WA Signup] FB.login response', response);
        if (response?.authResponse?.code) {
          codeRef.current = response.authResponse.code;
          void tryComplete();
        } else {
          // No code => user closed the popup or denied. The message listener
          // may already have set an error/cancel state; only set if still launching.
          setStatus((s) => {
            if (s === 'launching') {
              setError('Login was closed before granting access.');
              return 'ready';
            }
            return s;
          });
        }
      },
      {
        config_id: CONFIG_ID,
        response_type: 'code',
        override_default_response_type: true,
        extras: {
          setup: {},
          featureType: '',
          sessionInfoVersion: '3',
        },
      },
    );
  }, [tryComplete]);

  // ---- Render ----

  if (!configured) {
    return (
      <div className="rounded-xl border border-dashed border-border bg-card p-5">
        <h3 className="text-sm font-semibold text-foreground">Connect WhatsApp Business</h3>
        <p className="mt-1 text-sm text-muted-foreground">
          Embedded Signup isn’t configured yet. The Meta App ID and signup configuration ID
          need to be set before the connect button can appear.
        </p>
      </div>
    );
  }

  if (status === 'success' && connected) {
    return (
      <div className="rounded-xl border border-border bg-card p-5">
        <div className="flex items-center gap-3">
          <span className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-primary">✓</span>
          <div>
            <h3 className="text-sm font-semibold text-foreground">WhatsApp connected</h3>
            <p className="text-sm text-muted-foreground">
              {connected.verifiedName ? `${connected.verifiedName} · ` : ''}
              {connected.displayPhone}
            </p>
          </div>
        </div>
        <p className="mt-3 text-xs text-muted-foreground">
          Templates are syncing in the background. You can now send and receive messages in the Inbox.
        </p>
      </div>
    );
  }

  const busy = status === 'launching' || status === 'completing' || status === 'loading-sdk';
  const label =
    status === 'loading-sdk' ? 'Loading…' :
    status === 'launching' ? 'Waiting for Meta…' :
    status === 'completing' ? 'Connecting…' :
    'Connect WhatsApp Business';

  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h3 className="text-sm font-semibold text-foreground">Connect WhatsApp Business</h3>
          <p className="mt-1 text-sm text-muted-foreground">
            Sign in with Meta to connect a WhatsApp Business number. You can pick an existing
            number or create a new one — no codes to copy.
          </p>
        </div>
        <button
          type="button"
          onClick={launch}
          disabled={busy}
          className="inline-flex shrink-0 items-center justify-center rounded-lg bg-primary px-4 py-2 text-sm font-medium text-white transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {label}
        </button>
      </div>

      {error && (
        <p className="mt-3 rounded-lg bg-red-50 px-3 py-2 text-xs text-red-700">{error}</p>
      )}
    </div>
  );
}
