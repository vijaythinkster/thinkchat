'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { authApi } from '@/lib/auth-api';
import { apiFetch } from '@/lib/http';
import {
  clearSession, getRefreshToken, getStoredUser, isAuthenticated, setSession, SessionUser,
} from '@/lib/auth';

interface MeResponse { user: SessionUser | null; roles: string[]; permissions: string[] }

interface AuthState {
  user: SessionUser | null;
  permissions: string[];
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (dto: { organizationName: string; email: string; password: string; firstName?: string; lastName?: string }) => Promise<void>;
  logout: () => Promise<void>;
  can: (permission: string) => boolean;
}

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [user, setUser] = useState<SessionUser | null>(null);
  const [permissions, setPermissions] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  // Hydrate from storage, then confirm with the server (also refreshes perms).
  useEffect(() => {
    let active = true;
    setUser(getStoredUser());
    if (!isAuthenticated()) { setLoading(false); return; }
    apiFetch<MeResponse>('/auth/me')
      .then((me) => { if (!active) return; setUser(me.user); setPermissions(me.permissions ?? []); })
      .catch(() => { if (active) { setUser(null); setPermissions([]); } })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    const r = await authApi.login(email, password);
    setSession({ accessToken: r.accessToken, refreshToken: r.refreshToken, user: r.user });
    setUser(r.user);
    const me = await apiFetch<MeResponse>('/auth/me').catch(() => null);
    setPermissions(me?.permissions ?? []);
    router.push('/inbox');
  }, [router]);

  const register = useCallback(async (dto: Parameters<AuthState['register']>[0]) => {
    const r = await authApi.register(dto);
    setSession({ accessToken: r.accessToken, refreshToken: r.refreshToken, user: r.user });
    setUser(r.user);
    const me = await apiFetch<MeResponse>('/auth/me').catch(() => null);
    setPermissions(me?.permissions ?? []);
    router.push('/inbox');
  }, [router]);

  const logout = useCallback(async () => {
    const rt = getRefreshToken();
    if (rt) await authApi.logout(rt).catch(() => undefined);
    clearSession();
    setUser(null); setPermissions([]);
    router.push('/login');
  }, [router]);

  const can = useCallback((p: string) => permissions.includes(p), [permissions]);

  const value = useMemo<AuthState>(
    () => ({ user, permissions, loading, login, register, logout, can }),
    [user, permissions, loading, login, register, logout, can],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within <AuthProvider>');
  return ctx;
}
