'use client';
import { useEffect, useRef } from 'react';
import { io, type Socket } from 'socket.io-client';
import { getAccessToken } from '@/lib/auth';
import type { Message } from '@/types/inbox';

const WS_URL = process.env.NEXT_PUBLIC_WS_URL ?? 'http://localhost:4000';

interface Handlers {
  onNewMessage?: (message: Message) => void;
  onStatus?: (p: { waMessageId: string; status: string }) => void;
  onTyping?: (p: { conversationId: string; userId: string }) => void;
}

/**
 * Connects to the /inbox namespace, authenticating with the JWT. The server
 * scopes events to the tenant room, so the client just reacts to what arrives.
 */
export function useInboxSocket(handlers: Handlers) {
  const socketRef = useRef<Socket | null>(null);
  const handlersRef = useRef(handlers);
  handlersRef.current = handlers;

  useEffect(() => {
    const socket = io(`${WS_URL}/inbox`, {
      auth: { token: getAccessToken() },
      transports: ['websocket'],
    });
    socketRef.current = socket;

    socket.on('message:new', (m: Message) => handlersRef.current.onNewMessage?.(m));
    socket.on('message:status', (p) => handlersRef.current.onStatus?.(p));
    socket.on('typing', (p) => handlersRef.current.onTyping?.(p));

    return () => {
      socket.disconnect();
      socketRef.current = null;
    };
  }, []);

  const openConversation = (conversationId: string) =>
    socketRef.current?.emit('conversation:open', { conversationId });
  const emitTyping = (conversationId: string) =>
    socketRef.current?.emit('typing', { conversationId });

  return { openConversation, emitTyping };
}
