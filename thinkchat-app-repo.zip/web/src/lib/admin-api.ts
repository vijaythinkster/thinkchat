import { apiFetch } from '@/lib/http';
import type {
  AdminUser, AuditRow, CouponRow, OrgDetail, OrgListItem, Paged,
  PlanRow, PlatformOverview, PlatformUsage,
} from '@/types/admin';

const qs = (o: Record<string, unknown>) => {
  const p = new URLSearchParams();
  Object.entries(o).forEach(([k, v]) => { if (v !== undefined && v !== null && v !== '') p.set(k, String(v)); });
  const s = p.toString();
  return s ? `?${s}` : '';
};

export const adminApi = {
  overview: () => apiFetch<PlatformOverview>('/admin/overview'),

  listOrgs: (q: { search?: string; status?: string; cursor?: string; limit?: number } = {}) =>
    apiFetch<Paged<OrgListItem>>(`/admin/organizations${qs(q)}`),
  getOrg: (id: string) => apiFetch<OrgDetail>(`/admin/organizations/${id}`),
  suspendOrg: (id: string, reason?: string) =>
    apiFetch(`/admin/organizations/${id}/suspend`, { method: 'POST', body: JSON.stringify({ reason }) }),
  reactivateOrg: (id: string) =>
    apiFetch(`/admin/organizations/${id}/reactivate`, { method: 'POST' }),
  impersonate: (id: string, userId: string) =>
    apiFetch<{ accessToken: string; expiresIn: number; user: { id: string; email: string } }>(
      `/admin/organizations/${id}/impersonate`, { method: 'POST', body: JSON.stringify({ userId }) }),

  listUsers: (q: { search?: string; organizationId?: string; cursor?: string } = {}) =>
    apiFetch<Paged<AdminUser>>(`/admin/users${qs(q)}`),
  setUserActive: (id: string, isActive: boolean) =>
    apiFetch(`/admin/users/${id}/active`, { method: 'POST', body: JSON.stringify({ isActive }) }),
  setSuperAdmin: (id: string, enabled: boolean) =>
    apiFetch(`/admin/users/${id}/super-admin`, { method: 'POST', body: JSON.stringify({ enabled }) }),

  usage: (q: { from?: string; to?: string } = {}) => apiFetch<PlatformUsage>(`/admin/usage${qs(q)}`),

  listPlans: () => apiFetch<PlanRow[]>('/admin/plans'),
  createPlan: (dto: unknown) => apiFetch<PlanRow>('/admin/plans', { method: 'POST', body: JSON.stringify(dto) }),
  updatePlan: (id: string, dto: unknown) => apiFetch<PlanRow>(`/admin/plans/${id}`, { method: 'PATCH', body: JSON.stringify(dto) }),

  listCoupons: () => apiFetch<CouponRow[]>('/admin/coupons'),
  createCoupon: (dto: unknown) => apiFetch<CouponRow>('/admin/coupons', { method: 'POST', body: JSON.stringify(dto) }),
  updateCoupon: (id: string, dto: unknown) => apiFetch<CouponRow>(`/admin/coupons/${id}`, { method: 'PATCH', body: JSON.stringify(dto) }),

  auditLogs: (q: { organizationId?: string; action?: string; cursor?: string } = {}) =>
    apiFetch<Paged<AuditRow>>(`/admin/audit-logs${qs(q)}`),
};
