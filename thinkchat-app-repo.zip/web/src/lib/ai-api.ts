import type { Assistant, KnowledgeEntry, TestResult } from '@/types/ai';
import { apiFetch as http } from '@/lib/http';

export const aiApi = {
  list() { return http<Assistant[]>('/ai/assistants'); },
  get(id: string) { return http<Assistant>(`/ai/assistants/${id}`); },
  create(body: Partial<Assistant>) {
    return http<Assistant>('/ai/assistants', { method: 'POST', body: JSON.stringify(body) });
  },
  update(id: string, body: Partial<Assistant>) {
    return http<Assistant>(`/ai/assistants/${id}`, { method: 'PATCH', body: JSON.stringify(body) });
  },
  test(id: string, message: string) {
    return http<TestResult>(`/ai/assistants/${id}/test`, { method: 'POST', body: JSON.stringify({ message }) });
  },
  knowledge(id: string) { return http<KnowledgeEntry[]>(`/ai/assistants/${id}/knowledge`); },
  addKnowledge(id: string, body: { name: string; sourceType: string; content?: string; sourceUri?: string }) {
    return http<KnowledgeEntry>(`/ai/assistants/${id}/knowledge`, { method: 'POST', body: JSON.stringify(body) });
  },
  removeKnowledge(id: string, kid: string) {
    return http(`/ai/assistants/${id}/knowledge/${kid}`, { method: 'DELETE' });
  },
};
