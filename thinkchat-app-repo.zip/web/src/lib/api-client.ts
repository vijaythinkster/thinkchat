import type {
  ConversationStatus, ListResponse, Message, ThreadResponse,
} from '@/types/inbox';

import { apiFetch as http } from '@/lib/http';

export const inboxApi = {
  listConversations(params: { status?: ConversationStatus; assigneeId?: string; cursor?: string } = {}) {
    const qs = new URLSearchParams(params as Record<string, string>).toString();
    return http<ListResponse>(`/conversations${qs ? `?${qs}` : ''}`);
  },
  getThread(conversationId: string) {
    return http<ThreadResponse>(`/conversations/${conversationId}/messages`);
  },
  sendText(conversationId: string, text: string, clientRef: string) {
    return http<Message>(`/conversations/${conversationId}/messages`, {
      method: 'POST',
      body: JSON.stringify({ type: 'text', text, clientRef }),
    });
  },
  assign(conversationId: string, dto: AssignDto) {
    return http(`/conversations/${conversationId}/assign`, { method: 'POST', body: JSON.stringify(dto) });
  },
  resolve(conversationId: string, status: ConversationStatus) {
    return http(`/conversations/${conversationId}/resolve`, { method: 'POST', body: JSON.stringify({ status }) });
  },
  addNote(conversationId: string, body: string) {
    return http(`/conversations/${conversationId}/notes`, { method: 'POST', body: JSON.stringify({ body }) });
  },
};
