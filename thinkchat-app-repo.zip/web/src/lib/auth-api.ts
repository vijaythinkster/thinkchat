import type { SessionUser } from '@/lib/auth';

const BASE = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:4000';

export interface AuthResponse {
  accessToken: string; refreshToken: string; expiresIn: number;
  user: SessionUser; organization?: { id: string; name: string };
}

async function post<T>(path: string, body: unknown): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error((await res.text()) || `Auth ${res.status}`);
  return res.json() as Promise<T>;
}

export const authApi = {
  login: (email: string, password: string) => post<AuthResponse>('/auth/login', { email, password }),
  register: (dto: { organizationName: string; email: string; password: string; firstName?: string; lastName?: string }) =>
    post<AuthResponse>('/auth/register', dto),
  refresh: (refreshToken: string) =>
    post<{ accessToken: string; refreshToken: string; expiresIn: number }>('/auth/refresh', { refreshToken }),
  logout: (refreshToken: string) => post<{ ok: boolean }>('/auth/logout', { refreshToken }),
};
