/**
 * Client-side session store. Access token is kept in memory (with a localStorage
 * mirror so it survives reloads) and used for API calls + the socket handshake;
 * the rotating refresh token is persisted to localStorage.
 *
 * Tradeoff: localStorage is simple but XSS-exposed. The harder-security option is
 * to have the backend set the refresh token as an httpOnly cookie; that needs a
 * cookie-based refresh endpoint and SSR token reads. Documented as a follow-up.
 */
const ACCESS = 'access_token';
const REFRESH = 'refresh_token';
const USER = 'auth_user';

export interface SessionUser {
  id: string; email: string;
  firstName?: string | null; lastName?: string | null;
  organizationId: string;
}

let memAccess: string | null = null;

export function getAccessToken(): string {
  if (memAccess) return memAccess;
  if (typeof window === 'undefined') return '';
  return window.localStorage.getItem(ACCESS) ?? '';
}

export function getRefreshToken(): string | null {
  if (typeof window === 'undefined') return null;
  return window.localStorage.getItem(REFRESH);
}

export function setSession(s: { accessToken: string; refreshToken: string; user?: SessionUser }) {
  memAccess = s.accessToken;
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(ACCESS, s.accessToken);
  window.localStorage.setItem(REFRESH, s.refreshToken);
  if (s.user) window.localStorage.setItem(USER, JSON.stringify(s.user));
}

export function getStoredUser(): SessionUser | null {
  if (typeof window === 'undefined') return null;
  const raw = window.localStorage.getItem(USER);
  return raw ? (JSON.parse(raw) as SessionUser) : null;
}

export function clearSession() {
  memAccess = null;
  if (typeof window === 'undefined') return;
  window.localStorage.removeItem(ACCESS);
  window.localStorage.removeItem(REFRESH);
  window.localStorage.removeItem(USER);
}

export function isAuthenticated(): boolean {
  return !!getAccessToken() || !!getRefreshToken();
}
