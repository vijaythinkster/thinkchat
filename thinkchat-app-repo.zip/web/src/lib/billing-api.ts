import type { Invoice, PeriodUsage, Subscription } from '@/types/billing';

import { apiFetch as http } from '@/lib/http';

export const billingApi = {
  usage() { return http<PeriodUsage>('/billing/usage'); },
  subscription() { return http<Subscription | null>('/billing/subscription'); },
  invoices() { return http<Invoice[]>('/billing/invoices'); },
  checkout(invoiceId: string) {
    return http<{ orderId: string; checkoutUrl?: string }>(`/billing/invoices/${invoiceId}/checkout`, { method: 'POST', body: '{}' });
  },
};
