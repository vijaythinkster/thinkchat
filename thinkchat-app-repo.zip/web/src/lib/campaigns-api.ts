import type {
  Campaign, CampaignAnalytics, CreateCampaignInput, SegmentDefinition,
} from '@/types/campaigns';

import { apiFetch as http } from '@/lib/http';

export const campaignsApi = {
  list() {
    return http<Campaign[]>('/campaigns');
  },
  get(id: string) {
    return http<Campaign>(`/campaigns/${id}`);
  },
  analytics(id: string) {
    return http<CampaignAnalytics>(`/campaigns/${id}/analytics`);
  },
  create(input: CreateCampaignInput) {
    return http<Campaign>('/campaigns', { method: 'POST', body: JSON.stringify(input) });
  },
  previewAudience(segment: SegmentDefinition) {
    return http<{ count: number }>('/campaigns/audience-preview', {
      method: 'POST', body: JSON.stringify({ segment }),
    });
  },
  launch(id: string) {
    return http<{ status: string }>(`/campaigns/${id}/launch`, { method: 'POST' });
  },
  schedule(id: string, scheduledAt: string, recurrence?: Record<string, unknown>) {
    return http<{ status: string }>(`/campaigns/${id}/schedule`, {
      method: 'POST', body: JSON.stringify({ scheduledAt, recurrence }),
    });
  },
  pause(id: string) {
    return http<{ status: string }>(`/campaigns/${id}/pause`, { method: 'POST' });
  },
  cancel(id: string) {
    return http<{ status: string }>(`/campaigns/${id}/cancel`, { method: 'POST' });
  },
};
