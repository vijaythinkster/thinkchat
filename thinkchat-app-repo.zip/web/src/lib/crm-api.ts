import type {
  Board, Contact, ContactDetail, ContactList, Deal, Label,
} from '@/types/crm';

import { apiFetch as http } from '@/lib/http';

export const crmApi = {
  listContacts(params: { q?: string; labelId?: string; cursor?: string } = {}) {
    const qs = new URLSearchParams(params as Record<string, string>).toString();
    return http<ContactList>(`/contacts${qs ? `?${qs}` : ''}`);
  },
  getContact(id: string) { return http<ContactDetail>(`/contacts/${id}`); },
  createContact(body: Partial<Contact> & { phone: string }) {
    return http<Contact>('/contacts', { method: 'POST', body: JSON.stringify(body) });
  },
  setLabels(id: string, labelIds: string[]) {
    return http<ContactDetail>(`/contacts/${id}/labels`, { method: 'POST', body: JSON.stringify({ labelIds }) });
  },
  importContacts(rows: Array<Record<string, unknown>>) {
    return http<{ created: number; updated: number; skipped: number; total: number }>(
      '/contacts/import', { method: 'POST', body: JSON.stringify({ rows }) });
  },
  labels() { return http<Label[]>('/labels'); },
  addNote(body: { body: string; contactId?: string; dealId?: string }) {
    return http('/notes', { method: 'POST', body: JSON.stringify(body) });
  },
  board(pipelineId?: string) {
    return http<Board>(`/pipelines/board${pipelineId ? `?pipelineId=${pipelineId}` : ''}`);
  },
  createDeal(body: { title: string; contactId?: string; value?: number; stageId?: string }) {
    return http<Deal>('/deals', { method: 'POST', body: JSON.stringify(body) });
  },
  moveDeal(id: string, stageId: string) {
    return http<Deal>(`/deals/${id}/move`, { method: 'PATCH', body: JSON.stringify({ stageId }) });
  },
};
