import type { Flow, FlowConnection, FlowNode } from '@/types/flows';
import { apiFetch as http } from '@/lib/http';

export const flowsApi = {
  list() { return http<Flow[]>('/flows'); },
  get(id: string) { return http<Flow>(`/flows/${id}`); },
  create(body: { name: string; trigger: Flow['trigger'] }) {
    return http<Flow>('/flows', { method: 'POST', body: JSON.stringify(body) });
  },
  update(id: string, body: Partial<Pick<Flow, 'name' | 'description' | 'trigger' | 'status'>>) {
    return http<Flow>(`/flows/${id}`, { method: 'PUT', body: JSON.stringify(body) });
  },
  saveCanvas(id: string, nodes: FlowNode[], connections: FlowConnection[]) {
    return http<Flow>(`/flows/${id}/canvas`, { method: 'PUT', body: JSON.stringify({ nodes, connections }) });
  },
  publish(id: string) { return http<Flow>(`/flows/${id}/publish`, { method: 'POST' }); },
  archive(id: string) { return http<Flow>(`/flows/${id}/archive`, { method: 'POST' }); },
};
