import { authApi } from '@/lib/auth-api';
import { clearSession, getAccessToken, getRefreshToken, setSession } from '@/lib/auth';

const BASE = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:4000';

// Single in-flight refresh shared across concurrent 401s.
let refreshing: Promise<string | null> | null = null;

function refreshOnce(): Promise<string | null> {
  const rt = getRefreshToken();
  if (!rt) return Promise.resolve(null);
  if (!refreshing) {
    refreshing = authApi.refresh(rt)
      .then((r) => { setSession({ accessToken: r.accessToken, refreshToken: r.refreshToken }); return r.accessToken; })
      .catch(() => { clearSession(); return null; })
      .finally(() => { refreshing = null; });
  }
  return refreshing;
}

function bounceToLogin() {
  clearSession();
  if (typeof window !== 'undefined') window.location.href = '/login';
}

/**
 * Authenticated fetch with reactive refresh: attaches the access token, and on a
 * 401 refreshes once and retries. If refresh fails, the session is cleared and the
 * user is sent to /login.
 */
export async function apiFetch<T>(path: string, init: RequestInit = {}): Promise<T> {
  const call = (token: string | null) =>
    fetch(`${BASE}${path}`, {
      ...init,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
        ...(init.headers ?? {}),
      },
      cache: 'no-store',
    });

  let res = await call(getAccessToken() || null);

  if (res.status === 401) {
    const fresh = await refreshOnce();
    if (!fresh) { bounceToLogin(); throw new Error('Unauthorized'); }
    res = await call(fresh);
    if (res.status === 401) { bounceToLogin(); throw new Error('Unauthorized'); }
  }

  if (!res.ok) throw new Error(`API ${res.status}: ${await res.text()}`);
  const text = await res.text();
  return (text ? JSON.parse(text) : undefined) as T;
}
