import { apiFetch } from '@/lib/http';
import type { IntegrationEvent, IntegrationView, TestResult } from '@/types/integrations';

export const integrationsApi = {
  list: () => apiFetch<IntegrationView[]>('/integrations'),

  connect: (provider: string, body: { credentials?: Record<string, string>; config?: Record<string, unknown> }) =>
    apiFetch<{ view: IntegrationView; test: TestResult }>(`/integrations/${provider}/connect`, {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  test: (provider: string) =>
    apiFetch<TestResult>(`/integrations/${provider}/test`, { method: 'POST' }),

  disconnect: (provider: string) =>
    apiFetch<void>(`/integrations/${provider}`, { method: 'DELETE' }),

  events: (provider: string) => apiFetch<IntegrationEvent[]>(`/integrations/${provider}/events`),
};

/** Inbound providers need this webhook URL pasted into the source platform. */
export function webhookUrl(provider: string, organizationId: string): string {
  const base = process.env.NEXT_PUBLIC_API_URL ?? '';
  return `${base}/webhooks/integrations/${provider.toLowerCase()}/${organizationId}`;
}
