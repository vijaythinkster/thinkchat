import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function initials(name?: string | null, phone?: string): string {
  if (name) {
    const parts = name.trim().split(/\s+/);
    return (parts[0][0] + (parts[1]?.[0] ?? '')).toUpperCase();
  }
  return (phone ?? '?').slice(-2);
}

export function fullName(u?: { firstName: string | null; lastName: string | null } | null): string {
  if (!u) return 'Unassigned';
  return [u.firstName, u.lastName].filter(Boolean).join(' ') || 'Unassigned';
}
