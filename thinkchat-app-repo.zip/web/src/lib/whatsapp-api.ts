import { apiFetch as http } from '@/lib/http';

/** Payload posted after Embedded Signup: code from FB.login + session info from the popup. */
export type CompleteSignupPayload = {
  code: string;
  wabaId: string;
  phoneNumberId: string;
};

export type ConnectedNumber = {
  id: string;
  displayPhone: string;
  verifiedName: string | null;
  qualityRating: string | null;
  status: string;
};

export const whatsappApi = {
  /** Exchanges the Embedded Signup result for a connected, encrypted WhatsApp number. */
  completeOnboarding: (payload: CompleteSignupPayload) =>
    http<ConnectedNumber>('/whatsapp/onboarding/complete', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),
};
