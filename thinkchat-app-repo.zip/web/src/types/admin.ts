export interface PlatformOverview {
  organizations: { total: number; suspended: number; active: number };
  users: number;
  connectedNumbers: number;
  messagesLast30d: number;
  mrr: number;
  revenueThisMonth: number;
  messagingThisMonth: {
    metaCost: number; billed: number; margin: number; marginPct: number; messages: number;
  };
}

export interface OrgListItem {
  id: string; name: string; slug: string;
  createdAt: string; suspendedAt: string | null; deletedAt: string | null;
  counts: { users: number; whatsAppNumbers: number; contacts: number };
  plan: { tier: string; name: string; priceMonthly: number; currency: string } | null;
  subscriptionStatus: string | null;
}

export interface Paged<T> { items: T[]; nextCursor: string | null; }

export interface OrgDetail {
  organization: {
    id: string; name: string; slug: string; parentId: string | null;
    timezone: string; locale: string; createdAt: string;
    suspendedAt: string | null; suspendedReason: string | null; deletedAt: string | null;
  };
  counts: Record<string, number>;
  children: { id: string; name: string; slug: string }[];
  subscriptions: any[];
  numbers: { id: string; displayName: string | null; phoneNumber: string; status: string; qualityRating: string | null }[];
  usageThisMonth: { metaCost: number; billed: number; margin: number; messages: number };
  recentInvoices: { id: string; number: string; status: string; total: string; currency: string; issuedAt: string | null; paidAt: string | null }[];
}

export interface AdminUser {
  id: string; email: string; firstName: string | null; lastName: string | null;
  isActive: boolean; isSuperAdmin: boolean; lastLoginAt: string | null; createdAt: string;
  organization: { id: string; name: string; slug: string };
}

export interface PlatformUsage {
  range: { from: string; to: string };
  byMetric: { metric: string; metaCost: number; billed: number; margin: number; quantity: number }[];
  topOrgsBySpend: { organizationId: string; name: string; metaCost: number; billed: number }[];
}

export interface PlanRow {
  id: string; tier: string; name: string; description: string | null;
  priceMonthly: string; priceYearly: string; currency: string;
  limits: Record<string, unknown>; features: Record<string, unknown>;
  isActive: boolean; _count?: { subscriptions: number };
}

export interface CouponRow {
  id: string; code: string; percentOff: number | null; amountOff: string | null;
  currency: string | null; maxRedemptions: number | null; redeemedCount: number;
  expiresAt: string | null; isActive: boolean; _count?: { subscriptions: number };
}

export interface AuditRow {
  id: string; action: string; entityType: string | null; entityId: string | null;
  metadata: Record<string, unknown> | null; ipAddress: string | null; createdAt: string;
  user: { email: string } | null; organization: { name: string } | null;
}
