export type AIProviderId = 'OPENAI' | 'ANTHROPIC' | 'GEMINI';
export type AssistantType = 'SALES' | 'SUPPORT' | 'APPOINTMENT' | 'LEAD_QUALIFICATION';
export type KnowledgeSourceType = 'TEXT' | 'URL' | 'FILE' | 'FAQ';

export interface Assistant {
  id: string; type: AssistantType; name: string;
  provider: AIProviderId; model: string; systemPrompt: string;
  temperature: number; isActive: boolean;
  config: Record<string, unknown> | null;
  escalationRules: Record<string, unknown> | null;
}

export interface KnowledgeEntry {
  id: string; name: string; sourceType: KnowledgeSourceType;
  sourceUri: string | null; content: string | null; createdAt: string;
}

export interface TestResult { reply: string; tokensIn: number; tokensOut: number }

export const PROVIDER_MODELS: Record<AIProviderId, string[]> = {
  OPENAI: ['gpt-4o', 'gpt-4o-mini'],
  ANTHROPIC: ['claude-sonnet-4-20250514', 'claude-3-5-haiku-20241022'],
  GEMINI: ['gemini-1.5-pro', 'gemini-1.5-flash'],
};
