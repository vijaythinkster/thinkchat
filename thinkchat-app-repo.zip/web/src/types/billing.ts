export interface UsageTotals {
  messages: number;
  metaCost: number;
  billedCost: number;
  margin: number;
}
export interface CategoryUsage {
  category: string; messages: number; metaCost: number; billedCost: number;
}
export interface CountryUsage {
  countryCode: string; messages: number; billedCost: number;
}
export interface PeriodUsage {
  periodStart: string; periodEnd: string;
  totals: UsageTotals;
  byCategory: CategoryUsage[];
  byCountry: CountryUsage[];
}

export type InvoiceStatus = 'DRAFT' | 'OPEN' | 'PAID' | 'VOID' | 'UNCOLLECTIBLE';
export interface Invoice {
  id: string; number: string; status: InvoiceStatus;
  subtotal: string; taxAmount: string; total: string; currency: string;
  issuedAt: string | null; dueAt: string | null; paidAt: string | null;
}

export interface Subscription {
  id: string; status: string; currentPeriodEnd: string | null;
  plan: { name: string; tier: string; priceMonthly: string; currency: string };
}
