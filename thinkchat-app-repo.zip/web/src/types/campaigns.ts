export type CampaignStatus =
  | 'DRAFT' | 'SCHEDULED' | 'RUNNING' | 'PAUSED' | 'COMPLETED' | 'CANCELED' | 'FAILED';

export interface Campaign {
  id: string;
  name: string;
  status: CampaignStatus;
  templateId: string;
  whatsAppNumberId: string;
  segmentId: string | null;
  scheduledAt: string | null;
  startedAt: string | null;
  completedAt: string | null;
  createdAt: string;
  template?: { name: string };
}

export interface CampaignAnalytics {
  campaignId: string;
  totals: {
    audience: number; pending: number; sent: number; delivered: number;
    read: number; clicked: number; replied: number; failed: number;
  };
  rates: {
    deliveryRate: number; readRate: number; clickRate: number;
    replyRate: number; failureRate: number;
  };
}

export type SegmentMatch = 'all' | 'any';
export interface SegmentCondition { field: string; op: string; value?: unknown }
export interface SegmentDefinition { match: SegmentMatch; conditions: SegmentCondition[] }

export interface CreateCampaignInput {
  name: string;
  templateId: string;
  whatsAppNumberId: string;
  segment: SegmentDefinition;
  variables?: { bodyParams?: string[] };
}
