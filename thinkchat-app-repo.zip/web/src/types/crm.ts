export interface Label { id: string; name: string; color: string }
export interface ContactLabel { label: Label }

export interface Contact {
  id: string; phone: string; name: string | null; email: string | null;
  countryCode: string | null; optedIn: boolean;
  attributes: Record<string, unknown> | null;
  lastContactedAt: string | null; createdAt: string;
  contactLabels?: ContactLabel[];
}

export interface ContactList { items: Contact[]; nextCursor: string | null }

export interface Note {
  id: string; body: string; createdAt: string;
  author?: { id: string; name: string | null } | null;
}
export interface Deal {
  id: string; title: string; value: string; currency: string;
  status: 'OPEN' | 'WON' | 'LOST'; stageId: string;
  stage?: { name: string }; contact?: { id: string; name: string | null; phone: string } | null;
}
export interface Task {
  id: string; title: string; status: 'TODO' | 'IN_PROGRESS' | 'DONE' | 'CANCELED'; dueAt: string | null;
}
export interface ContactDetail {
  contact: Contact; notes: Note[]; deals: Deal[]; tasks: Task[];
  conversations: { id: string; status: string; lastMessageAt: string | null }[];
}

export interface Stage { id: string; name: string; order: number; probability: number }
export interface BoardColumn { stage: Stage; deals: Deal[]; totalValue: number }
export interface Board { pipeline: { id: string; name: string } | null; columns: BoardColumn[] }
