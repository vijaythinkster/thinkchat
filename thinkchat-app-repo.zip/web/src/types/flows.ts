export type FlowStatus = 'DRAFT' | 'PUBLISHED' | 'ARCHIVED';
export type FlowNodeType =
  | 'MESSAGE' | 'QUESTION' | 'CONDITION' | 'AI' | 'API_CALL' | 'DELAY' | 'HUMAN_AGENT' | 'TAG' | 'CRM_UPDATE';

export interface FlowNode {
  id: string; type: FlowNodeType; label: string | null;
  config: Record<string, unknown>; position: { x: number; y: number };
}
export interface FlowConnection {
  id?: string; sourceNodeId: string; targetNodeId: string; condition?: Record<string, unknown> | null;
}
export interface Flow {
  id: string; name: string; description: string | null; status: FlowStatus;
  trigger: { type: string; config?: Record<string, unknown> };
  nodes?: FlowNode[]; connections?: FlowConnection[];
}

export const NODE_LABELS: Record<FlowNodeType, string> = {
  MESSAGE: 'Send message', QUESTION: 'Ask question', CONDITION: 'Branch',
  AI: 'AI reply', API_CALL: 'Call API', DELAY: 'Wait',
  HUMAN_AGENT: 'Hand to human', TAG: 'Add label', CRM_UPDATE: 'Update contact',
};
