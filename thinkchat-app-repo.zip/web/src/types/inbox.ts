export type ConversationStatus = 'OPEN' | 'PENDING' | 'RESOLVED' | 'SNOOZED';
export type MessageDirection = 'INBOUND' | 'OUTBOUND';
export type MessageStatus = 'QUEUED' | 'SENT' | 'DELIVERED' | 'READ' | 'FAILED';
export type MessageType =
  | 'TEXT' | 'IMAGE' | 'VIDEO' | 'AUDIO' | 'DOCUMENT'
  | 'STICKER' | 'LOCATION' | 'CONTACT' | 'TEMPLATE' | 'INTERACTIVE' | 'SYSTEM';

export interface Contact {
  id: string;
  name: string | null;
  phone: string;
  email?: string | null;
  attributes?: Record<string, unknown> | null;
}

export interface Label { id: string; name: string; color: string }

export interface Message {
  id: string;
  conversationId: string;
  direction: MessageDirection;
  type: MessageType;
  status: MessageStatus;
  body: string | null;
  mediaUrl?: string | null;
  mediaMimeType?: string | null;
  waMessageId?: string | null;
  sentAt?: string | null;
  deliveredAt?: string | null;
  readAt?: string | null;
  createdAt: string;
}

export interface Conversation {
  id: string;
  status: ConversationStatus;
  unreadCount: number;
  lastMessageAt: string | null;
  windowExpiresAt: string | null;
  contact: Contact;
  assignedAgent?: { id: string; user: { firstName: string | null; lastName: string | null } } | null;
  conversationLabels?: { label: Label }[];
  messages?: Message[]; // last message for the list row
}

export interface ListResponse {
  items: Conversation[];
  nextCursor: string | null;
}

export interface ThreadResponse {
  conversation: Conversation;
  messages: Message[];
}
