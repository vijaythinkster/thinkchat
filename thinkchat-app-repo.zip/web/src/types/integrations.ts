export type IntegrationProvider =
  | 'META_LEAD_ADS'
  | 'GOOGLE_LEAD_FORMS'
  | 'WORDPRESS'
  | 'WOOCOMMERCE'
  | 'SHOPIFY'
  | 'ASANA'
  | 'HUBSPOT'
  | 'SALESFORCE'
  | 'ZAPIER'
  | 'N8N';

export interface IntegrationView {
  provider: IntegrationProvider;
  kind: 'INBOUND_LEAD' | 'OUTBOUND_CRM' | 'BRIDGE';
  status: 'CONNECTED' | 'DISCONNECTED' | 'ERROR';
  connected: boolean;
  config: Record<string, unknown>;
  hasCredentials: boolean;
  lastSyncedAt: string | null;
}

export interface IntegrationEvent {
  id: string;
  eventType: string | null;
  status: string;
  error: string | null;
  createdAt: string;
}

export interface TestResult {
  ok: boolean;
  detail?: string;
}

/** UI metadata: label, blurb, and which credential/config fields each provider needs. */
export const PROVIDER_META: Record<
  IntegrationProvider,
  { label: string; blurb: string; credentialFields: string[]; configHint?: string }
> = {
  META_LEAD_ADS: {
    label: 'Meta Lead Ads',
    blurb: 'Capture Facebook/Instagram lead-form submissions as contacts.',
    credentialFields: ['appSecret', 'pageAccessToken', 'verifyToken'],
  },
  GOOGLE_LEAD_FORMS: {
    label: 'Google Lead Forms',
    blurb: 'Receive Google lead-form submissions via a webhook relay.',
    credentialFields: ['token'],
    configHint: 'Map form fields in config.fieldMap.',
  },
  WORDPRESS: {
    label: 'WordPress',
    blurb: 'Push Contact Form 7 / WPForms submissions into the platform.',
    credentialFields: ['token'],
    configHint: 'Set fieldMap to your form field names.',
  },
  WOOCOMMERCE: {
    label: 'WooCommerce',
    blurb: 'Turn new WooCommerce customers/orders into contacts.',
    credentialFields: ['webhookSecret'],
  },
  SHOPIFY: {
    label: 'Shopify',
    blurb: 'Sync Shopify customers and orders into contacts.',
    credentialFields: ['webhookSecret'],
  },
  ASANA: {
    label: 'Asana',
    blurb: 'Create an Asana task for every new lead.',
    credentialFields: ['accessToken'],
    configHint: 'Set projectGid to the target Asana project.',
  },
  HUBSPOT: {
    label: 'HubSpot',
    blurb: 'Push new contacts out to HubSpot CRM.',
    credentialFields: ['accessToken'],
  },
  SALESFORCE: {
    label: 'Salesforce',
    blurb: 'Create leads in Salesforce from new contacts.',
    credentialFields: ['accessToken', 'instanceUrl'],
  },
  ZAPIER: {
    label: 'Zapier',
    blurb: 'Connect 6,000+ apps via a generic inbound webhook.',
    credentialFields: ['token'],
  },
  N8N: {
    label: 'n8n',
    blurb: 'Self-hosted automation via a generic inbound webhook.',
    credentialFields: ['token'],
  },
};
